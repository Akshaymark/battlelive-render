"""Step 1: speech recognition with word timestamps (faster-whisper, runs offline on CPU).

Usage:  python scripts/transcribe.py public/audio/narration.wav
Writes: scripts/raw_transcript.json  (segments with per-word start/end seconds)

Requires: pip install faster-whisper  (downloads the 'small' model once; afterwards fully offline)
WhisperX can be swapped in for phoneme-level forced alignment: see README.
"""
import json, subprocess, sys
import numpy as np
from faster_whisper import WhisperModel

src = sys.argv[1] if len(sys.argv) > 1 else "public/audio/narration.wav"
pcm = subprocess.run(["ffmpeg", "-v", "error", "-i", src, "-ar", "16000", "-ac", "1", "-f", "f32le", "-"],
                     capture_output=True, check=True).stdout
audio = np.frombuffer(pcm, dtype=np.float32)
model = WhisperModel("small", device="cpu", compute_type="int8")
segments, info = model.transcribe(audio, word_timestamps=True, vad_filter=False)
out = []
for s in segments:
    out.append({"start": s.start, "end": s.end, "text": s.text.strip(),
                "words": [{"w": w.word, "s": w.start, "e": w.end} for w in s.words]})
    print(f"{s.start:7.2f}-{s.end:7.2f}  {s.text.strip()}")
json.dump(out, open("scripts/raw_transcript.json", "w"), indent=1)
print("language:", info.language, " duration:", round(len(audio) / 16000, 2), "s")
