#!/usr/bin/env bash
# Renders one review still per given frame (parallel, 3 at a time). Usage: scripts/stills.sh 60 300 ...
mkdir -p out/stills
printf "%s\n" "$@" | xargs -P 3 -I{} sh -c 'npx remotion still src/index.ts ${COMP:-LastRide} out/stills/f{}.jpg --frame={} --gl=angle --log=error >/dev/null 2>&1 || echo "fail {}"'
