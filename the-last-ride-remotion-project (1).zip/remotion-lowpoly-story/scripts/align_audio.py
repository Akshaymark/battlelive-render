"""Step 2: clean the recognised words, apply manual corrections, detect sentence
boundaries and pauses, and write src/data/transcript.json for Remotion.

Usage:  python scripts/align_audio.py
Reads:  scripts/raw_transcript.json
Writes: src/data/transcript.json  { duration, words:[{text,start,end,sentence,pauseAfter}], sentences:[...] }

Word timestamps come straight from Whisper's cross-attention alignment (not equal splits).
Corrections below fix recognition errors without touching timing.
"""
import json, re, subprocess

CORRECTIONS = {  # (sentence index, original word) -> replacement
    "right": "ride",  # "Don't get off when the ride stops" (Whisper heard "right")
}

raw = json.load(open("scripts/raw_transcript.json"))
dur = float(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                            "public/audio/narration.wav"], capture_output=True, text=True).stdout)
words, sentences = [], []
for si, seg in enumerate(raw):
    first = len(words)
    for w in seg["words"]:
        t = w["w"].strip()
        key = re.sub(r"[^\w']", "", t).lower()
        if key in CORRECTIONS:
            t = t.lower().replace(key, CORRECTIONS[key])
        words.append({"text": t, "start": round(w["s"], 3), "end": round(w["e"], 3), "sentence": si})
    sentences.append({"index": si, "start": round(seg["start"], 3), "end": round(seg["end"], 3),
                      "text": " ".join(x["text"] for x in words[first:]), "firstWord": first, "lastWord": len(words) - 1})
for i, w in enumerate(words):
    nxt = words[i + 1]["start"] if i + 1 < len(words) else dur
    w["pauseAfter"] = round(max(0.0, nxt - w["end"]), 3)
json.dump({"duration": round(dur, 3), "words": words, "sentences": sentences},
          open("src/data/transcript.json", "w"), indent=1)
print(len(words), "words,", len(sentences), "sentences,", round(dur, 2), "s")
