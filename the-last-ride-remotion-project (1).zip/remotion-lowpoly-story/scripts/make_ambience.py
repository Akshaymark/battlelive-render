"""Procedurally synthesises the ambience/SFX bed (no samples, no external assets).
Usage: python scripts/make_ambience.py   -> public/audio/ambience.wav
Event times (seconds) match the storyboard in src/data/storyboard.ts."""
import json, wave
import numpy as np

SR = 44100
DUR = json.load(open("src/data/transcript.json"))["duration"] + 1.5
N = int(DUR * SR)
rng = np.random.default_rng(7)
t = np.arange(N) / SR
L = np.zeros(N); R = np.zeros(N)

def lp(x, a):  # one-pole low-pass
    y = np.empty_like(x); s = 0.0
    for i in range(len(x)):
        s += a * (x[i] - s); y[i] = s
    return y

def add(sig, at, gain=1.0, pan=0.0):
    i = int(at * SR); n = min(len(sig), N - i)
    if n <= 0: return
    L[i:i + n] += sig[:n] * gain * (1 - max(0, pan)); R[i:i + n] += sig[:n] * gain * (1 + min(0, pan))

# dark drone: detuned low sines, slow swell, rises in tension towards the end
ten = np.clip(t / 110, 0, 1)
drone = (np.sin(2*np.pi*55*t) + 0.7*np.sin(2*np.pi*55.4*t) + 0.4*np.sin(2*np.pi*82.5*t + np.sin(t*0.3)))
drone *= (0.35 + 0.25*np.sin(t*0.21)**2) * (0.6 + 0.6*ten)
# high eerie music-box-like tone cluster (sparse)
bell = np.zeros(N)
for k, at in enumerate(np.arange(1.0, DUR - 3, 4.3)):
    f = [523.25, 622.25, 493.88, 415.3][k % 4]
    n = int(2.5 * SR); tt = np.arange(n) / SR
    s = np.sin(2*np.pi*f*tt) * np.exp(-tt*2.2) * 0.25
    i = int(at * SR); m = min(n, N - i); bell[i:i+m] += s[:m]
wind = np.resize(lp(rng.normal(0, 1, N // 8 + 1), 0.02).repeat(8), N) * 0.6 * (0.6 + 0.4*np.sin(t*0.17))
bed = drone * 0.06 + bell * 0.25 + wind * 0.22
L += bed; R += bed * 0.95 + np.roll(bell, 900) * 0.05

def creak(d=1.4):
    n = int(d*SR); tt = np.arange(n)/SR
    f = 180 + 60*np.sin(tt*7)
    s = np.sign(np.sin(2*np.pi*np.cumsum(f)/SR)) * np.exp(-((tt-d/2)/(d/2.5))**2)
    return lp(s, 0.08) * 0.5
def crackle(d=2.0):
    n = int(d*SR); s = rng.normal(0, 1, n) * (rng.random(n) < 0.02) * 2 + rng.normal(0, 0.15, n)
    return s * np.exp(-np.arange(n)/SR*0.3) * 0.5
def thump(g=1.0):
    n = int(0.8*SR); tt = np.arange(n)/SR
    return np.sin(2*np.pi*(45 + 60*np.exp(-tt*20))*tt) * np.exp(-tt*5) * g
def whoosh(d=0.8):
    n = int(d*SR); s = lp(rng.normal(0, 1, n), 0.1)
    return s * np.sin(np.pi*np.arange(n)/n)**2 * 0.6
def steps(at, count, gap):
    for k in range(count):
        n = int(0.12*SR); s = lp(rng.normal(0, 1, n), 0.3) * np.exp(-np.arange(n)/SR*40)
        add(s, at + k*gap, 0.35, pan=0.2*(-1)**k)

for at in [13.0, 18.4, 21.3, 101.0, 115.5]: add(creak(), at, 0.35, -0.3)
steps(15.9, 6, 0.42); steps(77.0, 6, 0.45)
add(thump(), 0.05, 0.6); add(thump(0.7), 11.56, 0.5)
add(crackle(6.5), 47.0, 0.55)
add(thump(0.6), 39.9, 0.4); add(whoosh(), 37.8, 0.5); add(thump(1.0), 44.2, 0.7)
add(thump(0.9), 60.9, 0.6); add(whoosh(), 63.6, 0.5); add(thump(1.0), 66.3, 0.7)
for k in range(5): add(thump(0.35), 73.8 + k*0.12, 0.4)
add(creak(2.2), 75.0, 0.45, 0.3)
add(thump(0.8), 87.9, 0.5); add(thump(1.0), 96.9, 0.7); add(thump(1.0), 104.6, 0.8)
add(whoosh(1.2), 112.5, 0.5); add(thump(1.0), 125.9, 0.6)

mix = np.stack([L, R], 1)
mix = mix / (np.abs(mix).max() + 1e-9) * 0.7
fade = np.ones(N); fade[-int(1.5*SR):] = np.linspace(1, 0, int(1.5*SR)); mix *= fade[:, None]
with wave.open("public/audio/ambience.wav", "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((mix * 32767).astype(np.int16).tobytes())
print("wrote public/audio/ambience.wav", round(DUR, 2), "s")
