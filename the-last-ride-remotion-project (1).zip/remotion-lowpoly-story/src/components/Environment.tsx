import React, {useMemo} from 'react';
import * as THREE from 'three';
import {PALETTE} from '../config';

const fm = (color: string, o: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
  new THREE.MeshStandardMaterial({color, flatShading: true, roughness: 0.9, ...o});

/** Seeded RNG so every render of every frame places scenery identically. */
const rng = (seed: number) => () => {
  seed = (seed * 16807) % 2147483647;
  return (seed - 1) / 2147483646;
};

/** Faceted ground with gentle random displacement. */
const Ground: React.FC = () => {
  const geo = useMemo(() => {
    const g = new THREE.PlaneGeometry(240, 240, 48, 48);
    const r = rng(11);
    const pos = g.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const far = Math.min(1, Math.max(0, (Math.hypot(x, y) - 45) / 60));
      pos.setZ(i, (r() - 0.5) * 0.35 + far * r() * 6);
    }
    g.computeVertexNormals();
    return g.toNonIndexed();
  }, []);
  const m = useMemo(() => fm('#1d2a2a'), []);
  const path = useMemo(() => fm('#3a3a40'), []);
  return (
    <group>
      <mesh geometry={geo} material={m} rotation={[-Math.PI / 2, 0, 0]} receiveShadow />
      <mesh material={path} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 22]} receiveShadow>
        <planeGeometry args={[6, 40]} />
      </mesh>
    </group>
  );
};

const Stars: React.FC = () => {
  const obj = useMemo(() => {
    const r = rng(5);
    const pts: number[] = [];
    for (let i = 0; i < 500; i++) {
      const th = r() * Math.PI * 2;
      const ph = r() * 0.45 * Math.PI;
      const R = 180;
      pts.push(Math.cos(th) * Math.cos(ph) * R, Math.sin(ph) * R + 10, Math.sin(th) * Math.cos(ph) * R);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
    return new THREE.Points(g, new THREE.PointsMaterial({color: '#dfe6ff', size: 0.9, sizeAttenuation: true, fog: false}));
  }, []);
  return <primitive object={obj} />;
};

export const Moon: React.FC<{position?: [number, number, number]}> = ({position = [-60, 70, -120]}) => {
  const m = useMemo(() => new THREE.MeshBasicMaterial({color: '#e9eeff', fog: false}), []);
  return (
    <mesh material={m} position={position}>
      <icosahedronGeometry args={[7, 1]} />
    </mesh>
  );
};

const Tree: React.FC<{p: [number, number, number]; s: number}> = ({p, s}) => {
  const M = useMemo(() => ({leaf: fm('#16302a'), trunk: fm('#2b1f18')}), []);
  return (
    <group position={p} scale={s}>
      <mesh material={M.trunk} position={[0, 0.6, 0]} castShadow>
        <cylinderGeometry args={[0.15, 0.22, 1.2, 5]} />
      </mesh>
      <mesh material={M.leaf} position={[0, 2.2, 0]} castShadow>
        <coneGeometry args={[1.3, 2.6, 6]} />
      </mesh>
      <mesh material={M.leaf} position={[0, 3.4, 0]} castShadow>
        <coneGeometry args={[0.9, 2.0, 6]} />
      </mesh>
    </group>
  );
};

export const LampPost: React.FC<{p: [number, number, number]; on: number}> = ({p, on}) => {
  const M = useMemo(() => ({pole: fm('#22252e', {metalness: 0.5}), glow: new THREE.MeshBasicMaterial({color: '#ffd59a'}), off: fm('#3a3a3a')}), []);
  return (
    <group position={p}>
      <mesh material={M.pole} position={[0, 2, 0]} castShadow>
        <cylinderGeometry args={[0.07, 0.1, 4, 5]} />
      </mesh>
      <mesh material={on > 0.1 ? M.glow : M.off} position={[0, 4.1, 0]}>
        <icosahedronGeometry args={[0.25, 0]} />
      </mesh>
      {on > 0.1 ? <pointLight position={[0, 3.9, 0]} color={PALETTE.warm} intensity={on * 6} distance={11} decay={1.6} /> : null}
    </group>
  );
};

const Tent: React.FC<{p: [number, number, number]; c: string; r?: number}> = ({p, c, r = 0}) => {
  const M = useMemo(() => ({a: fm(c), b: fm('#d9d0c0'), base: fm('#2a2a2f')}), [c]);
  return (
    <group position={p} rotation={[0, r, 0]}>
      <mesh material={M.base} position={[0, 1, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[2.2, 2.2, 2, 8]} />
      </mesh>
      <mesh material={M.a} position={[0, 2.9, 0]} castShadow>
        <coneGeometry args={[2.7, 1.9, 8]} />
      </mesh>
      <mesh material={M.b} position={[0, 4.0, 0]}>
        <coneGeometry args={[0.12, 0.5, 4]} />
      </mesh>
    </group>
  );
};

const Carousel: React.FC<{p: [number, number, number]}> = ({p}) => {
  const M = useMemo(() => ({roof: fm('#6d2a33'), stripe: fm('#d8cdb5'), pole: fm('#b39a5a', {metalness: 0.6}), base: fm('#3a3340'), horse: fm('#cfc6b4')}), []);
  return (
    <group position={p}>
      <mesh material={M.base} position={[0, 0.3, 0]} receiveShadow castShadow>
        <cylinderGeometry args={[5, 5, 0.6, 12]} />
      </mesh>
      <mesh material={M.roof} position={[0, 5, 0]} castShadow>
        <coneGeometry args={[5.6, 2.4, 12]} />
      </mesh>
      {Array.from({length: 8}).map((_, k) => {
        const a = (k / 8) * Math.PI * 2;
        return (
          <group key={k} position={[Math.sin(a) * 3.8, 0, Math.cos(a) * 3.8]}>
            <mesh material={M.pole} position={[0, 2.4, 0]}>
              <cylinderGeometry args={[0.05, 0.05, 4, 4]} />
            </mesh>
            <mesh material={M.horse} position={[0, 1.6 + (k % 2) * 0.3, 0]} rotation={[0, a + Math.PI / 2, 0]} castShadow>
              <boxGeometry args={[0.9, 0.45, 0.25]} />
            </mesh>
          </group>
        );
      })}
    </group>
  );
};

/** Entrance gates with two hinged doors; `open` 0..1 swings them inward. */
export const Gates: React.FC<{z: number; open: number}> = ({z, open}) => {
  const M = useMemo(() => ({iron: fm('#1a1c22', {metalness: 0.6, roughness: 0.5}), arch: fm('#5a1f27'), sign: fm('#d9c48a', {emissive: '#2a1a00'})}), []);
  const door = (side: 1 | -1) => (
    <group position={[3 * side, 0, 0]} rotation={[0, side * open * 1.4, 0]}>
      {Array.from({length: 7}).map((_, k) => (
        <mesh key={k} material={M.iron} position={[-side * (0.2 + k * 0.42), 1.6, 0]} castShadow>
          <boxGeometry args={[0.07, 3.2, 0.07]} />
        </mesh>
      ))}
      <mesh material={M.iron} position={[-side * 1.5, 0.4, 0]}>
        <boxGeometry args={[3, 0.08, 0.08]} />
      </mesh>
      <mesh material={M.iron} position={[-side * 1.5, 2.9, 0]}>
        <boxGeometry args={[3, 0.08, 0.08]} />
      </mesh>
    </group>
  );
  return (
    <group position={[0, 0, z]}>
      {[1, -1].map((s) => (
        <mesh key={s} material={M.arch} position={[3.3 * s, 2.6, 0]} castShadow>
          <boxGeometry args={[0.6, 5.2, 0.6]} />
        </mesh>
      ))}
      <mesh material={M.arch} position={[0, 5.6, 0]} castShadow>
        <boxGeometry args={[7.6, 0.9, 0.6]} />
      </mesh>
      <mesh material={M.sign} position={[0, 5.6, 0.32]}>
        <boxGeometry args={[4.5, 0.5, 0.05]} />
      </mesh>
      {door(1)}
      {door(-1)}
      {/* fence */}
      {[1, -1].map((s) =>
        Array.from({length: 26}).map((_, k) => (
          <mesh key={`${s}${k}`} material={M.iron} position={[s * (4 + k * 1.2), 1.1, 0]}>
            <boxGeometry args={[0.08, 2.2, 0.08]} />
          </mesh>
        )),
      )}
      {[1, -1].map((s) => (
        <mesh key={`r${s}`} material={M.iron} position={[s * 19.5, 2, 0]}>
          <boxGeometry args={[31, 0.08, 0.08]} />
        </mesh>
      ))}
    </group>
  );
};

/** Loudspeaker pole; `crackle` 0..1 makes the horn glow/jitter. */
export const Speaker: React.FC<{p: [number, number, number]; crackle: number; t: number}> = ({p, crackle, t}) => {
  const M = useMemo(() => ({pole: fm('#2a2d36', {metalness: 0.5}), horn: fm('#9aa0ab', {metalness: 0.6, roughness: 0.4}), led: new THREE.MeshBasicMaterial({color: '#ff3030'})}), []);
  const j = crackle > 0 ? Math.sin(t * 70) * 0.03 * crackle : 0;
  return (
    <group position={p}>
      <mesh material={M.pole} position={[0, 3, 0]}>
        <cylinderGeometry args={[0.08, 0.12, 6, 5]} />
      </mesh>
      {[-0.6, 0.6].map((x) => (
        <mesh key={x} material={M.horn} position={[x + j, 5.8, 0.2]} rotation={[Math.PI / 2 - 0.3, 0, x * 0.4]}>
          <coneGeometry args={[0.45, 0.9, 6, 1, true]} />
        </mesh>
      ))}
      {crackle > 0.05 && Math.sin(t * 23) > 0 ? (
        <mesh material={M.led} position={[0, 5.4, 0.15]}>
          <icosahedronGeometry args={[0.06, 0]} />
        </mesh>
      ) : null}
    </group>
  );
};

export type ParkState = {lights: number; gatesOpen: number; crackle: number; t: number};

/** The whole amusement-park exterior (everything except the wheel and characters). */
export const Park: React.FC<ParkState> = ({lights, gatesOpen, crackle, t}) => {
  const trees = useMemo(() => {
    const r = rng(3);
    const out: {p: [number, number, number]; s: number}[] = [];
    for (let i = 0; i < 46; i++) {
      const a = r() * Math.PI * 2;
      const d = 34 + r() * 30;
      out.push({p: [Math.cos(a) * d, 0, Math.sin(a) * d - 5], s: 0.9 + r() * 1.3});
    }
    return out;
  }, []);
  return (
    <group>
      <Ground />
      <Stars />
      <Moon />
      {trees.map((tr, i) => (
        <Tree key={i} p={tr.p} s={tr.s} />
      ))}
      <Gates z={38} open={gatesOpen} />
      {[6, 14, 22, 30].map((z) => (
        <React.Fragment key={z}>
          <LampPost p={[-4.2, 0, z]} on={lights} />
          <LampPost p={[4.2, 0, z]} on={lights} />
        </React.Fragment>
      ))}
      <Tent p={[-14, 0, 18]} c="#7a2a35" r={0.3} />
      <Tent p={[15, 0, 14]} c="#2a4a6a" r={0.8} />
      <Tent p={[-22, 0, -6]} c="#5a4a20" />
      <Carousel p={[18, 0, -4]} />
      <Speaker p={[6.5, 0, 24]} crackle={crackle} t={t} />
    </group>
  );
};
