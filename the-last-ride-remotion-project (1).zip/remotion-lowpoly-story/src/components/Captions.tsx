import React, {useMemo} from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {WORDS, Word} from '../utils/speech';
import {EMPHASIS, SCENES} from '../data/storyboard';
import {PALETTE} from '../config';

type Phrase = {words: Word[]; start: number; end: number};

/** Group aligned words into short caption phrases: break on sentence ends, pauses, or length. */
export const buildPhrases = (words: Word[]): Phrase[] => {
  const out: Phrase[] = [];
  let cur: Word[] = [];
  const flush = () => {
    if (!cur.length) return;
    const last = cur[cur.length - 1];
    out.push({words: cur, start: cur[0].start - 0.06, end: last.end + Math.min(0.45, last.pauseAfter)});
    cur = [];
  };
  words.forEach((w, i) => {
    cur.push(w);
    const next = words[i + 1];
    const chars = cur.map((x) => x.text).join(' ').length;
    const endSentence = /[.?!,]$/.test(w.text) || !next || next.sentence !== w.sentence;
    if (endSentence || w.pauseAfter > 0.32 || cur.length >= 4 || chars > 20) flush();
  });
  flush();
  return out;
};

const clean = (s: string) => s.toLowerCase().replace(/[^a-z']/g, '');

/** Word-by-word cinematic captions, timed from the real alignment. */
export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const phrases = useMemo(() => buildPhrases(WORDS), []);
  const ph = phrases.find((p) => t >= p.start && t <= p.end);
  if (!ph) return null;
  const scene = SCENES.find((s) => t >= s.from && t < s.to);
  const portrait = height > width;
  const top = scene?.caption === 'top';
  const fontSize = portrait ? 86 : 74;
  const appear = interpolate(t, [ph.start, ph.start + 0.12], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const leave = interpolate(t, [ph.end - 0.1, ph.end], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <AbsoluteFill
      style={{
        justifyContent: top ? 'flex-start' : 'flex-end',
        alignItems: 'center',
        paddingTop: top ? (portrait ? 300 : 90) : 0,
        paddingBottom: top ? 0 : portrait ? 380 : 110,
        pointerEvents: 'none',
      }}
    >
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          maxWidth: portrait ? 940 : 1500,
          gap: '0 22px',
          opacity: appear * leave,
          transform: `scale(${0.9 + 0.1 * appear}) translateY(${(1 - appear) * 20}px)`,
        }}
      >
        {ph.words.map((w, i) => {
          const spoken = t >= w.start;
          const active = spoken && (i === ph.words.length - 1 ? t <= ph.end : t < ph.words[i + 1].start);
          const emph = EMPHASIS.has(clean(w.text));
          const pop = interpolate(t, [w.start, w.start + 0.12], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
          const color = !spoken ? PALETTE.captionDim : emph ? PALETTE.accent : active ? '#ffe9b0' : PALETTE.caption;
          return (
            <span
              key={`${w.start}-${i}`}
              style={{
                fontFamily: 'Anton',
                fontSize,
                lineHeight: 1.15,
                letterSpacing: 1,
                textTransform: 'uppercase',
                color,
                display: 'inline-block',
                transform: `scale(${active ? 1 + 0.12 * pop : 1}) translateY(${active ? -6 * pop : 0}px)`,
                textShadow: '0 6px 0 rgba(0,0,0,0.85), 0 0 30px rgba(0,0,0,0.9), 0 0 4px #000',
                WebkitTextStroke: '3px rgba(0,0,0,0.85)',
                paintOrder: 'stroke fill',
              }}
            >
              {w.text.replace(/[.,]$/, '')}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
