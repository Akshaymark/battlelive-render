import React, {useLayoutEffect} from 'react';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {CamKey} from '../data/types';
import {easeInOut, lerp, lerp3, noise1, V3} from '../utils/anim';
import {cabinPivot} from './FerrisWheel';

/** Resolve a camera key to world space (follow-cabin keys are relative to the moving cabin). */
const toWorld = (k: CamKey, wheelAngle: number): {pos: V3; target: V3} => {
  if (k.followCabin === undefined) return {pos: k.pos, target: k.target};
  const p = cabinPivot(k.followCabin, wheelAngle);
  return {
    pos: [k.pos[0] + p[0], k.pos[1] + p[1], k.pos[2] + p[2]],
    target: [k.target[0] + p[0], k.target[1] + p[1], k.target[2] + p[2]],
  };
};

export const cameraAt = (keys: CamKey[], t: number, wheelAngle: number) => {
  let a = keys[0];
  let b = keys[keys.length - 1];
  for (let i = 0; i < keys.length - 1; i++) {
    if (t >= keys[i].t && t <= keys[i + 1].t) {
      a = keys[i];
      b = keys[i + 1];
      break;
    }
  }
  if (t < keys[0].t) b = a;
  if (t > keys[keys.length - 1].t) a = b;
  const k = a === b ? 0 : easeInOut((t - a.t) / (b.t - a.t));
  const A = toWorld(a, wheelAngle);
  const B = toWorld(b, wheelAngle);
  return {
    pos: lerp3(A.pos, B.pos, k),
    target: lerp3(A.target, B.target, k),
    fov: lerp(a.fov ?? 45, b.fov ?? 45, k),
    roll: lerp(a.roll ?? 0, b.roll ?? 0, k),
  };
};

/**
 * Drives the R3F default camera from storyboard keyframes. Deterministic: depends only on time.
 * `handheld` adds a subtle procedural shake. For landscape renders the vertical FOV is narrowed so
 * framing stays comparable to the 9:16 master.
 */
export const StoryCamera: React.FC<{keys: CamKey[]; t: number; wheelAngle: number; handheld?: number}> = ({keys, t, wheelAngle, handheld = 0}) => {
  const {camera, size} = useThree();
  useLayoutEffect(() => {
    const c = cameraAt(keys, t, wheelAngle);
    const cam = camera as THREE.PerspectiveCamera;
    const sh = handheld * 0.02;
    cam.position.set(c.pos[0] + noise1(t * 1.3, 1) * sh, c.pos[1] + noise1(t * 1.1, 2) * sh, c.pos[2] + noise1(t * 0.9, 3) * sh);
    cam.up.set(0, 1, 0);
    cam.lookAt(c.target[0], c.target[1], c.target[2]);
    if (c.roll) cam.rotateZ(c.roll);
    const aspect = size.width / size.height;
    const fov = aspect > 1 ? (2 * Math.atan(Math.tan((c.fov * Math.PI) / 360) / 1.45) * 180) / Math.PI : c.fov;
    cam.fov = fov;
    cam.near = 0.05;
    cam.far = 600;
    cam.aspect = aspect;
    cam.updateProjectionMatrix();
  }, [camera, keys, t, wheelAngle, handheld, size.width, size.height]);
  return null;
};
