import React, {useMemo} from 'react';
import * as THREE from 'three';
import {Pose} from '../animations/poses';
import {Face} from '../animations/expressions';

/**
 * Procedural low-poly human. Every part is a faceted primitive (flat shading), arranged in a
 * joint hierarchy: pelvis -> torso -> neck -> head, shoulders -> elbows -> hands, hips -> knees -> feet.
 * The face is built from separate brow / eye / pupil / mouth meshes driven by a `Face`.
 */
export type CharacterKind = 'hero' | 'girl' | 'ghost' | 'guard' | 'passenger';

export type Look = {
  skin: string; hair: string; top: string; bottom: string; shoes: string;
  height: number; // overall scale (adult = 1)
  hairStyle: 'short' | 'bob' | 'bald' | 'cap';
  dress?: boolean;
  eyeGlow?: string; // ghost-style glowing eyes
};

const PASSENGER_LOOKS: Look[] = [
  {skin: '#b98a6a', hair: '#1d1a19', top: '#5b6b7a', bottom: '#2c2f38', shoes: '#151515', height: 1, hairStyle: 'short'},
  {skin: '#d9b08c', hair: '#4a3222', top: '#7a4b4b', bottom: '#2a2a33', shoes: '#151515', height: 0.95, hairStyle: 'bob', dress: true},
  {skin: '#8d5b3e', hair: '#111111', top: '#4f6a52', bottom: '#2b2b2b', shoes: '#151515', height: 1.02, hairStyle: 'short'},
  {skin: '#e3c3a5', hair: '#8a8a8a', top: '#6b5a7a', bottom: '#2f2a35', shoes: '#151515', height: 0.97, hairStyle: 'bald'},
];

export const LOOKS: Record<Exclude<CharacterKind, 'passenger'>, Look> = {
  hero: {skin: '#c08a64', hair: '#16130f', top: '#2f5d6b', bottom: '#23252e', shoes: '#111', height: 1, hairStyle: 'short'},
  girl: {skin: '#efd9c8', hair: '#120f0f', top: '#f2efe6', bottom: '#f2efe6', shoes: '#3a1010', height: 0.62, hairStyle: 'bob', dress: true},
  ghost: {skin: '#3a3f4a', hair: '#0c0c10', top: '#22252d', bottom: '#1a1c22', shoes: '#0a0a0a', height: 1.06, hairStyle: 'short', eyeGlow: '#d8f3ff'},
  guard: {skin: '#9b6b4b', hair: '#222', top: '#1f2d4f', bottom: '#1a2340', shoes: '#0d0d0d', height: 1.08, hairStyle: 'cap'},
};

export const lookFor = (kind: CharacterKind, variant = 0): Look =>
  kind === 'passenger' ? PASSENGER_LOOKS[variant % PASSENGER_LOOKS.length] : LOOKS[kind];

const mat = (color: string, opts: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
  new THREE.MeshStandardMaterial({color, flatShading: true, roughness: 0.85, metalness: 0.0, ...opts});

// Shared low-poly geometries (created once).
const G = {
  head: new THREE.IcosahedronGeometry(0.13, 1),
  hair: new THREE.IcosahedronGeometry(0.14, 1),
  torso: new THREE.CylinderGeometry(0.2, 0.15, 0.56, 6),
  dress: new THREE.CylinderGeometry(0.16, 0.34, 0.62, 7),
  pelvis: new THREE.CylinderGeometry(0.155, 0.15, 0.16, 6),
  limbUpper: new THREE.CylinderGeometry(0.06, 0.05, 0.3, 5),
  limbLower: new THREE.CylinderGeometry(0.05, 0.04, 0.28, 5),
  thigh: new THREE.CylinderGeometry(0.075, 0.06, 0.45, 5),
  shin: new THREE.CylinderGeometry(0.06, 0.045, 0.45, 5),
  hand: new THREE.IcosahedronGeometry(0.048, 0),
  foot: new THREE.BoxGeometry(0.1, 0.07, 0.22),
  neck: new THREE.CylinderGeometry(0.05, 0.06, 0.1, 5),
  eye: new THREE.IcosahedronGeometry(0.026, 1),
  pupil: new THREE.IcosahedronGeometry(0.014, 0),
  brow: new THREE.BoxGeometry(0.06, 0.009, 0.01),
  nose: new THREE.ConeGeometry(0.022, 0.05, 4),
  mouthArc: new THREE.TorusGeometry(0.036, 0.008, 3, 8, Math.PI),
  mouthHole: new THREE.IcosahedronGeometry(0.03, 1),
  capTop: new THREE.CylinderGeometry(0.15, 0.14, 0.08, 7),
  capBrim: new THREE.BoxGeometry(0.2, 0.015, 0.12),
};

export type CharacterProps = {
  kind: CharacterKind;
  variant?: number;
  pose: Pose;
  face: Face;
  mouth: number; // speaking openness 0..1
  opacity?: number;
  position?: [number, number, number];
  rotationY?: number;
  scale?: number;
  holdBalloon?: boolean;
  t: number;
};

export const Character: React.FC<CharacterProps> = ({
  kind, variant = 0, pose, face, mouth, opacity = 1, position = [0, 0, 0], rotationY = 0, scale = 1, holdBalloon, t,
}) => {
  const look = lookFor(kind, variant);
  const transparent = opacity < 0.999;
  const M = useMemo(() => {
    const o = {transparent, opacity, depthWrite: !transparent};
    return {
      skin: mat(look.skin, o),
      hair: mat(look.hair, o),
      top: mat(look.top, o),
      bottom: mat(look.bottom, o),
      shoes: mat(look.shoes, o),
      eyeWhite: look.eyeGlow
        ? new THREE.MeshBasicMaterial({color: look.eyeGlow, transparent, opacity})
        : mat('#f4f1ea', {...o, roughness: 0.4}),
      pupil: look.eyeGlow ? new THREE.MeshBasicMaterial({color: '#ffffff', transparent, opacity}) : mat('#0b0b0b', o),
      brow: mat(look.hair === '#8a8a8a' ? '#666' : '#0d0b0a', o),
      mouth: mat('#3a0f12', o),
      lip: mat(kind === 'girl' ? '#b0485a' : '#7a3d36', o),
      badge: mat('#d8c27a', {...o, metalness: 0.6, roughness: 0.3}),
    };
  }, [look, opacity, transparent, kind]);

  const shiverX = pose.shiver ? Math.sin(t * 60) * 0.006 * pose.shiver : 0;
  const s = look.height * scale;
  const sitting = pose.hipY < 0.75;

  const leg = (side: 1 | -1, thigh: number, knee: number) => (
    <group position={[0.1 * side, 0, 0]} rotation={[thigh, 0, 0]}>
      <mesh geometry={G.thigh} material={look.dress ? M.skin : M.bottom} position={[0, -0.225, 0]} castShadow />
      <group position={[0, -0.45, 0]} rotation={[knee, 0, 0]}>
        <mesh geometry={G.shin} material={look.dress ? M.skin : M.bottom} position={[0, -0.225, 0]} castShadow />
        <mesh geometry={G.foot} material={M.shoes} position={[0, -0.46, 0.05]} castShadow />
      </group>
    </group>
  );

  const arm = (side: 1 | -1, fwd: number, out: number, elbow: number, holding = false) => (
    <group position={[0.25 * side, 0.5, 0]} rotation={[fwd, 0, out * side]}>
      <mesh geometry={G.limbUpper} material={M.top} position={[0, -0.15, 0]} castShadow />
      <group position={[0, -0.3, 0]} rotation={[-elbow, 0, 0]}>
        <mesh geometry={G.limbLower} material={kind === 'girl' ? M.skin : M.top} position={[0, -0.14, 0]} castShadow />
        <mesh geometry={G.hand} material={M.skin} position={[0, -0.3, 0]} castShadow />
        {holding ? <Balloon t={t} /> : null}
      </group>
    </group>
  );

  // Mouth: arc (smile/frown) + dark opening scaled by expression + speech.
  const open = Math.min(1, face.mouthOpen + mouth * 0.9);
  const curve = face.mouthCurve;
  const eyeY = 0.165;

  return (
    <group position={position} rotation={[0, rotationY, 0]} scale={s}>
      <group position={[shiverX, pose.hipY, 0]}>
        {/* legs */}
        {leg(1, pose.thighL, pose.kneeL)}
        {leg(-1, pose.thighR, pose.kneeR)}
        <mesh geometry={G.pelvis} material={look.dress ? M.top : M.bottom} position={[0, 0.02, 0]} castShadow />
        {/* torso */}
        <group rotation={[pose.lean, pose.torsoYaw, 0]} scale={[1, 1 + pose.breathe, 1 + pose.breathe]}>
          <mesh geometry={G.torso} material={M.top} position={[0, 0.3, 0]} castShadow />
          {look.dress ? (
            <mesh geometry={G.dress} material={M.top} position={[0, sitting ? 0.02 : -0.12, sitting ? 0.06 : 0]} castShadow />
          ) : null}
          {kind === 'guard' ? <mesh geometry={G.hand} material={M.badge} position={[0.1, 0.42, 0.17]} scale={0.6} /> : null}
          {arm(1, pose.armLFwd, pose.armLOut, pose.elbowL, holdBalloon)}
          {arm(-1, pose.armRFwd, pose.armROut, pose.elbowR)}
          <mesh geometry={G.neck} material={M.skin} position={[0, 0.6, 0]} />
          {/* head */}
          <group position={[0, 0.64, 0]} rotation={[pose.headPitch, pose.headYaw, pose.headRoll]}>
            <mesh geometry={G.head} material={M.skin} position={[0, 0.14, 0]} scale={[1, 1.15, 1.02]} castShadow />
            {look.hairStyle === 'short' ? (
              <mesh geometry={G.hair} material={M.hair} position={[0, 0.2, -0.025]} scale={[1.02, 0.85, 1.02]} />
            ) : null}
            {look.hairStyle === 'bob' ? (
              <mesh geometry={G.hair} material={M.hair} position={[0, 0.15, -0.035]} scale={[1.1, 1.18, 1.05]} />
            ) : null}
            {look.hairStyle === 'cap' ? (
              <group position={[0, 0.27, 0]}>
                <mesh geometry={G.capTop} material={M.top} />
                <mesh geometry={G.capBrim} material={M.shoes} position={[0, -0.03, 0.1]} />
                <mesh geometry={G.hand} material={M.badge} position={[0, 0.01, 0.14]} scale={0.45} />
              </group>
            ) : null}
            {/* face */}
            <group position={[0, 0, 0.005]}>
              {[1, -1].map((side) => (
                <group key={side} position={[0.048 * side, eyeY, 0.112]}>
                  <mesh geometry={G.eye} material={M.eyeWhite} scale={[1, face.eyeScale, 0.6]} />
                  <mesh
                    geometry={G.pupil}
                    material={M.pupil}
                    position={[0, 0, 0.018]}
                    scale={[face.pupil, face.pupil * Math.min(1.2, face.eyeScale), 0.6]}
                  />
                  <mesh
                    geometry={G.brow}
                    material={M.brow}
                    position={[0, 0.042 + face.browY + face.browTilt * 0.02 * side, 0.01]}
                    rotation={[0, 0, -face.browAngle * side + face.browTilt * 0.4]}
                  />
                </group>
              ))}
              {look.eyeGlow ? null : <mesh geometry={G.nose} material={M.skin} position={[0, 0.12, 0.13]} rotation={[Math.PI / 2.2, 0, 0]} />}
              <group position={[0, 0.072, 0.118]} scale={[face.mouthWidth, 1, 1]}>
                {open > 0.04 ? (
                  <mesh geometry={G.mouthHole} material={M.mouth} scale={[0.85, 0.15 + open * 0.75, 0.35]} />
                ) : null}
                {Math.abs(curve) > 0.05 ? (
                  <mesh
                    geometry={G.mouthArc}
                    material={M.lip}
                    rotation={[0, 0, curve > 0 ? Math.PI : 0]}
                    position={[0, curve > 0 ? 0.008 : -0.012, 0.004]}
                    scale={[0.9, Math.abs(curve) * 0.55, 0.5]}
                  />
                ) : open <= 0.04 ? (
                  <mesh geometry={G.brow} material={M.lip} scale={[1.1, 0.8, 1]} />
                ) : null}
              </group>
            </group>
          </group>
        </group>
      </group>
    </group>
  );
};

/** Red balloon on a string, held in the hand. Sways deterministically with time. */
export const Balloon: React.FC<{t: number}> = ({t}) => {
  const sway = Math.sin(t * 0.9) * 0.12;
  const m = useMemo(() => mat('#d4161f', {roughness: 0.35, metalness: 0.1, emissive: '#3a0003'}), []);
  const strM = useMemo(() => new THREE.LineBasicMaterial({color: '#ddd'}), []);
  const geo = useMemo(() => new THREE.IcosahedronGeometry(0.24, 1), []);
  const str = useMemo(() => {
    const g = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, 1.0, 0)]);
    return new THREE.Line(g, strM);
  }, [strM]);
  return (
    <group position={[0, -0.3, 0]} rotation={[Math.PI + sway * 0.3, 0, sway]}>
      <primitive object={str} />
      <mesh geometry={geo} material={m} position={[0, 1.2, 0]} scale={[1, 1.18, 1]} castShadow />
    </group>
  );
};
