import {useEffect, useState} from 'react';
import {continueRender, delayRender, staticFile} from 'remotion';

/** Loads the bundled fonts (public/fonts) before any frame is captured. No network access. */
export const useFonts = () => {
  const [handle] = useState(() => delayRender('Loading fonts'));
  useEffect(() => {
    const fonts = [
      new FontFace('Anton', `url(${staticFile('fonts/Anton-Regular.ttf')})`),
      new FontFace('Bebas Neue', `url(${staticFile('fonts/BebasNeue-Regular.ttf')})`),
      new FontFace('Montserrat', `url(${staticFile('fonts/Montserrat.ttf')})`, {weight: '100 900'}),
    ];
    Promise.all(fonts.map((f) => f.load()))
      .then((loaded) => {
        loaded.forEach((f) => (document.fonts as unknown as {add: (x: FontFace) => void}).add(f));
        continueRender(handle);
      })
      .catch((e) => {
        console.error(e);
        continueRender(handle);
      });
  }, [handle]);
};
