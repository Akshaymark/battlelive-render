import React, {useMemo} from 'react';
import * as THREE from 'three';

export const WHEEL = {center: [0, 15, 0] as [number, number, number], radius: 12, cabins: 12};

const fm = (color: string, o: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
  new THREE.MeshStandardMaterial({color, flatShading: true, roughness: 0.7, ...o});

/** Position (world) of cabin i's pivot for a wheel angle. Cabins hang below the pivot. */
export const cabinPivot = (i: number, angle: number): [number, number, number] => {
  const a = angle + (i / WHEEL.cabins) * Math.PI * 2;
  return [WHEEL.center[0] + Math.sin(a) * WHEEL.radius, WHEEL.center[1] - Math.cos(a) * WHEEL.radius, WHEEL.center[2]];
};

export const CabinShell: React.FC<{lit?: number; color?: string; children?: React.ReactNode}> = ({lit = 0, color = '#8c2f39', children}) => {
  const M = useMemo(
    () => ({
      body: new THREE.MeshStandardMaterial({color, flatShading: true, roughness: 0.7, side: THREE.DoubleSide}),
      roof: fm('#2a2d38'),
      glass: new THREE.MeshStandardMaterial({color: '#9fb7d8', transparent: true, opacity: 0.18, roughness: 0.1, metalness: 0.3, depthWrite: false}),
      lamp: new THREE.MeshBasicMaterial({color: '#ffcf7a'}),
    }),
    [color],
  );
  return (
    <group>
      <group rotation={[0, Math.PI / 6, 0]}>
      <mesh material={M.roof} position={[0, 0.05, 0]} castShadow>
        <cylinderGeometry args={[0.9, 1.35, 0.35, 6]} />
      </mesh>
      {/* floor + lower walls (floor top at y=-2.45) */}
      <mesh material={M.body} position={[0, -2.55, 0]} castShadow receiveShadow>
        <cylinderGeometry args={[1.3, 1.2, 0.2, 6]} />
      </mesh>
      <mesh material={M.body} position={[0, -2.05, 0]} castShadow>
        <cylinderGeometry args={[1.3, 1.3, 0.8, 6, 1, true]} />
      </mesh>
      {/* glass upper walls */}
      <mesh material={M.glass} position={[0, -0.9, 0]}>
        <cylinderGeometry args={[1.3, 1.3, 1.5, 6, 1, true]} />
      </mesh>
      </group>
      {/* benches */}
      {[0.72, -0.72].map((z) => (
        <mesh key={z} material={M.roof} position={[0, -2.2, z]}>
          <boxGeometry args={[1.5, 0.5, 0.4]} />
        </mesh>
      ))}
      {/* six corner posts */}
      {Array.from({length: 6}).map((_, k) => {
        const a = (k / 6) * Math.PI * 2 + Math.PI / 6;
        return (
          <mesh key={k} material={M.roof} position={[Math.sin(a) * 1.3, -0.9, Math.cos(a) * 1.3]}>
            <boxGeometry args={[0.06, 1.5, 0.06]} />
          </mesh>
        );
      })}
      {lit > 0 ? (
        <mesh material={M.lamp} position={[0, -0.25, 0]} scale={lit}>
          <icosahedronGeometry args={[0.08, 0]} />
        </mesh>
      ) : null}
      <group position={[0, -2.45, 0]}>{children}</group>
    </group>
  );
};

/**
 * Low-poly ferris wheel. `angle` is supplied by the scene (integrated from a speed track so it is
 * deterministic and can stop/start). `renderCabin(i)` lets scenes seat characters inside cabins.
 */
export const FerrisWheel: React.FC<{
  angle: number;
  lights: number;
  renderCabin?: (i: number) => React.ReactNode;
  highlight?: number;
}> = ({angle, lights, renderCabin, highlight}) => {
  const M = useMemo(
    () => ({
      steel: fm('#3b4256', {metalness: 0.4, roughness: 0.5}),
      bulb: new THREE.MeshBasicMaterial({color: '#ffd38a'}),
      bulbRed: new THREE.MeshBasicMaterial({color: '#ff5a5a'}),
    }),
    [],
  );
  const {radius, cabins, center} = WHEEL;
  const spokes = 24;
  return (
    <group>
      {/* A-frame supports */}
      {[-1.6, 1.6].map((z) =>
        [-1, 1].map((side) => (
          <mesh key={`${z}${side}`} material={M.steel} position={[side * 4, center[1] / 2, z]} rotation={[0, 0, side * 0.26]} castShadow>
            <boxGeometry args={[0.45, center[1] + 1.2, 0.45]} />
          </mesh>
        )),
      )}
      <group position={center} rotation={[0, 0, angle]}>
        {/* hub */}
        <mesh material={M.steel} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[1.0, 1.0, 3.6, 8]} />
        </mesh>
        {[-1.4, 1.4].map((z) => (
          <group key={z} position={[0, 0, z]}>
            <mesh material={M.steel}>
              <torusGeometry args={[radius, 0.16, 4, 36]} />
            </mesh>
            <mesh material={M.steel}>
              <torusGeometry args={[radius * 0.62, 0.1, 4, 28]} />
            </mesh>
            {Array.from({length: spokes}).map((_, k) => {
              const a = (k / spokes) * Math.PI * 2;
              return (
                <mesh key={k} material={M.steel} position={[Math.sin(a) * radius / 2, Math.cos(a) * radius / 2, 0]} rotation={[0, 0, -a]}>
                  <boxGeometry args={[0.1, radius, 0.1]} />
                </mesh>
              );
            })}
            {/* rim bulbs */}
            {lights > 0.02
              ? Array.from({length: 36}).map((_, k) => {
                  const a = (k / 36) * Math.PI * 2;
                  return (
                    <mesh key={k} material={k % 3 === 0 ? M.bulbRed : M.bulb} position={[Math.sin(a) * (radius + 0.25), Math.cos(a) * (radius + 0.25), 0.2 * Math.sign(z)]} scale={lights}>
                      <icosahedronGeometry args={[0.13, 0]} />
                    </mesh>
                  );
                })
              : null}
          </group>
        ))}
      </group>
      {/* cabins hang upright: positioned at rim pivots, not rotated with the wheel */}
      {Array.from({length: cabins}).map((_, i) => {
        const p = cabinPivot(i, angle);
        const sway = Math.sin(angle * 3 + i) * 0.04;
        return (
          <group key={i} position={p} rotation={[0, 0, sway]}>
            <CabinShell lit={lights} color={i === highlight ? '#2f6d7a' : i % 2 ? '#8c2f39' : '#6b5a2a'}>
              {renderCabin ? renderCabin(i) : null}
            </CabinShell>
          </group>
        );
      })}
    </group>
  );
};
