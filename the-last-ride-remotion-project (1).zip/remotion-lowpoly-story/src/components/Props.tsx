import React, {useMemo} from 'react';
import * as THREE from 'three';
import {Park} from './Environment';

const fm = (color: string, o: Partial<THREE.MeshStandardMaterialParameters> = {}) =>
  new THREE.MeshStandardMaterial({color, flatShading: true, roughness: 0.85, ...o});

/** Draws a texture procedurally on a canvas (fonts are preloaded by FontLoader). */
const useCanvasTexture = (w: number, h: number, draw: (c: CanvasRenderingContext2D) => void, deps: unknown[]) =>
  useMemo(() => {
    const cv = document.createElement('canvas');
    cv.width = w;
    cv.height = h;
    const ctx = cv.getContext('2d')!;
    draw(ctx);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    return tex;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

/** Paper admission ticket: "ADMIT 2" although the hero came alone. */
export const Ticket: React.FC<{position?: [number, number, number]; rotation?: [number, number, number]; scale?: number}> = ({
  position = [0, 0, 0], rotation = [0, 0, 0], scale = 1,
}) => {
  const tex = useCanvasTexture(
    512, 256,
    (c) => {
      c.fillStyle = '#e8dcc0';
      c.fillRect(0, 0, 512, 256);
      c.strokeStyle = '#8a1a22';
      c.lineWidth = 8;
      c.strokeRect(14, 14, 484, 228);
      c.setLineDash([10, 10]);
      c.beginPath();
      c.moveTo(380, 20);
      c.lineTo(380, 236);
      c.stroke();
      c.setLineDash([]);
      c.fillStyle = '#8a1a22';
      c.font = '34px Montserrat';
      c.fillText('THE LAST RIDE', 40, 70);
      c.font = '96px Anton';
      c.fillText('ADMIT 2', 40, 185);
      c.font = '26px Montserrat';
      c.fillStyle = '#4a2a20';
      c.fillText('00:00', 400, 80);
      c.save();
      c.translate(445, 190);
      c.rotate(-Math.PI / 2);
      c.font = '30px Anton';
      c.fillText('No. 013', 0, 0);
      c.restore();
    },
    [],
  );
  const m = useMemo(() => new THREE.MeshStandardMaterial({map: tex, roughness: 0.9}), [tex]);
  return (
    <mesh position={position} rotation={rotation} scale={scale} material={m} castShadow>
      <planeGeometry args={[0.36, 0.18]} />
    </mesh>
  );
};

/** Instant photo held by the guard: the hero entering the park holding the girl's hand. */
export const Photograph: React.FC<{position?: [number, number, number]; rotation?: [number, number, number]; scale?: number}> = ({
  position = [0, 0, 0], rotation = [0, 0, 0], scale = 1,
}) => {
  const tex = useCanvasTexture(
    420, 500,
    (c) => {
      c.fillStyle = '#f1ece2';
      c.fillRect(0, 0, 420, 500);
      const g = c.createLinearGradient(0, 30, 0, 400);
      g.addColorStop(0, '#1b2238');
      g.addColorStop(1, '#4a3a2a');
      c.fillStyle = g;
      c.fillRect(25, 25, 370, 370);
      // gate arch
      c.fillStyle = '#5a1f27';
      c.fillRect(70, 120, 24, 240);
      c.fillRect(326, 120, 24, 240);
      c.fillRect(70, 105, 280, 30);
      c.strokeStyle = '#111';
      c.lineWidth = 3;
      for (let x = 100; x < 320; x += 18) {
        c.beginPath();
        c.moveTo(x, 150);
        c.lineTo(x, 360);
        c.stroke();
      }
      // ground
      c.fillStyle = '#2a2420';
      c.fillRect(25, 355, 370, 40);
      // man silhouette
      const fig = (x: number, h: number, col: string) => {
        c.fillStyle = col;
        c.beginPath();
        c.arc(x, 360 - h, h * 0.13, 0, Math.PI * 2);
        c.fill();
        c.beginPath();
        c.moveTo(x - h * 0.16, 360 - h * 0.85);
        c.lineTo(x + h * 0.16, 360 - h * 0.85);
        c.lineTo(x + h * 0.12, 360 - h * 0.4);
        c.lineTo(x - h * 0.12, 360 - h * 0.4);
        c.fill();
        c.fillRect(x - h * 0.1, 360 - h * 0.4, h * 0.07, h * 0.4);
        c.fillRect(x + h * 0.03, 360 - h * 0.4, h * 0.07, h * 0.4);
      };
      fig(190, 170, '#2f5d6b');
      fig(250, 105, '#e9e4da');
      c.strokeStyle = '#c9b8a0';
      c.lineWidth = 6;
      c.beginPath();
      c.moveTo(212, 255);
      c.lineTo(236, 290);
      c.stroke();
      // red balloon
      c.fillStyle = '#d4161f';
      c.beginPath();
      c.ellipse(272, 180, 18, 22, 0, 0, Math.PI * 2);
      c.fill();
      c.strokeStyle = '#ddd';
      c.lineWidth = 1.5;
      c.beginPath();
      c.moveTo(272, 202);
      c.lineTo(262, 290);
      c.stroke();
      // sepia wash
      c.fillStyle = 'rgba(120,80,30,0.18)';
      c.fillRect(25, 25, 370, 370);
      c.fillStyle = '#7a2020';
      c.font = '30px Anton';
      c.fillText('YESTERDAY  23:58', 40, 455);
    },
    [],
  );
  const m = useMemo(() => new THREE.MeshStandardMaterial({map: tex, roughness: 0.6}), [tex]);
  return (
    <mesh position={position} rotation={rotation} scale={scale} material={m} castShadow>
      <planeGeometry args={[0.21, 0.25]} />
    </mesh>
  );
};

/**
 * Interior of a ferris-wheel cabin, used for close/medium shots. The cabin is large enough to place
 * a camera inside. The park is rendered far below (elevation) so the windows show real depth.
 */
export const CabinInterior: React.FC<{
  elevation: number;
  sway: number;
  lights: number;
  t: number;
  children?: React.ReactNode;
  outside?: React.ReactNode;
}> = ({elevation, sway, lights, t, children, outside}) => {
  const M = useMemo(
    () => ({
      body: fm('#2f6d7a', {side: THREE.DoubleSide}),
      seat: fm('#5a2a2f'),
      frame: fm('#20232c', {metalness: 0.5, roughness: 0.5}),
      glass: new THREE.MeshStandardMaterial({color: '#a9c4e6', transparent: true, opacity: 0.12, roughness: 0.05, metalness: 0.6, depthWrite: false}),
      floor: fm('#1d1f26'),
    }),
    [],
  );
  const R = 1.8;
  return (
    <group>
      <group position={[0, -elevation, 0]}>
        <Park lights={lights} gatesOpen={0} crackle={0} t={t} />
      </group>
      {outside}
      <group rotation={[sway * 0.4, 0, sway]}>
        <group rotation={[0, Math.PI / 6, 0]}>
        <mesh material={M.floor} position={[0, -0.05, 0]} receiveShadow>
          <cylinderGeometry args={[R, R, 0.1, 6]} />
        </mesh>
        <mesh material={M.body} position={[0, 0.45, 0]} receiveShadow>
          <cylinderGeometry args={[R, R, 0.9, 6, 1, true]} />
        </mesh>
        <mesh material={M.glass} position={[0, 1.65, 0]}>
          <cylinderGeometry args={[R, R, 1.5, 6, 1, true]} />
        </mesh>
        <mesh material={M.frame} position={[0, 2.45, 0]}>
          <cylinderGeometry args={[R * 0.7, R, 0.2, 6]} />
        </mesh>
        {Array.from({length: 6}).map((_, k) => {
          const a = (k / 6) * Math.PI * 2;
          return (
            <mesh key={k} material={M.frame} position={[Math.sin(a) * R, 1.65, Math.cos(a) * R]}>
              <boxGeometry args={[0.07, 1.5, 0.07]} />
            </mesh>
          );
        })}
        </group>
        {[1, -1].map((s) => (
          <mesh key={s} material={M.seat} position={[0, 0.25, s * 1.1]} castShadow receiveShadow>
            <boxGeometry args={[2.0, 0.5, 0.5]} />
          </mesh>
        ))}
        {children}
      </group>
    </group>
  );
};
