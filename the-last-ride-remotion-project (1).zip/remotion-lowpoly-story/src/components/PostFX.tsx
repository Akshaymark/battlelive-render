import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';

/** Film look: vignette, deterministic animated grain, subtle colour wash. */
export const PostFX: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,0.72) 100%)'}} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(20,10,40,0.18), rgba(0,0,0,0) 30%, rgba(0,0,0,0) 70%, rgba(10,0,0,0.25))', mixBlendMode: 'multiply'}} />
      <svg width="100%" height="100%" style={{position: 'absolute', opacity: 0.11, mixBlendMode: 'overlay'}}>
        <filter id={`g${f % 8}`}>
          <feTurbulence type="fractalNoise" baseFrequency="0.85" numOctaves={2} seed={f % 8} />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter={`url(#g${f % 8})`} />
      </svg>
    </AbsoluteFill>
  );
};
