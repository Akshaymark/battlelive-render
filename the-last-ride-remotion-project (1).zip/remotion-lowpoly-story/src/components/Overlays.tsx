import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig, spring} from 'remotion';
import {OVERLAYS} from '../data/storyboard';
import {OverlaySpec} from '../data/types';
import {PALETTE} from '../config';

const fadeIO = (t: number, a: number, b: number, d = 0.3) =>
  interpolate(t, [a, a + d, b - d, b], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

/** Motion-graphic overlays: title, PA announcement, choice cards, call to action, end card. */
export const Overlays: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const portrait = height > width;
  const active = OVERLAYS.filter((o) => t >= o.from && t <= o.to);
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {active.map((o, i) => (
        <Overlay key={i} o={o} t={t} fps={fps} frame={frame} portrait={portrait} />
      ))}
    </AbsoluteFill>
  );
};

const Overlay: React.FC<{o: OverlaySpec; t: number; fps: number; frame: number; portrait: boolean}> = ({o, t, fps, frame, portrait}) => {
  const a = fadeIO(t, o.from, o.to);
  const s = spring({frame: frame - Math.round(o.from * fps), fps, config: {damping: 14, stiffness: 120}});
  if (o.type === 'title') {
    const spacing = interpolate(t, [o.from, o.to], [4, 16]);
    return (
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: a}}>
        <div style={{fontFamily: 'Bebas Neue', fontSize: portrait ? 150 : 200, whiteSpace: 'nowrap', color: PALETTE.red, letterSpacing: spacing, textShadow: '0 0 40px rgba(224,38,47,0.6), 0 8px 0 #000'}}>
          {o.text}
        </div>
        {o.sub ? (
          <div style={{fontFamily: 'Montserrat', fontWeight: 800, fontSize: 40, color: '#fff', letterSpacing: 12, marginTop: 10, opacity: s}}>{o.sub}</div>
        ) : null}
        <div style={{width: 520 * s, height: 6, background: PALETTE.red, marginTop: 24}} />
      </AbsoluteFill>
    );
  }
  if (o.type === 'announcement') {
    const bars = Array.from({length: 18}).map((_, k) => 14 + Math.abs(Math.sin(t * 13 + k * 0.9) * Math.sin(t * 5.1 + k)) * 60);
    return (
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'flex-end', paddingBottom: portrait ? 520 : 200, opacity: a}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 26, background: 'rgba(8,8,14,0.82)', border: `3px solid ${PALETTE.red}`, borderRadius: 26, padding: '22px 36px', transform: `scale(${0.8 + 0.2 * s})`}}>
          <div style={{width: 22, height: 22, borderRadius: 11, background: Math.sin(t * 12) > 0 ? PALETTE.red : '#5a0a10'}} />
          <div style={{fontFamily: 'Montserrat', fontWeight: 900, fontSize: 34, color: '#fff', letterSpacing: 6}}>{o.text}</div>
          <div style={{display: 'flex', gap: 5, alignItems: 'center', height: 80}}>
            {bars.map((h, k) => (
              <div key={k} style={{width: 7, height: h, background: '#fff', borderRadius: 4, opacity: 0.85}} />
            ))}
          </div>
        </div>
      </AbsoluteFill>
    );
  }
  if (o.type === 'choice') {
    const second = o.num === '2';
    return (
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'flex-start', paddingTop: (portrait ? 760 : 330) + (second ? (portrait ? 190 : 150) : 0), opacity: a}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 28, width: portrait ? 900 : 1100, background: 'rgba(10,10,16,0.86)', border: `4px solid ${second ? '#fff' : PALETTE.red}`, borderRadius: 30, padding: '24px 30px', transform: `translateX(${(1 - s) * (second ? 900 : -900)}px)`}}>
          <div style={{width: 110, height: 110, borderRadius: 55, background: second ? '#fff' : PALETTE.red, color: second ? '#111' : '#fff', fontFamily: 'Anton', fontSize: 72, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{o.num}</div>
          <div style={{fontFamily: 'Anton', fontSize: portrait ? 58 : 60, color: '#fff', lineHeight: 1.05}}>{o.text}</div>
        </div>
      </AbsoluteFill>
    );
  }
  if (o.type === 'cta') {
    const pulse = 1 + 0.04 * Math.sin(t * 7);
    return (
      <AbsoluteFill style={{alignItems: 'center', justifyContent: 'flex-start', paddingTop: portrait ? 520 : 150, opacity: a}}>
        <div style={{background: PALETTE.red, color: '#fff', fontFamily: 'Montserrat', fontWeight: 900, fontSize: portrait ? 56 : 52, letterSpacing: 4, padding: '26px 60px', borderRadius: 70, transform: `scale(${(0.6 + 0.4 * s) * pulse})`, boxShadow: '0 10px 40px rgba(224,38,47,0.5)'}}>
          {o.text}
        </div>
      </AbsoluteFill>
    );
  }
  // endcard
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', paddingTop: portrait ? 700 : 380, opacity: a}}>
      <div style={{fontFamily: 'Montserrat', fontWeight: 800, fontSize: 40, color: '#fff', letterSpacing: 10}}>{o.text}</div>
      {o.sub ? <div style={{fontFamily: 'Bebas Neue', fontSize: 170, color: PALETTE.red, letterSpacing: 14 * s, textShadow: '0 0 40px rgba(224,38,47,0.6)'}}>{o.sub}</div> : null}
    </AbsoluteFill>
  );
};
