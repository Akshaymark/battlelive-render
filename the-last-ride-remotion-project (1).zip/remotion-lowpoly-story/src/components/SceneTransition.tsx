import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';

/** Transition into a scene: fade from black, quick dip, white flash, or hard cut. */
export const SceneTransition: React.FC<{kind: 'cut' | 'fade' | 'flash' | 'dip'}> = ({kind}) => {
  const f = useCurrentFrame();
  if (kind === 'cut') return null;
  const len = kind === 'fade' ? 18 : kind === 'dip' ? 9 : 7;
  const o = interpolate(f, [0, len], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  if (o <= 0) return null;
  return <AbsoluteFill style={{background: kind === 'flash' ? '#fff8ee' : '#000', opacity: o}} />;
};
