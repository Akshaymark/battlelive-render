import transcript from './data/transcript.json';

export const FPS = 30;
/** Extra frames after the narration ends (end card hold). */
export const TAIL_SECONDS = 1.4;
export const DURATION_SECONDS = transcript.duration + TAIL_SECONDS;
export const DURATION_FRAMES = Math.ceil(DURATION_SECONDS * FPS);

export type Aspect = '9:16' | '16:9';
export const SIZES: Record<Aspect, {width: number; height: number}> = {
  '9:16': {width: 1080, height: 1920},
  '16:9': {width: 1920, height: 1080},
};

export const PALETTE = {
  night: '#0b1022',
  fog: '#141a33',
  moon: '#c9d6ff',
  warm: '#ffb45e',
  red: '#e0262f',
  accent: '#ff3b4a',
  caption: '#ffffff',
  captionDim: 'rgba(255,255,255,0.45)',
};
