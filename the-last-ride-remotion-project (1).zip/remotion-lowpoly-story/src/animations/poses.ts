import {Key, track, inRanges, noise1, clamp} from '../utils/anim';

/** Every animatable channel of a character. Values are radians / meters. */
export type Pose = {
  hipY: number; // pelvis height (standing 0.95, sitting 0.5)
  lean: number; // torso pitch forward
  torsoYaw: number;
  headYaw: number;
  headPitch: number;
  headRoll: number;
  thighL: number; thighR: number; kneeL: number; kneeR: number;
  armLFwd: number; armRFwd: number; armLOut: number; armROut: number; elbowL: number; elbowR: number;
  breathe: number;
  shiver: number;
};

export type Channel =
  | 'x' | 'y' | 'z' | 'rotY' | 'scale' | 'opacity'
  | 'headYaw' | 'headPitch' | 'headRoll' | 'lean' | 'torsoYaw'
  | 'armLFwd' | 'armRFwd' | 'armLOut' | 'armROut' | 'elbowL' | 'elbowR' | 'shiver';

export type Motion = {
  tracks?: Partial<Record<Channel, Key[]>>;
  /** time ranges during which the character walks (legs/arms cycle) */
  walk?: [number, number][];
  /** time ranges during which the character runs */
  run?: [number, number][];
  /** [[time, 0|1]] sitting amount; 1 = seated */
  sit?: Key[];
  /** subtle idle sway; 0 = statue (used for the motionless passengers) */
  idle?: number;
};

export const poseAt = (m: Motion, t: number, seed = 0): Pose => {
  const tr = m.tracks ?? {};
  const sit = clamp(track(m.sit, t, 0));
  const walking = inRanges(m.walk, t);
  const running = inRanges(m.run, t);
  const idle = m.idle ?? 1;
  const cyc = running ? t * 9 : t * 5.2;
  const amp = running ? 0.85 : walking ? 0.5 : 0;
  const s = Math.sin(cyc);
  const stand = 1 - sit;
  const legSwing = amp * s * stand;
  const p: Pose = {
    hipY: 0.95 * stand + 0.5 * sit + (amp ? Math.abs(Math.cos(cyc)) * 0.04 : 0),
    lean: track(tr.lean, t) + (running ? 0.25 : 0) + noise1(t * 0.6, seed) * 0.02 * idle,
    torsoYaw: track(tr.torsoYaw, t),
    headYaw: track(tr.headYaw, t) + noise1(t * 0.35, seed + 3) * 0.05 * idle,
    headPitch: track(tr.headPitch, t) + noise1(t * 0.3, seed + 5) * 0.03 * idle,
    headRoll: track(tr.headRoll, t),
    thighL: -legSwing - 1.5 * sit,
    thighR: legSwing - 1.5 * sit,
    kneeL: Math.max(0, Math.sin(cyc + 0.6)) * amp * 1.1 * stand + 1.5 * sit,
    kneeR: Math.max(0, Math.sin(cyc + Math.PI + 0.6)) * amp * 1.1 * stand + 1.5 * sit,
    armLFwd: track(tr.armLFwd, t) + legSwing * 0.8,
    armRFwd: track(tr.armRFwd, t) - legSwing * 0.8,
    armLOut: track(tr.armLOut, t) + 0.08,
    armROut: track(tr.armROut, t) + 0.08,
    elbowL: track(tr.elbowL, t) + (amp ? 0.5 : 0.15) + sit * 0.6,
    elbowR: track(tr.elbowR, t) + (amp ? 0.5 : 0.15) + sit * 0.6,
    breathe: Math.sin(t * 2.1 + seed) * 0.012 * idle,
    shiver: track(tr.shiver, t),
  };
  if (sit > 0.5) {
    // hands rest on the knees when seated
    p.armLFwd += -0.55 * sit;
    p.armRFwd += -0.55 * sit;
  }
  return p;
};
