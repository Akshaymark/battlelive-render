/** Facial expression presets. Faces are procedural geometry: brows, eyes, pupils and a mouth
 *  whose shape (curve, width, openness) is blended between presets over time. */
export type Expression =
  | 'neutral' | 'fear' | 'surprise' | 'sad' | 'happy' | 'angry' | 'confused' | 'creepy' | 'blank';

export type Face = {
  browY: number; // brow height offset
  browAngle: number; // >0 inner ends up (worry), <0 inner ends down (anger)
  browTilt: number; // asymmetric tilt for confusion
  eyeScale: number; // eye opening
  pupil: number; // pupil size
  mouthOpen: number; // 0..1 base openness
  mouthCurve: number; // + smile, - frown
  mouthWidth: number;
};

export const FACES: Record<Expression, Face> = {
  neutral: {browY: 0, browAngle: 0, browTilt: 0, eyeScale: 1, pupil: 1, mouthOpen: 0, mouthCurve: 0, mouthWidth: 1},
  fear: {browY: 0.012, browAngle: 0.45, browTilt: 0, eyeScale: 1.35, pupil: 0.7, mouthOpen: 0.45, mouthCurve: -0.6, mouthWidth: 1.1},
  surprise: {browY: 0.02, browAngle: 0.1, browTilt: 0, eyeScale: 1.45, pupil: 0.8, mouthOpen: 0.8, mouthCurve: 0, mouthWidth: 0.8},
  sad: {browY: -0.004, browAngle: 0.5, browTilt: 0, eyeScale: 0.8, pupil: 1, mouthOpen: 0, mouthCurve: -0.8, mouthWidth: 0.9},
  happy: {browY: 0.006, browAngle: -0.05, browTilt: 0, eyeScale: 0.9, pupil: 1, mouthOpen: 0.1, mouthCurve: 1, mouthWidth: 1.2},
  angry: {browY: -0.01, browAngle: -0.55, browTilt: 0, eyeScale: 0.85, pupil: 0.9, mouthOpen: 0.05, mouthCurve: -0.5, mouthWidth: 1},
  confused: {browY: 0.004, browAngle: 0.1, browTilt: 0.35, eyeScale: 1.05, pupil: 1, mouthOpen: 0.05, mouthCurve: -0.25, mouthWidth: 0.8},
  creepy: {browY: -0.006, browAngle: -0.15, browTilt: 0, eyeScale: 1.2, pupil: 0.45, mouthOpen: 0, mouthCurve: 0.9, mouthWidth: 1.35},
  blank: {browY: 0, browAngle: 0, browTilt: 0, eyeScale: 1.15, pupil: 0.35, mouthOpen: 0, mouthCurve: 0, mouthWidth: 0.7},
};

const keys = Object.keys(FACES.neutral) as (keyof Face)[];

/** Expression timeline: [[time, expression], ...]; blends over `blend` seconds at each change. */
export const faceAt = (timeline: [number, Expression][] | undefined, t: number, blend = 0.35): Face => {
  if (!timeline || timeline.length === 0) return FACES.neutral;
  let cur: Expression = timeline[0][1];
  let prev: Expression = cur;
  let since = 99;
  for (const [at, e] of timeline) {
    if (t >= at) {
      prev = cur;
      cur = e;
      since = t - at;
    }
  }
  const k = Math.min(1, since / blend);
  const a = FACES[prev];
  const b = FACES[cur];
  const out = {} as Face;
  for (const key of keys) out[key] = a[key] + (b[key] - a[key]) * k;
  return out;
};
