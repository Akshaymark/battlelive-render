import {Key, V3} from '../utils/anim';
import {Motion} from '../animations/poses';
import {Expression} from '../animations/expressions';
import {CharacterKind} from '../components/Character';

/** Where an actor lives: the world, inside an exterior wheel cabin, the cabin-interior set,
 *  or the "opposite cabin" seen through the window of the interior set. */
export type Place = 'world' | {cabin: number} | 'interior' | 'opposite';

export type ActorSpec = {
  id: string;
  kind: CharacterKind;
  variant?: number;
  place: Place;
  pos: V3;
  rotY?: number;
  motion?: Motion;
  faces?: [number, Expression][];
  /** time ranges in which the actor speaks; lip-sync uses the real word timestamps */
  talk?: [number, number][];
  balloon?: boolean;
  /** visibility windows (absolute seconds); omitted = whole scene */
  visible?: [number, number][];
  opacity?: number;
  scale?: number;
};

export type CamKey = {
  t: number; // absolute seconds
  pos: V3;
  target: V3;
  fov?: number; // vertical FOV for the 9:16 frame (auto-adapted for 16:9)
  roll?: number;
  /** pos/target are relative to this exterior cabin's pivot (tracking shots) */
  followCabin?: number;
};

export type PropSpec =
  | {type: 'ticket'; pos: V3; rot: V3; scale?: number; visible?: [number, number]}
  | {type: 'photo'; pos: V3; rot: V3; scale?: number; visible?: [number, number]};

export type OverlaySpec =
  | {type: 'title'; from: number; to: number; text: string; sub?: string}
  | {type: 'announcement'; from: number; to: number; text: string}
  | {type: 'choice'; from: number; to: number; num: string; text: string}
  | {type: 'cta'; from: number; to: number; text: string}
  | {type: 'endcard'; from: number; to: number; text: string; sub?: string};

export type SetKind = 'park' | 'interior';

export type Mood = {
  background: string;
  fog: [number, number];
  ambient: number;
  moon: number;
  /** extra coloured key light, e.g. red emergency glow */
  accent?: {color: string; intensity: number; pos: V3};
};

export type SceneSpec = {
  id: string;
  /** human-readable storyboard description of the beat */
  beat: string;
  from: number;
  to: number;
  set: SetKind;
  /** interior set: height of the cabin above the ground */
  elevation?: number;
  camera: CamKey[];
  handheld?: number;
  actors: ActorSpec[];
  props?: PropSpec[];
  caption: 'top' | 'bottom';
  transition: 'cut' | 'fade' | 'flash' | 'dip';
  mood: Mood;
  /** show the girl's cabin across from the interior set */
  oppositeCabin?: boolean;
  /** highlight one exterior cabin (the hero's) */
  highlightCabin?: number;
};

export type GlobalTracks = {
  wheelSpeed: Key[]; // radians / second
  lights: Key[]; // 0..1 park lights
  gates: Key[]; // 0..1 gate opening
  crackle: Key[]; // 0..1 loudspeaker activity
};
