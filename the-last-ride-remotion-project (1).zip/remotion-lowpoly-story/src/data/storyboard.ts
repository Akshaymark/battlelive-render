/**
 * STORYBOARD — "The Last Ride"
 * Every time below is in seconds on the narration timeline and was taken from the word-level
 * alignment in transcript.json (see scripts/). Edit beats, cameras, actors or expressions here;
 * the scene renderer (src/scenes/StoryScene.tsx) draws whatever this file describes.
 */
import {ActorSpec, GlobalTracks, Mood, OverlaySpec, SceneSpec} from './types';
import {Expression} from '../animations/expressions';

const PI = Math.PI;
export const HERO_CABIN = 10;
export const GIRL_CABIN = 4;

/** Park-wide state over time: wheel speed, lights, gates, loudspeaker. */
export const GLOBAL: GlobalTracks = {
  wheelSpeed: [[0, 0.07], [60.4, 0.07], [61.6, 0], [100.4, 0], [101.4, 0.07], [200, 0.07]],
  lights: [[0, 0.15], [73.7, 0.15], [74.0, 1], [200, 1]],
  gates: [[0, 0], [75.4, 0], [76.6, 1], [200, 1]],
  crackle: [[0, 0], [47.0, 0], [47.3, 1], [53.6, 1], [54.0, 0], [200, 0]],
};

const NIGHT: Mood = {background: '#0b1022', fog: [30, 150], ambient: 0.32, moon: 1.3};
const CABIN: Mood = {background: '#0b1022', fog: [25, 170], ambient: 0.5, moon: 1.0};
const DREAD: Mood = {...CABIN, ambient: 0.35, accent: {color: '#ff2a3a', intensity: 6, pos: [1.2, 2.2, -1.0]}};
const LIT: Mood = {background: '#121836', fog: [30, 160], ambient: 0.45, moon: 1.1};

const seated = {sit: [[0, 1]] as [number, number][]};

/** Motionless passengers in every exterior cabin except the hero's and the girl's. */
const passengers = (opts: {from?: number; turnAt?: number; only?: number[]} = {}): ActorSpec[] => {
  const out: ActorSpec[] = [];
  for (let i = 0; i < 12; i++) {
    if (i === HERO_CABIN || i === GIRL_CABIN) continue;
    if (opts.only && !opts.only.includes(i)) continue;
    const n = i % 3 === 0 ? 1 : 2;
    for (let k = 0; k < n; k++) {
      const x = n === 1 ? 0 : k === 0 ? -0.36 : 0.36;
      const side = k === 0 ? 1 : -1;
      const turn = opts.turnAt;
      out.push({
        id: `p${i}-${k}`,
        kind: 'passenger',
        variant: i + k,
        place: {cabin: i},
        pos: [x, 0, -0.72],
        rotY: 0,
        motion: {
          ...seated,
          idle: 0,
          tracks: turn
            ? {rotY: [[turn, 1.25 * side], [turn + 0.7, 0]], headYaw: [[turn, 0.5 * side], [turn + 0.9, 0]]}
            : undefined,
        },
        faces: [[0, 'blank' as Expression]],
      });
    }
  }
  return out;
};

const girlIn = (place: ActorSpec['place'], pos: [number, number, number], rotY: number, extra: Partial<ActorSpec> = {}): ActorSpec => ({
  id: 'girl',
  kind: 'girl',
  place,
  pos,
  rotY,
  balloon: true,
  motion: {...seated, idle: 0.3},
  faces: [[0, 'blank']],
  ...extra,
});

export const SCENES: SceneSpec[] = [
  {
    id: 's01-establish',
    beat: 'Title. Crane down over the locked, empty park at midnight to the lone hero on the path.',
    from: 0, to: 7.6, set: 'park', caption: 'bottom', transition: 'fade', mood: NIGHT,
    camera: [
      {t: 0, pos: [0, 26, 78], target: [0, 10, 10], fov: 52},
      {t: 7.6, pos: [3, 2.2, 30.5], target: [0, 1.5, 34], fov: 42},
    ],
    actors: [
      {
        id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 34], rotY: PI,
        motion: {tracks: {headYaw: [[2.4, 0], [3.4, 0.8], [4.8, -0.8], [6.0, 0]], headPitch: [[6.3, 0], [6.9, -0.25]]}},
        faces: [[0, 'neutral'], [6.3, 'confused']],
      },
      ...passengers(),
      girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0),
    ],
  },
  {
    id: 's02-locked',
    beat: 'He turns to the locked gates, then sweeps the dead rides. "Except one" — he looks up.',
    from: 7.6, to: 12.9, set: 'park', caption: 'bottom', transition: 'cut', mood: NIGHT, handheld: 0.4,
    camera: [
      {t: 7.6, pos: [1.2, 1.8, 31], target: [0, 1.8, 38], fov: 42},
      {t: 9.0, pos: [1.0, 1.8, 31.8], target: [0, 1.9, 38], fov: 40},
      {t: 9.5, pos: [-1, 3, 35], target: [18, 2, -4], fov: 40},
      {t: 10.7, pos: [-1, 3, 35], target: [-14, 2, 18], fov: 40},
      {t: 11.5, pos: [0.6, 1.75, 32.3], target: [0, 1.65, 34], fov: 34},
      {t: 12.9, pos: [0.4, 1.7, 32.8], target: [0, 1.75, 34], fov: 30},
    ],
    actors: [
      {
        id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 34],
        motion: {
          tracks: {
            rotY: [[7.6, PI], [8.2, 0], [9.1, 0], [9.8, PI]],
            armRFwd: [[8.3, 0], [8.6, -1.2], [9.0, 0]],
            headYaw: [[9.8, 0], [10.4, 0.7], [11.0, -0.7], [11.6, 0]],
            headPitch: [[11.5, 0], [12.0, -0.45]],
          },
        },
        faces: [[0, 'confused'], [8.4, 'sad'], [11.56, 'surprise']],
      },
    ],
  },
  {
    id: 's03-wheel',
    beat: 'Low hero shot of the ferris wheel, still turning, faint bulbs. Orbiting camera.',
    from: 12.9, to: 15.8, set: 'park', caption: 'top', transition: 'cut', mood: NIGHT,
    camera: [
      {t: 12.9, pos: [13, 1.5, 22], target: [0, 15, 0], fov: 55},
      {t: 15.8, pos: [-9, 2, 23], target: [0, 14, 0], fov: 52},
    ],
    actors: [...passengers(), girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0)],
  },
  {
    id: 's04a-board',
    beat: 'He walks to the bottom cabin and climbs inside.',
    from: 15.8, to: 17.6, set: 'park', caption: 'top', transition: 'cut', mood: NIGHT,
    camera: [
      {t: 15.8, pos: [5, 2.5, 11], target: [-0.5, 1.8, 3], fov: 45},
      {t: 17.6, pos: [4, 2.2, 8], target: [-0.6, 1.5, 1.5], fov: 42},
    ],
    actors: [
      {
        id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 0], rotY: PI,
        motion: {walk: [[15.9, 16.95]], tracks: {x: [[15.9, 0], [17.0, -0.6]], z: [[15.9, 8], [17.0, 2.2], [17.5, 1.0]], y: [[17.0, 0], [17.4, 0.55]], armRFwd: [[17.0, 0], [17.2, -1.6]]}},
        faces: [[0, 'neutral']],
      },
      ...passengers(),
      girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0),
    ],
  },
  {
    id: 's04b-rise',
    beat: 'Tracking shot rising with his cabin; he notices every other cabin is occupied.',
    from: 17.6, to: 22.8, set: 'park', caption: 'bottom', transition: 'cut', mood: NIGHT, highlightCabin: HERO_CABIN,
    camera: [
      {t: 17.6, pos: [2.5, -0.8, 6], target: [0, -1.4, 0], fov: 45, followCabin: HERO_CABIN},
      {t: 20.0, pos: [3, 0.5, 9], target: [-3, -0.5, 0], fov: 48, followCabin: HERO_CABIN},
      {t: 22.8, pos: [3, 1.5, 10.5], target: [-7, 1.5, 0], fov: 52, followCabin: HERO_CABIN},
    ],
    actors: [
      {
        id: 'hero', kind: 'hero', place: {cabin: HERO_CABIN}, pos: [-0.3, 0, -0.72], rotY: 0,
        motion: {...seated, tracks: {headYaw: [[19.5, 0], [20.4, 1.0], [21.6, 1.1]], headPitch: [[20.4, 0], [21.0, -0.2]]}},
        faces: [[0, 'neutral'], [20.3, 'confused'], [21.4, 'fear']],
      },
      ...passengers(),
      girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0),
    ],
  },
  {
    id: 's05-still',
    beat: 'Close on the passengers: completely still, not blinking. Slow push to one blank face.',
    from: 22.8, to: 28.2, set: 'park', caption: 'top', transition: 'dip', mood: {...NIGHT, ambient: 0.45},
    camera: [
      {t: 22.8, pos: [0.3, -0.9, 3.6], target: [0, -1.1, -0.72], fov: 40, followCabin: 9},
      {t: 25.3, pos: [0.3, -0.95, 2.8], target: [0.1, -1.05, -0.72], fov: 36, followCabin: 9},
      {t: 28.2, pos: [0.36, -1.0, 1.6], target: [0.36, -1.03, -0.72], fov: 28, followCabin: 9},
    ],
    actors: [...passengers({only: [8, 9, 11]})],
  },
  {
    id: 's06-girl',
    beat: 'Over his shoulder, through the glass: the girl with the red balloon in the cabin opposite, staring.',
    from: 28.2, to: 35.5, set: 'interior', elevation: 7, caption: 'bottom', transition: 'cut', mood: CABIN, oppositeCabin: true, handheld: 0.25,
    camera: [
      {t: 28.2, pos: [0.35, 1.75, 1.65], target: [0, 1.2, -9.7], fov: 42},
      {t: 31.2, pos: [0.25, 1.6, 1.5], target: [0.05, 1.0, -9.7], fov: 22},
      {t: 33.6, pos: [0.15, 1.5, 1.3], target: [0.05, 1.0, -9.7], fov: 13},
      {t: 35.5, pos: [0.12, 1.5, 1.25], target: [0.05, 1.0, -9.7], fov: 11},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'interior', pos: [-0.35, 0, 1.1], rotY: PI, motion: seated, faces: [[0, 'neutral'], [31.3, 'confused'], [33.6, 'fear']]},
      girlIn('opposite', [0, 0, -0.72], 0, {motion: {...seated, idle: 0, tracks: {headPitch: [[0, 0.05]]}}, faces: [[0, 'blank'], [33.5, 'creepy']]}),
    ],
  },
  {
    id: 's07-point',
    beat: 'Close on the girl. She slowly raises her arm and points behind him.',
    from: 35.5, to: 37.7, set: 'interior', elevation: 9, caption: 'top', transition: 'cut', mood: DREAD, oppositeCabin: true,
    camera: [
      {t: 35.5, pos: [0.2, 1.25, -8.35], target: [0, 1.1, -9.72], fov: 38},
      {t: 37.7, pos: [0.3, 1.2, -8.15], target: [0, 1.15, -9.72], fov: 44},
    ],
    actors: [
      girlIn('opposite', [0, 0, -0.72], 0, {
        motion: {...seated, idle: 0, tracks: {armRFwd: [[36.0, 0], [36.6, -0.95]], elbowR: [[36.0, 0], [36.6, -0.75]], armROut: [[36.0, 0], [36.6, -0.15]], headPitch: [[36.0, 0.05], [36.6, -0.05]]}},
        faces: [[0, 'blank']],
      }),
    ],
  },
  {
    id: 's08-turn',
    beat: 'He spins around in fear — then the camera finds the empty seat beside him. Nobody.',
    from: 37.7, to: 41.4, set: 'interior', elevation: 11, caption: 'top', transition: 'flash', mood: CABIN, handheld: 0.6,
    camera: [
      {t: 37.7, pos: [-0.2, 1.5, 0.1], target: [-0.35, 1.4, 1.1], fov: 46},
      {t: 39.6, pos: [-0.25, 1.5, 0.15], target: [-0.35, 1.4, 1.1], fov: 44},
      {t: 40.2, pos: [0.5, 1.35, 0.2], target: [0.45, 0.8, 1.1], fov: 40},
      {t: 41.4, pos: [0.5, 1.3, 0.3], target: [0.45, 0.85, 1.1], fov: 36},
    ],
    actors: [
      {
        id: 'hero', kind: 'hero', place: 'interior', pos: [-0.35, 0, 1.1], rotY: PI,
        motion: {...seated, tracks: {headYaw: [[38.2, 0], [38.6, 1.4]], torsoYaw: [[38.2, 0], [38.6, 0.5]], shiver: [[38.6, 0], [39.0, 1]]}},
        faces: [[0, 'surprise'], [38.4, 'fear']],
      },
    ],
  },
  {
    id: 's09-reflection',
    beat: 'He looks at the glass: in the reflection, a dark man is sitting beside him. Push in.',
    from: 41.4, to: 47.0, set: 'interior', elevation: 14, caption: 'bottom', transition: 'cut', mood: DREAD,
    camera: [
      {t: 41.4, pos: [0.15, 1.65, 1.75], target: [0, 1.35, -4.2], fov: 34},
      {t: 44.0, pos: [0.1, 1.6, 1.5], target: [0, 1.35, -4.2], fov: 30},
      {t: 46.0, pos: [0.05, 1.55, 0.9], target: [0.2, 1.4, -4.2], fov: 26},
      {t: 47.0, pos: [0.05, 1.55, 0.85], target: [0.2, 1.4, -4.2], fov: 25},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'interior', pos: [-0.35, 0, 1.1], rotY: PI, motion: seated, faces: [[0, 'fear']]},
      // reflections live "behind" the glass, mirrored, faint
      {id: 'hero-refl', kind: 'hero', place: 'interior', pos: [-0.35, 0, -4.22], rotY: 0, opacity: 0.3, motion: {...seated, tracks: {headYaw: [[44.2, 0], [45.0, -0.4]]}}, faces: [[0, 'fear']]},
      {
        id: 'ghost', kind: 'ghost', place: 'interior', pos: [0.45, 0, -4.22], rotY: 0, opacity: 0.42, visible: [[44.1, 47.0]],
        motion: {...seated, idle: 0, tracks: {headYaw: [[44.1, 0.5], [45.4, 0.5], [46.2, 0]]}},
        faces: [[0, 'blank']],
      },
    ],
  },
  {
    id: 's10-speakers',
    beat: 'Exterior: the loudspeakers crackle to life. "The park is closing..." Pull back to the wheel.',
    from: 47.0, to: 54.5, set: 'park', caption: 'top', transition: 'cut', mood: NIGHT, handheld: 0.3,
    camera: [
      {t: 47.0, pos: [10.5, 2.2, 31.5], target: [6.5, 5.8, 24], fov: 40},
      {t: 49.4, pos: [10.0, 2.6, 30.5], target: [6.5, 5.7, 24], fov: 36},
      {t: 54.5, pos: [16, 6, 36], target: [0, 12, 0], fov: 50},
    ],
    actors: [...passengers(), girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0)],
    highlightCabin: HERO_CABIN,
  },
  {
    id: 's11-ticket',
    beat: 'He looks down: a ticket on his lap reads ADMIT 2. He came alone.',
    from: 54.5, to: 60.4, set: 'interior', elevation: 24, caption: 'top', transition: 'cut', mood: CABIN,
    camera: [
      {t: 54.5, pos: [-0.35, 1.55, 0.6], target: [-0.35, 0.6, 0.9], fov: 46},
      {t: 56.3, pos: [-0.33, 1.3, 0.5], target: [-0.35, 0.62, 0.86], fov: 38},
      {t: 60.4, pos: [-0.33, 1.2, 0.55], target: [-0.35, 0.62, 0.86], fov: 34},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'interior', pos: [-0.35, 0, 1.1], rotY: PI, motion: {...seated, tracks: {headPitch: [[54.6, 0], [55.3, 0.6]], armLFwd: [[56.5, 0], [57.2, -0.25]]}}, faces: [[0, 'confused'], [58.4, 'fear']]},
    ],
    props: [{type: 'ticket', pos: [-0.35, 0.62, 0.84], rot: [-PI / 2, 0, PI], scale: 0.85}],
  },
  {
    id: 's12-stop',
    beat: 'Wide: the ferris wheel grinds to a halt. Bulbs flicker.',
    from: 60.4, to: 62.7, set: 'park', caption: 'top', transition: 'dip', mood: NIGHT,
    camera: [
      {t: 60.4, pos: [0, 9, 46], target: [0, 13, 0], fov: 48},
      {t: 62.7, pos: [0, 9.5, 41], target: [0, 13.5, 0], fov: 48},
    ],
    actors: [...passengers(), girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0)],
    highlightCabin: HERO_CABIN,
  },
  {
    id: 's13-turn',
    beat: 'Every passenger turns, in unison, to stare straight at him (at camera).',
    from: 62.7, to: 66.0, set: 'park', caption: 'top', transition: 'cut', mood: {...NIGHT, ambient: 0.45},
    camera: [
      {t: 62.7, pos: [0, -0.9, 4.0], target: [0, -1.1, -0.72], fov: 42, followCabin: 9},
      {t: 66.0, pos: [0, -1.0, 2.6], target: [0, -1.05, -0.72], fov: 38, followCabin: 9},
    ],
    actors: [...passengers({only: [8, 9, 11], turnAt: 63.6})],
  },
  {
    id: 's14-beside',
    beat: 'Back inside: the girl is suddenly sitting right beside him. He recoils.',
    from: 66.0, to: 68.9, set: 'interior', elevation: 26, caption: 'top', transition: 'flash', mood: DREAD, handheld: 0.5,
    camera: [
      {t: 66.0, pos: [0.05, 1.3, -1.1], target: [0.05, 1.05, 1.1], fov: 52},
      {t: 68.9, pos: [0.05, 1.28, -0.8], target: [0.05, 1.05, 1.1], fov: 48},
    ],
    actors: [
      {
        id: 'hero', kind: 'hero', place: 'interior', pos: [-0.35, 0, 1.1], rotY: PI,
        motion: {...seated, tracks: {headYaw: [[67.0, 0], [67.4, 0.9]], lean: [[67.2, 0], [67.6, -0.15]], x: [[67.2, -0.35], [67.6, -0.6]], shiver: [[67.4, 0], [67.8, 1]]}},
        faces: [[0, 'confused'], [66.8, 'surprise'], [67.6, 'fear']],
      },
      girlIn('interior', [0.4, 0, 1.1], PI, {visible: [[66.6, 68.9]], faces: [[0, 'creepy']], motion: {...seated, idle: 0, tracks: {headYaw: [[66.6, -0.6]]}}}),
    ],
  },
  {
    id: 's15-whisper',
    beat: 'Close-up: she leans in and whispers. Lips synced to the words.',
    from: 68.9, to: 73.3, set: 'interior', elevation: 26, caption: 'bottom', transition: 'cut', mood: DREAD,
    camera: [
      {t: 68.9, pos: [0.05, 1.12, 0.0], target: [0.3, 1.0, 1.1], fov: 46},
      {t: 73.3, pos: [0.15, 1.1, 0.2], target: [0.35, 1.0, 1.1], fov: 38},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'interior', pos: [-0.6, 0, 1.1], rotY: PI, motion: {...seated, tracks: {headYaw: [[0, 0.9]], shiver: [[0, 1]]}}, faces: [[0, 'fear']]},
      girlIn('interior', [0.4, 0, 1.1], PI, {
        talk: [[70.5, 72.1]],
        faces: [[0, 'creepy'], [70.4, 'blank']],
        motion: {...seated, idle: 0, tracks: {headYaw: [[69.2, -0.2], [69.8, 0.6]], lean: [[69.2, 0], [69.8, 0.12]], headRoll: [[69.8, 0], [70.4, 0.15]]}},
      }),
    ],
  },
  {
    id: 's16-lights',
    beat: 'The park lights slam on. The gates swing open.',
    from: 73.3, to: 76.8, set: 'park', caption: 'top', transition: 'flash', mood: LIT,
    camera: [
      {t: 73.3, pos: [-3, 1.4, 29], target: [0, 3, 38], fov: 52},
      {t: 76.8, pos: [-2.5, 1.6, 31], target: [0, 2.6, 38], fov: 48},
    ],
    actors: [{id: 'hero', kind: 'hero', place: 'world', pos: [0.4, 0, 33], rotY: 0, motion: {tracks: {headPitch: [[73.4, 0], [73.9, -0.2], [75.0, 0]]}}, faces: [[0, 'surprise'], [75.6, 'confused']]}],
  },
  {
    id: 's17-exit',
    beat: 'Tracking shot: he walks out through the gates where a security guard is waiting.',
    from: 76.8, to: 80.6, set: 'park', caption: 'top', transition: 'cut', mood: LIT,
    camera: [
      {t: 76.8, pos: [-2.8, 1.7, 31], target: [0, 1.5, 35], fov: 46},
      {t: 79.3, pos: [-3.2, 1.8, 37.5], target: [0.3, 1.8, 42], fov: 44},
      {t: 80.6, pos: [-3.0, 1.8, 38], target: [0.3, 1.9, 42], fov: 40},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 33], rotY: 0, motion: {walk: [[76.9, 79.2]], tracks: {z: [[76.9, 33], [79.2, 40.5]]}}, faces: [[0, 'neutral'], [78.6, 'surprise']]},
      {id: 'guard', kind: 'guard', place: 'world', pos: [0.3, 0, 42.2], rotY: PI, motion: {tracks: {armLFwd: [[0, -0.2]], elbowL: [[0, 1.2]], armRFwd: [[0, -0.2]], elbowR: [[0, 1.2]]}}, faces: [[0, 'blank']]},
    ],
  },
  {
    id: 's18-question',
    beat: 'Over-the-shoulder dialogue: "Sir, who did you come here with?" — reverse — "Nobody."',
    from: 80.6, to: 87.0, set: 'park', caption: 'top', transition: 'cut', mood: LIT,
    camera: [
      {t: 80.6, pos: [-0.6, 1.8, 39.0], target: [0.3, 1.9, 42.2], fov: 38},
      {t: 84.8, pos: [-0.5, 1.8, 39.4], target: [0.3, 1.95, 42.2], fov: 32},
      {t: 85.0, pos: [0.9, 1.95, 43.5], target: [0, 1.6, 40.5], fov: 36},
      {t: 87.0, pos: [0.8, 1.9, 43.2], target: [0, 1.62, 40.5], fov: 30},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 40.5], rotY: 0, talk: [[85.6, 86.2]], motion: {tracks: {headYaw: [[85.5, 0], [86.2, -0.15]]}}, faces: [[0, 'confused'], [85.5, 'sad']]},
      {id: 'guard', kind: 'guard', place: 'world', pos: [0.3, 0, 42.2], rotY: PI, talk: [[81.1, 84.2]], motion: {tracks: {headPitch: [[0, 0.1]], armRFwd: [[82.4, 0], [82.8, -0.6], [84.2, 0]]}}, faces: [[0, 'neutral'], [84.3, 'confused']]},
    ],
  },
  {
    id: 's19-photo',
    beat: 'He shows a photograph. Push in: it is the hero, entering the park, holding a little girl\'s hand.',
    from: 87.0, to: 94.0, set: 'park', caption: 'top', transition: 'cut', mood: LIT,
    camera: [
      {t: 87.0, pos: [-0.6, 1.8, 39.1], target: [0.3, 1.6, 42.2], fov: 38},
      {t: 88.4, pos: [0.15, 1.42, 40.75], target: [0.15, 1.36, 41.4], fov: 34},
      {t: 94.0, pos: [0.15, 1.38, 40.92], target: [0.15, 1.36, 41.4], fov: 30},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 40.5], rotY: 0, faces: [[0, 'confused'], [89.5, 'fear']]},
      {id: 'guard', kind: 'guard', place: 'world', pos: [0.3, 0, 42.2], rotY: PI, motion: {tracks: {armRFwd: [[87.3, 0], [87.9, -1.3]], elbowR: [[87.3, 0.2], [87.9, 0.4]]}}, faces: [[0, 'blank']]},
    ],
    props: [{type: 'photo', pos: [0.15, 1.36, 41.4], rot: [0, PI, 0], scale: 1, visible: [87.7, 94.0]}],
  },
  {
    id: 's20-yesterday',
    beat: 'Low close-up of the guard leaning in: "Sir... you were here yesterday too."',
    from: 94.0, to: 99.3, set: 'park', caption: 'bottom', transition: 'cut', mood: {...LIT, accent: {color: '#ff2a3a', intensity: 3, pos: [1.5, 3, 40]}},
    camera: [
      {t: 94.0, pos: [0.0, 1.85, 40.9], target: [0.3, 2.0, 42.2], fov: 38},
      {t: 99.3, pos: [0.05, 1.9, 41.25], target: [0.3, 2.0, 42.2], fov: 32},
    ],
    actors: [
      {id: 'guard', kind: 'guard', place: 'world', pos: [0.3, 0, 42.2], rotY: PI, talk: [[95.8, 96.4], [96.9, 98.5]], motion: {tracks: {lean: [[94.3, 0], [95.2, 0.22]], headRoll: [[95.2, 0], [96.0, -0.08]]}}, faces: [[0, 'blank'], [96.9, 'sad']]},
    ],
  },
  {
    id: 's21-lookback',
    beat: 'He turns and looks back at the wheel. His cabin, alone, is moving again. Long-lens push.',
    from: 99.3, to: 103.0, set: 'park', caption: 'top', transition: 'cut', mood: LIT, highlightCabin: HERO_CABIN,
    camera: [
      {t: 99.3, pos: [0.8, 1.8, 43.6], target: [0, 2, 38], fov: 40},
      {t: 100.6, pos: [0.8, 1.9, 43.6], target: [0, 12, 0], fov: 34},
      {t: 103.0, pos: [0.8, 1.9, 43.6], target: [-0.8, 24.5, 0], fov: 12},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 40.5], motion: {tracks: {rotY: [[99.4, 0], [100.2, PI]], headPitch: [[100.2, 0], [100.8, -0.4]]}}, faces: [[0, 'fear']]},
      {id: 'guard', kind: 'guard', place: 'world', pos: [0.3, 0, 42.2], rotY: PI, faces: [[0, 'blank']]},
      ...passengers(),
      girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0),
    ],
  },
  {
    id: 's22-double',
    beat: 'Through the cabin glass: he sees himself, sitting beside the little girl.',
    from: 103.0, to: 108.7, set: 'park', caption: 'top', transition: 'dip', mood: {...NIGHT, ambient: 0.5}, highlightCabin: HERO_CABIN,
    camera: [
      {t: 103.0, pos: [0, -0.8, 4.6], target: [0, -1.1, -0.72], fov: 40, followCabin: HERO_CABIN},
      {t: 104.6, pos: [0, -0.9, 3.4], target: [0, -1.1, -0.72], fov: 38, followCabin: HERO_CABIN},
      {t: 108.7, pos: [-0.2, -0.95, 2.4], target: [-0.1, -1.1, -0.72], fov: 36, followCabin: HERO_CABIN},
    ],
    actors: [
      {id: 'double', kind: 'hero', place: {cabin: HERO_CABIN}, pos: [-0.36, 0, -0.72], rotY: 0, motion: {...seated, idle: 0}, faces: [[0, 'blank']]},
      girlIn({cabin: HERO_CABIN}, [0.36, 0, -0.72], 0, {faces: [[0, 'blank'], [106.4, 'creepy']], motion: {...seated, idle: 0, tracks: {armLOut: [[0, 0.25]]}}}),
    ],
  },
  {
    id: 's23-smile',
    beat: 'Close on the girl: a slow smile. "You haven\'t left yet."',
    from: 108.7, to: 112.7, set: 'park', caption: 'bottom', transition: 'cut', mood: {...NIGHT, ambient: 0.5, accent: {color: '#ff2a3a', intensity: 4, pos: [0, 30, 6]}}, highlightCabin: HERO_CABIN,
    camera: [
      {t: 108.7, pos: [0.36, -1.3, 1.1], target: [0.36, -1.38, -0.72], fov: 34, followCabin: HERO_CABIN},
      {t: 112.7, pos: [0.36, -1.33, 0.75], target: [0.36, -1.38, -0.72], fov: 30, followCabin: HERO_CABIN},
    ],
    actors: [
      {id: 'double', kind: 'hero', place: {cabin: HERO_CABIN}, pos: [-0.36, 0, -0.72], rotY: 0, motion: {...seated, idle: 0}, faces: [[0, 'blank']]},
      girlIn({cabin: HERO_CABIN}, [0.36, 0, -0.72], 0, {talk: [[110.8, 112.2]], faces: [[0, 'creepy']], motion: {...seated, idle: 0, tracks: {headRoll: [[109.3, 0], [110.2, 0.18]]}}}),
    ],
  },
  {
    id: 's24-option1',
    beat: 'Choice one: behind him, the wheel looms. Get back on?',
    from: 112.7, to: 118.4, set: 'park', caption: 'top', transition: 'flash', mood: LIT, highlightCabin: HERO_CABIN,
    camera: [
      {t: 112.7, pos: [0.8, 1.0, 41], target: [0, 12, 0], fov: 55},
      {t: 118.4, pos: [0.6, 1.3, 38.5], target: [0, 13, 0], fov: 50},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 37], rotY: PI, faces: [[0, 'fear']], motion: {tracks: {headPitch: [[0, -0.35]]}}},
      ...passengers(),
      girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0),
    ],
  },
  {
    id: 's25-option2',
    beat: 'Choice two: he turns to the open exit gates and the dark road beyond.',
    from: 118.4, to: 122.3, set: 'park', caption: 'top', transition: 'cut', mood: LIT,
    camera: [
      {t: 118.4, pos: [-1.6, 1.5, 34], target: [0, 1.6, 45], fov: 46},
      {t: 122.3, pos: [-1.2, 1.6, 35], target: [0, 1.8, 46], fov: 42},
    ],
    actors: [{id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 37], motion: {tracks: {rotY: [[118.5, PI], [119.3, 0]]}}, faces: [[0, 'fear'], [120.5, 'sad']]}],
  },
  {
    id: 's26-final',
    beat: 'Crane up and away: the tiny figure between the wheel and the gates. Comment 1 or 2.',
    from: 122.3, to: 129.4, set: 'park', caption: 'bottom', transition: 'cut', mood: LIT, highlightCabin: HERO_CABIN,
    camera: [
      {t: 122.3, pos: [2, 2.5, 44], target: [0, 1.8, 37], fov: 45},
      {t: 129.4, pos: [0, 32, 78], target: [0, 9, 18], fov: 52},
    ],
    actors: [
      {id: 'hero', kind: 'hero', place: 'world', pos: [0, 0, 37], rotY: PI / 2, motion: {tracks: {headYaw: [[123.0, -1.0], [124.5, 1.0], [126.0, 0]]}}, faces: [[0, 'confused']]},
      ...passengers(),
      girlIn({cabin: GIRL_CABIN}, [0.3, 0, -0.72], 0),
    ],
  },
];

export const OVERLAYS: OverlaySpec[] = [
  {type: 'title', from: 0.15, to: 2.3, text: 'THE LAST RIDE', sub: 'EPISODE 1'},
  {type: 'announcement', from: 49.4, to: 53.8, text: 'PARK ANNOUNCEMENT'},
  {type: 'choice', from: 114.9, to: 122.2, num: '1', text: 'GET BACK ON THE FERRIS WHEEL'},
  {type: 'choice', from: 118.5, to: 122.2, num: '2', text: 'WALK THROUGH THE EXIT GATES'},
  {type: 'cta', from: 124.18, to: 129.4, text: 'COMMENT 1 OR 2'},
  {type: 'endcard', from: 125.88, to: 129.4, text: 'YOUR CHOICE DECIDES', sub: 'EPISODE 2'},
];

/** Words drawn in the accent colour in captions (lower-case, punctuation stripped). */
export const EMPHASIS = new Set([
  'last', 'midnight', 'locked', 'except', 'moving', 'occupied', 'still', 'blinking', 'girl', 'red', 'balloon', 'staring',
  'behind', "nobody's", 'reflection', 'man', 'beside', 'crackle', 'closing', 'same', 'ticket', 'alone', 'stops', 'turns',
  'suddenly', 'whispers', "don't", 'lights', 'gates', 'security', 'guard', 'nobody', 'photograph', 'hand', 'yesterday',
  'yourself', 'smiles', "haven't", 'left', 'choices', 'one', 'two', 'choose', 'episode',
]);
