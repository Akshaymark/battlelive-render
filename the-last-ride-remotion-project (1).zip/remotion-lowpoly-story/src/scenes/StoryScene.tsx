import React, {useMemo} from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import * as THREE from 'three';
import {SceneSpec, ActorSpec} from '../data/types';
import {GLOBAL} from '../data/storyboard';
import {integrate, track, clamp} from '../utils/anim';
import {poseAt} from '../animations/poses';
import {faceAt} from '../animations/expressions';
import {mouthFromWords} from '../utils/speech';
import {Character, lookFor} from '../components/Character';
import {FerrisWheel, CabinShell} from '../components/FerrisWheel';
import {Park} from '../components/Environment';
import {CabinInterior, Photograph, Ticket} from '../components/Props';
import {StoryCamera} from '../components/Camera';
import {SceneTransition} from '../components/SceneTransition';

const seedOf = (id: string) => id.split('').reduce((a, c) => a + c.charCodeAt(0), 0) % 97;

/** Renders one actor at absolute time t, resolving pose, expression, lip-sync and placement. */
const Actor: React.FC<{a: ActorSpec; t: number}> = ({a, t}) => {
  if (a.visible && !a.visible.some(([x, y]) => t >= x && t <= y)) return null;
  const m = a.motion ?? {};
  const tr = m.tracks ?? {};
  const pose = poseAt(m, t, seedOf(a.id));
  const face = faceAt(a.faces, t);
  const mouth = mouthFromWords(t, a.talk);
  const h = lookFor(a.kind, a.variant).height;
  const sit = clamp(track(m.sit, t, 0));
  // children: lift so the (smaller) pelvis meets the 0.5 m bench
  const lift = h < 1 ? sit * 0.5 * (1 - h) : 0;
  const x = tr.x ? track(tr.x, t) : a.pos[0];
  const y = (tr.y ? track(tr.y, t) : a.pos[1]) + lift;
  const z = tr.z ? track(tr.z, t) : a.pos[2];
  const rotY = tr.rotY ? track(tr.rotY, t) : a.rotY ?? 0;
  const opacity = (a.opacity ?? 1) * (tr.opacity ? track(tr.opacity, t) : 1);
  return (
    <Character
      kind={a.kind}
      variant={a.variant}
      pose={pose}
      face={face}
      mouth={mouth}
      position={[x, y, z]}
      rotationY={rotY}
      opacity={opacity}
      holdBalloon={a.balloon}
      t={t}
    />
  );
};

const inCabin = (a: ActorSpec, i: number) => typeof a.place === 'object' && a.place.cabin === i;

/** Global park state at time t (deterministic): wheel angle, lights (with flicker), gates, PA. */
export const worldState = (t: number) => {
  const wheelAngle = integrate(GLOBAL.wheelSpeed, 0, t, 1 / 30);
  let lights = track(GLOBAL.lights, t);
  if (t > 60.5 && t < 62.6) lights *= Math.sin(t * 41) > 0.2 ? 1.6 : 0.2;
  return {wheelAngle, lights, gates: track(GLOBAL.gates, t), crackle: track(GLOBAL.crackle, t)};
};

export const StoryScene: React.FC<{scene: SceneSpec}> = ({scene}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = scene.from + frame / fps;
  const W = worldState(t);
  const mood = scene.mood;
  const fog = useMemo(() => new THREE.Fog(mood.background, mood.fog[0], mood.fog[1]), [mood]);

  const world = scene.actors.filter((a) => a.place === 'world');
  const interior = scene.actors.filter((a) => a.place === 'interior');
  const opposite = scene.actors.filter((a) => a.place === 'opposite');
  const props = (scene.props ?? []).map((p, i) => {
    if (p.visible && (t < p.visible[0] || t > p.visible[1])) return null;
    return p.type === 'ticket' ? (
      <Ticket key={i} position={p.pos} rotation={p.rot} scale={p.scale} />
    ) : (
      <Photograph key={i} position={p.pos} rotation={p.rot} scale={p.scale} />
    );
  });

  return (
    <AbsoluteFill style={{background: mood.background}}>
      <ThreeCanvas width={width} height={height} shadows gl={{antialias: true}} camera={{fov: 45, position: [0, 2, 10]}}>
        <color attach="background" args={[mood.background]} />
        <primitive attach="fog" object={fog} />
        <StoryCamera keys={scene.camera} t={t} wheelAngle={W.wheelAngle} handheld={scene.handheld} />
        <ambientLight intensity={mood.ambient * 2.2} color="#8fa0d8" />
        <hemisphereLight args={['#6d80c4', '#2a2018', 1.3]} />
        <directionalLight
          position={[-30, 50, 40]}
          intensity={mood.moon * 2.4}
          color="#c7d4ff"
          castShadow
          shadow-mapSize-width={1024}
          shadow-mapSize-height={1024}
          shadow-camera-left={-40}
          shadow-camera-right={40}
          shadow-camera-top={40}
          shadow-camera-bottom={-40}
          shadow-camera-far={150}
        />
        {mood.accent ? <pointLight position={mood.accent.pos} color={mood.accent.color} intensity={mood.accent.intensity} distance={14} decay={1.5} /> : null}

        {scene.set === 'park' ? (
          <>
            <Park lights={W.lights} gatesOpen={W.gates} crackle={W.crackle} t={t} />
            <FerrisWheel
              angle={W.wheelAngle}
              lights={W.lights}
              highlight={scene.highlightCabin}
              renderCabin={(i) => scene.actors.filter((a) => inCabin(a, i)).map((a) => <Actor key={a.id} a={a} t={t} />)}
            />
            {world.map((a) => (
              <Actor key={a.id} a={a} t={t} />
            ))}
            {props}
          </>
        ) : (
          <CabinInterior
            elevation={scene.elevation ?? 10}
            sway={Math.sin(t * 0.7) * 0.012}
            lights={W.lights}
            t={t}
            outside={
              scene.oppositeCabin ? (
                <group position={[0, 2.6 + Math.sin(t * 0.5) * 0.08, -9]} rotation={[0, 0, Math.sin(t * 0.6) * 0.02]}>
                  <CabinShell lit={0.6} color="#8c2f39">
                    {opposite.map((a) => (
                      <Actor key={a.id} a={a} t={t} />
                    ))}
                  </CabinShell>
                  <pointLight position={[0.5, -1.0, 0.8]} intensity={2.2} distance={5} color="#ffd9b0" />
                </group>
              ) : null
            }
          >
            <pointLight position={[0, 2.25, 0]} intensity={2.4} distance={6} decay={1.4} color="#ffcf9a" castShadow={false} />
            {interior.map((a) => (
              <Actor key={a.id} a={a} t={t} />
            ))}
            {props}
          </CabinInterior>
        )}
      </ThreeCanvas>
      <SceneTransition kind={scene.transition} />
    </AbsoluteFill>
  );
};
