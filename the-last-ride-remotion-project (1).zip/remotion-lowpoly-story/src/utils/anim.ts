/** Deterministic animation helpers. All functions are pure functions of time (seconds). */
export type Key = [number, number];

export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const easeInOut = (x: number) => {
  const c = clamp(x);
  return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
};
export const easeOut = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;

/** Interpolate a keyframe track [[time, value], ...] with ease-in-out between keys. */
export const track = (keys: Key[] | undefined, t: number, fallback = 0): number => {
  if (!keys || keys.length === 0) return fallback;
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 0; i < keys.length - 1; i++) {
    const [t0, v0] = keys[i];
    const [t1, v1] = keys[i + 1];
    if (t >= t0 && t <= t1) return lerp(v0, v1, easeInOut((t - t0) / Math.max(1e-6, t1 - t0)));
  }
  return keys[keys.length - 1][1];
};

/** Vector keyframes for cameras. */
export type V3 = [number, number, number];
export const lerp3 = (a: V3, b: V3, k: number): V3 => [lerp(a[0], b[0], k), lerp(a[1], b[1], k), lerp(a[2], b[2], k)];

/** Integrate a speed track (units/second) from t0 to t: used for the ferris wheel angle. */
export const integrate = (keys: Key[], t0: number, t: number, step = 1 / 60) => {
  let acc = 0;
  for (let x = t0; x < t; x += step) acc += track(keys, Math.min(x + step / 2, t)) * Math.min(step, t - x);
  return acc;
};

/** Cheap deterministic pseudo-noise in [-1, 1]. */
export const noise1 = (x: number, seed = 0) =>
  Math.sin(x * 1.7 + seed * 12.9) * 0.5 + Math.sin(x * 3.1 + seed * 4.1) * 0.3 + Math.sin(x * 7.3 + seed) * 0.2;

export const inRanges = (ranges: [number, number][] | undefined, t: number) =>
  !!ranges && ranges.some(([a, b]) => t >= a && t <= b);
