import transcript from '../data/transcript.json';

export type Word = {text: string; start: number; end: number; sentence: number; pauseAfter: number};
export const WORDS: Word[] = transcript.words as Word[];

/**
 * Mouth openness (0..1) for a speaking character, driven by the real word timestamps:
 * every word inside the character's talk ranges produces a syllable-like open/close pulse.
 */
export const mouthFromWords = (t: number, ranges: [number, number][] | undefined): number => {
  if (!ranges) return 0;
  for (const [a, b] of ranges) {
    if (t < a || t > b) continue;
    for (const w of WORDS) {
      if (w.start > b) break;
      if (w.end < a || t < w.start || t > w.end) continue;
      const len = Math.max(0.08, w.end - w.start);
      const syll = Math.max(1, Math.round(w.text.replace(/[^aeiouy]/gi, '').length * 0.8));
      const p = (t - w.start) / len;
      return 0.25 + 0.75 * Math.abs(Math.sin(p * Math.PI * syll));
    }
  }
  return 0;
};
