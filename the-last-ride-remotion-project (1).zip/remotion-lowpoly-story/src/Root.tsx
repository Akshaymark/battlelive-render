import React from 'react';
import {Composition} from 'remotion';
import {LastRideVideo} from './Video';
import {DURATION_FRAMES, FPS, SIZES} from './config';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="LastRide"
      component={LastRideVideo}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={SIZES['9:16'].width}
      height={SIZES['9:16'].height}
      defaultProps={{showCaptions: true}}
    />
    <Composition
      id="LastRide16x9"
      component={LastRideVideo}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={SIZES['16:9'].width}
      height={SIZES['16:9'].height}
      defaultProps={{showCaptions: true}}
    />
  </>
);
