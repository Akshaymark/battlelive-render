import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, useVideoConfig} from 'remotion';
import {SCENES} from './data/storyboard';
import {StoryScene} from './scenes/StoryScene';
import {Captions} from './components/Captions';
import {Overlays} from './components/Overlays';
import {PostFX} from './components/PostFX';
import {useFonts} from './components/FontLoader';

/** Master composition: scenes on the narration timeline + captions + overlays + audio. */
export const LastRideVideo: React.FC<{showCaptions?: boolean}> = ({showCaptions = true}) => {
  useFonts();
  const {fps, durationInFrames} = useVideoConfig();
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {SCENES.map((s) => {
        const from = Math.round(s.from * fps);
        const to = Math.min(durationInFrames, Math.round(s.to * fps));
        return (
          <Sequence key={s.id} from={from} durationInFrames={Math.max(1, to - from)} name={s.id}>
            <StoryScene scene={s} />
          </Sequence>
        );
      })}
      <PostFX />
      <Overlays />
      {showCaptions ? <Captions /> : null}
      <Audio src={staticFile('audio/narration.wav')} />
      <Audio src={staticFile('audio/ambience.wav')} volume={0.32} />
    </AbsoluteFill>
  );
};
