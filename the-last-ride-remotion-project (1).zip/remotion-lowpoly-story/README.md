# The Last Ride: Low-Poly 3D Story (Remotion + React Three Fiber)

This is a cinematic low-poly 3D animated short built entirely from your narration (`public/audio/narration.wav`, 127.96 s).
It renders at 1080×1920 (9:16) or 1920×1080 (16:9) at 30 fps. All models, textures, fonts and audio are bundled or generated, so a render needs no network and no paid API.

## Quick start

```bash
# Node 18+ (tested on Node 22)
npm install
npx remotion browser ensure      # downloads Remotion's headless Chromium once
npm run studio                   # live editor at http://localhost:3000
```

### Render

```bash
# Full 9:16 vertical video (master)
npx remotion render src/index.ts LastRide out/the-last-ride-9x16.mp4 --gl=angle --concurrency=2

# 16:9 landscape version
npx remotion render src/index.ts LastRide16x9 out/the-last-ride-16x9.mp4 --gl=angle --concurrency=2

# 10-second preview
npm run preview
```

`--gl=angle` is required because the scenes use WebGL. On a machine with a GPU you can raise `--concurrency` to speed things up. Rendering on CPU (software WebGL) takes about 1 to 2 s per frame.

**Linux note:** Chromium needs a few system libraries. On Debian or Ubuntu, run:
`sudo apt-get install libatk1.0-0 libatspi2.0-0 libxcomposite1 libxdamage1 libgbm1 libxkbcommon0 libasound2`

## How it works

| Layer | Where | What it does |
|---|---|---|
| Speech recognition | `scripts/transcribe.py` | faster-whisper (`small`, CPU) produces word-level timestamps from the audio. |
| Alignment and cleanup | `scripts/align_audio.py` | Applies word corrections without moving timings ("right" → "ride"), marks sentence boundaries and the pause after each word, and writes `src/data/transcript.json`. |
| Storyboard | `src/data/storyboard.ts` | Splits the story into 27 scenes. Each scene sets its timing, set, camera keyframes, actors (position, motion tracks, expressions, speech ranges), props, caption placement, transition and lighting mood. Every time is taken from the alignment. |
| Scene engine | `src/scenes/StoryScene.tsx` | Renders any scene from its storyboard entry. It resolves poses, expressions, lip-sync and placement for each actor, either in the world, inside a moving wheel cabin, or in the cabin interior. |
| Characters | `src/components/Character.tsx` | Procedural low-poly humans with a joint hierarchy (hips, knees, shoulders, elbows, neck, head). Faces are built from geometry: brows, eyes, pupils, nose, and a mouth shaped by curve, width and openness. |
| Animation | `src/animations/poses.ts`, `expressions.ts` | Walk and run cycles, sitting, head turns, gestures, lean, shiver and idle breathing. Nine blended expressions: neutral, fear, surprise, sad, happy, angry, confused, creepy, blank. |
| Lip-sync | `src/utils/speech.ts` | Mouth movement is driven by the real word timestamps, with one pulse per syllable estimate inside each spoken word. |
| Camera | `src/components/Camera.tsx` | Eased keyframes for position, target, FOV and roll, plus optional handheld shake. Tracking shots can follow a moving cabin. FOV adapts automatically for 16:9. |
| World | `Environment.tsx`, `FerrisWheel.tsx`, `Props.tsx` | Displaced faceted ground, stars, moon, trees, tents, carousel, lamp posts with real lights, hinged gates, a loudspeaker, a 12-cabin ferris wheel whose angle is integrated from a speed track (so it stops and restarts deterministically), the cabin interior, and canvas-drawn ticket and photograph props. |
| Captions | `src/components/Captions.tsx` | Word-by-word captions grouped by sentence, pause and length. The current word pops and highlights, upcoming words stay dimmed, and key words use the accent colour (`EMPHASIS` in the storyboard). Each scene places captions at the top or bottom so they stay off faces. |
| Motion graphics | `src/components/Overlays.tsx` | Title card, park-announcement waveform, the two choice cards, the "Comment 1 or 2" call to action, and the end card. |
| Transitions and look | `SceneTransition.tsx`, `PostFX.tsx` | Fade, dip-to-black, white flash and hard cut, plus vignette, colour wash and animated film grain. |
| Sound | `scripts/make_ambience.py` | Synthesises a drone, wind, music-box tones, creaks, footsteps, loudspeaker crackle and hits at storyboard times, written to `public/audio/ambience.wav` and mixed under the narration. |

## Editing

- **Change a beat:** edit its entry in `src/data/storyboard.ts`. Camera keys use absolute seconds on the narration timeline. Actor `tracks` take `[[time, value], ...]` pairs, `faces` take `[[time, 'fear'], ...]`, and `talk` takes `[[start, end]]` ranges for lip-sync.
- **Add a character look:** add it to `LOOKS` in `Character.tsx`.
- **New audio:** replace `public/audio/narration.wav`, then run:
  ```bash
  pip install faster-whisper numpy
  python scripts/transcribe.py public/audio/narration.wav
  python scripts/align_audio.py
  python scripts/make_ambience.py
  ```
  After that, rewrite the storyboard for the new story. The composition length follows `transcript.json` automatically.
- **WhisperX:** for phoneme-level forced alignment, swap `transcribe.py` for WhisperX (`whisperx.align`). Keep the output in the same `raw_transcript.json` format and everything downstream still works.

## Implementation notes

- **Depth of field is not implemented.** Depth comes from scene fog and lighting instead. Adding `@react-three/postprocessing` DOF would be possible but greatly slows software rendering.
- **Faces use procedural meshes, not morph targets.** Each facial part is scaled and rotated per expression, which gives the same effect.
- **The sound bed is synthesised, not recorded.** The narration is your own file and is left untouched.
- **The transcript is Whisper `small` output with one correction.** Check `src/data/transcript.json` if you spot a caption error.

## Structure

```
public/audio/        narration.wav (yours), ambience.wav (generated)
public/fonts/        Anton, Bebas Neue, Montserrat (OFL), LICENSE.md
public/models|textures/  notes: everything is procedural
scripts/             transcribe.py, align_audio.py, make_ambience.py, stills.sh, raw_transcript.json
src/Root.tsx         compositions LastRide (9:16) and LastRide16x9
src/Video.tsx        scenes timeline + captions + overlays + audio
src/config.ts        fps, sizes, palette, duration
src/data/            transcript.json, storyboard.ts, types.ts
src/scenes/          StoryScene.tsx (data-driven scene renderer)
src/components/      Character, FerrisWheel, Environment, Props, Camera, Captions, Overlays, SceneTransition, PostFX, FontLoader
src/animations/      poses.ts, expressions.ts
src/utils/           anim.ts (keyframes, easing, integration), speech.ts (lip-sync)
```
