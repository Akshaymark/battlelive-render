All 3D models in this project are generated procedurally at render time in TypeScript
(src/components/Character.tsx, FerrisWheel.tsx, Environment.tsx, Props.tsx) from Three.js
low-poly primitives with flat shading. There are no external model files, so nothing has to be
downloaded and every frame is deterministic.
