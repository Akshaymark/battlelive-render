# Font licenses

Anton (Vernon Adams), Bebas Neue (Dharma Type), and Montserrat (Julieta Ulanovsky et al.) are
licensed under the SIL Open Font License, Version 1.1. You may use, bundle, and redistribute them
with this project. Full license text: https://openfontlicense.org/open-font-license-official-text/
Source: Google Fonts (fonts.google.com).
