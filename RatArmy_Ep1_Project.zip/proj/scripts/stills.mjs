// Render preview stills: node scripts/stills.mjs <frame> <frame> ...   (COMP=RatThumb for thumbnail, SCALE=0.4 default)
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path';
import fs from 'fs';
const id = process.env.COMP || 'RatArmy1';
const scale = Number(process.env.SCALE || 0.4);
const frames = process.argv.slice(2).map(Number);
fs.mkdirSync('stills', {recursive: true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const comp = await selectComposition({serveUrl, id, chromiumOptions: {gl: 'angle'}});
for (const f of frames.length ? frames : [0]) {
  const t0 = Date.now();
  await renderStill({serveUrl, composition: comp, frame: f, output: `stills/${id}_f${String(f).padStart(4, '0')}.png`, chromiumOptions: {gl: 'angle'}, scale});
  console.log('done', f, Date.now() - t0, 'ms');
}
