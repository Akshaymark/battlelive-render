"""Music + SFX bed for CATS vs RAT Ep1 (no narration). Pure numpy -> public/audio/ratarmy_bed.wav
   pip install numpy   (if missing)"""
import numpy as np, wave, os

SR = 44100
DUR = 55.5
N = int(SR * DUR)
L = np.zeros(N); R = np.zeros(N)
rng = np.random.default_rng(7)

def tt(d): return np.arange(int(SR * d)) / SR

def add(sig, at, gain=1.0, pan=0.0):
    i = int(at * SR)
    if i >= N: return
    s = sig[: N - i] * gain
    L[i:i + len(s)] += s * np.sqrt(0.5 * (1 - pan))
    R[i:i + len(s)] += s * np.sqrt(0.5 * (1 + pan))

def lp(x, a):  # one-pole lowpass, a in (0,1): smaller = darker
    y = np.empty_like(x); acc = 0.0
    for i in range(len(x)):
        acc += a * (x[i] - acc); y[i] = acc
    return y

def lp_fast(x, a):
    # vectorised-ish: apply in blocks via cumulative approach (good enough for noise beds)
    from math import exp
    y = np.zeros_like(x)
    k = int(1 / a) * 3
    ker = a * (1 - a) ** np.arange(k)
    return np.convolve(x, ker, mode='same')

def env(d, a=0.005, r=None):
    t = tt(d); r = r or d
    e = np.minimum(1, t / a) * np.exp(-t / (r / 5))
    return e

# ---------------- instruments
def kick(): t = tt(0.35); f = 45 + 90 * np.exp(-t * 30); return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9)
def snare(): t = tt(0.22); return (rng.standard_normal(len(t)) * 0.7 + np.sin(2 * np.pi * 190 * t) * 0.5) * np.exp(-t * 22)
def tom(f=110): t = tt(0.4); fr = f * (1 + 0.6 * np.exp(-t * 25)); return np.sin(2 * np.pi * np.cumsum(fr) / SR) * np.exp(-t * 8)
def hat(): t = tt(0.06); n = rng.standard_normal(len(t)); n = n - lp_fast(n, 0.3); return n * np.exp(-t * 70)
def pop():
    t = tt(0.12); f = 400 + 2200 * (t / 0.12) ** 0.6
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 30) * np.minimum(1, t / 0.003)
def pluck(f, d=0.28):
    t = tt(d); s = np.sign(np.sin(2 * np.pi * f * t)) * 0.4 + np.sin(2 * np.pi * f * t) * 0.6
    return lp_fast(s, 0.12) * np.exp(-t * 9)
def bassoon(f, d):
    t = tt(d); vib = 1 + 0.006 * np.sin(2 * np.pi * 5.5 * t)
    ph = 2 * np.pi * np.cumsum(f * vib) / SR
    s = 0.6 * np.sin(ph) + 0.3 * np.sin(2 * ph) + 0.2 * np.sign(np.sin(ph)) * 0.5
    e = np.minimum(1, t / 0.03) * np.minimum(1, (d - t) / 0.05)
    return s * e
def whoosh(d=0.35):
    t = tt(d); n = rng.standard_normal(len(t)); n = lp_fast(n, 0.08)
    return n * np.sin(np.pi * t / d) ** 2 * 3
def impact():
    t = tt(1.2); return (np.sin(2 * np.pi * 50 * t) * np.exp(-t * 4) + lp_fast(rng.standard_normal(len(t)), 0.05) * 2 * np.exp(-t * 6))
def arp(base=523.25):
    out = np.zeros(int(SR * 0.6))
    for i, m in enumerate([1, 1.26, 1.5, 2.0]):
        s = np.sin(2 * np.pi * base * m * tt(0.25)) * np.exp(-tt(0.25) * 12)
        j = int(i * 0.07 * SR); out[j:j + len(s)] += s
    return out

# ---------------- ambience: subway rumble + fluorescent hum
noise = rng.standard_normal(N)
rumble = lp_fast(noise, 0.004)
rumble /= np.abs(rumble).max()
tg = np.arange(N) / SR
rum_env = 0.35 + 0.15 * np.sin(2 * np.pi * 0.13 * tg)
rum_env += np.clip((tg - 46.2) / 1.0, 0, 1) * np.clip((53.8 - tg) / 0.4, 0, 1) * 1.1  # train in the swarm
L += rumble * rum_env * 0.5; R += np.roll(rumble, 300) * rum_env * 0.5
hum = (np.sin(2 * np.pi * 60 * tg) * 0.5 + np.sin(2 * np.pi * 120 * tg) * 0.3 + np.sin(2 * np.pi * 180 * tg) * 0.1)
flick = np.where((np.floor(tg * 9) * 0.37 % 1) > 0.86, 0.2, 1.0)
L += hum * 0.025 * flick; R += hum * 0.025 * flick

# music goes to its own bus so it can be ducked under the voiceover
ML = np.zeros(N); MR = np.zeros(N)
def addm(sig, at, gain=1.0, pan=0.0):
    i = int(at * SR)
    if i >= N: return
    s = sig[: N - i] * gain
    ML[i:i + len(s)] += s * np.sqrt(0.5 * (1 - pan))
    MR[i:i + len(s)] += s * np.sqrt(0.5 * (1 + pan))

# ---------------- march: 104 bpm, D minor ostinato (timeline aligned to narration)
BPM = 104; beat = 60 / BPM
bass_notes = [73.42, 73.42, 87.31, 73.42, 110.0, 103.83, 98.0, 87.31]
def section_gain(t):
    if t < 6.3: return 0.45
    if t < 9.4: return 0.6
    if t < 12.3: return 0.3   # roar
    if t < 16.5: return 0.55
    if t < 42.2: return 0.9
    if t < 46.2: return 0.0   # boss stare: drone only
    if t < 53.6: return 1.0
    return 0.0
b = 0; t = 0.0
while t < 53.6:
    g = section_gain(t)
    if g > 0:
        if b % 2 == 0: addm(kick(), t, 0.55 * g)
        if b % 4 in (1, 3): addm(snare(), t, 0.25 * g, 0.1)
        if t >= 16.5 and b % 4 == 3: addm(snare(), t + beat * 0.5, 0.15 * g, -0.1)
        if t >= 46.2: addm(snare(), t + beat * 0.5, 0.18 * g)
        addm(hat(), t + beat * 0.5, 0.12 * g, 0.4)
        addm(pluck(bass_notes[b % 8], beat * 0.9), t, 0.35 * g, -0.2)
        addm(pluck(bass_notes[b % 8] * 2, beat * 0.45), t + beat * 0.5, 0.12 * g, 0.2)
    t += beat; b += 1
mel = [(293.66, .5), (349.23, .5), (440, .5), (415.3, .5), (392, .5), (349.23, .5), (329.63, 1.0),
       (293.66, .5), (349.23, .5), (440, .5), (523.25, .5), (466.16, 1.0), (440, 1.0)]
t = 16.5
while t < 37.0:
    for f, d in mel:
        if t >= 37.0: break
        addm(bassoon(f / 2, d * beat * 0.75), t, 0.2, 0.15)
        t += d * beat
for i, f in enumerate([293.66, 349.23, 440, 587.33, 523.25, 587.33, 698.46, 587.33]):
    addm(bassoon(f, 0.45) + bassoon(f * 1.5, 0.45) * 0.5, 46.6 + i * beat * 2, 0.22)
# king fanfare + lineup stabs
for i, f in enumerate([392.0, 392.0, 523.25, 659.25, 783.99]):
    addm(bassoon(f, 0.5 if i < 4 else 1.4) + bassoon(f * 1.5, 0.5 if i < 4 else 1.4) * 0.4, 34.45 + i * 0.22, 0.22)
for at, f in [(37.36, 392.0), (38.56, 440.0), (39.62, 493.88), (41.2, 587.33)]:
    addm(bassoon(f, 0.4) + bassoon(f * 1.25, 0.4) * 0.6 + bassoon(f * 1.5, 0.4) * 0.5, at, 0.25)
# cliffhanger drone 42.2-46.2 + heartbeat
tt3 = tt(4.0)
drone = (np.sin(2 * np.pi * 55 * tt3) + 0.5 * np.sin(2 * np.pi * 58.3 * tt3)) * np.minimum(1, tt3 / 0.4) * np.minimum(1, (4.0 - tt3) / 0.15)
addm(drone, 42.2, 0.4)
for hb in [42.6, 42.85, 43.6, 43.85, 44.5, 44.75, 45.4, 45.65]: addm(kick(), hb, 0.5)
# end card sting
for i, f in enumerate([293.66, 440, 587.33]): addm(bassoon(f, 1.6) * np.exp(-tt(1.6) * 1.5), 53.65 + i * 0.02, 0.18)

# ---------------- SFX (not ducked as hard)
for c in [4.0, 6.3, 9.4, 12.3, 14.5, 16.5, 25.6, 31.6, 37.2, 38.5, 39.6, 40.8, 42.2, 46.2, 50.3, 53.6]: add(whoosh(), c - 0.2, 0.22)
add(impact(), 0.0, 0.6)
t = tt(1.9); f = 85 - 25 * (t / 1.9)
growl = np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)) * (0.6 + 0.4 * np.sin(2 * np.pi * 28 * t))
growl = lp_fast(growl, 0.06) + lp_fast(rng.standard_normal(len(t)), 0.03) * 1.5
growl *= np.minimum(1, t / 0.08) * np.minimum(1, (1.9 - t) / 0.4)
add(growl / np.abs(growl).max(), 9.5, 0.7)
add(impact(), 9.5, 0.6)
drops = [17.2, 20.9, 23.3, 23.7, 24.1, 24.5, 24.9]
for i, d in enumerate(drops):
    add(pop(), d, 0.5, (-0.4 if i % 2 else 0.4))
    add(tom(140 + i * 12), d + 0.42, 0.55)
    add(arp(523.25 * (1 + i * 0.06))[: int(SR * 0.35)], d + 0.45, 0.12)
add(impact(), 26.4, 0.5); add(arp(659.25), 26.4, 0.25)
for k in range(14): add(pop(), 26.4 + k * 0.035, 0.12, (k % 3 - 1) * 0.5)
add(impact(), 29.3, 0.5); add(arp(783.99), 29.3, 0.25)
for k in range(18): add(pop(), 29.3 + k * 0.035, 0.12, (k % 3 - 1) * 0.5)
t = tt(1.4); add(np.sin(2 * np.pi * (220 + 30 * np.sin(2 * np.pi * 3 * t)) * t) * 0.3 * np.sin(np.pi * t / 1.4), 28.4, 0.4)
t = tt(0.5); add(np.sin(2 * np.pi * np.cumsum(1400 - 1000 * t / 0.5) / SR) * 0.4 * np.minimum(1, t / 0.05), 33.8, 0.35)
add(impact(), 34.3, 0.9); add(kick(), 34.3, 0.8)
t = tt(0.4); add(np.sin(2 * np.pi * np.cumsum(200 + 600 * t / 0.4) / SR) * np.minimum(1, t / 0.02) * np.exp(-t * 3), 36.0, 0.35)  # grow
add(impact(), 36.35, 0.6)
for at in [37.36, 38.56, 39.62, 41.2]: add(impact(), at, 0.35)
add(impact(), 44.5, 0.4)
t = tt(1.6)
horn = sum(((f * t) % 1 - 0.5) for f in [311.1, 313.0, 392.0, 394.5])
horn = lp_fast(horn, 0.18) * np.minimum(1, t / 0.06) * np.minimum(1, (1.6 - t) / 0.3)
add(horn / np.abs(horn).max(), 47.2, 0.45)
for k in range(300):
    tk = 46.5 + rng.random() * 7.0
    add(hat() * 0.6, tk, 0.06 * rng.random(), rng.random() * 2 - 1)
add(impact(), 53.6, 0.7)

# ---------------- duck under the voiceover
vo_env = np.zeros(N)
try:
    with wave.open('public/audio/narration.wav') as w:
        sr = w.getframerate(); v = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float64) / 32768
        if w.getnchannels() == 2: v = v.reshape(-1, 2).mean(1)
    v = np.interp(np.arange(N) / SR, np.arange(len(v)) / sr, np.abs(v), right=0)
    win = int(SR * 0.12)
    v = np.convolve(v, np.ones(win) / win, mode='same')
    v = np.clip(v / (np.percentile(v[v > 1e-4], 70) + 1e-9), 0, 1)
    # smooth attack/release (~80 ms / ~350 ms)
    env = np.zeros(N); a_up = 1 - np.exp(-1 / (0.08 * SR / 64)); a_dn = 1 - np.exp(-1 / (0.35 * SR / 64))
    acc = 0.0
    for i in range(0, N, 64):
        x = v[i]; acc += (a_up if x > acc else a_dn) * (x - acc); env[i:i + 64] = acc
    vo_env = env
    print('ducking under narration.wav')
except FileNotFoundError:
    print('no narration.wav: no ducking')
music_gain = 1 - 0.68 * vo_env   # ~ -10 dB under voice
sfx_gain = 1 - 0.45 * vo_env
L = L * sfx_gain + ML * music_gain
R = R * sfx_gain + MR * music_gain

# ---------------- master (bed sits under the voice; Remotion plays narration.wav on top)
mix = np.stack([L, R], 1)
mix = np.tanh(mix * 1.1)
mix /= np.abs(mix).max() / 0.6
fade = np.ones(N); fl = int(SR * 0.8); fade[-fl:] = np.linspace(1, 0, fl)
mix *= fade[:, None]
os.makedirs('public/audio', exist_ok=True)
out = (mix * 32767).astype(np.int16)
with wave.open('public/audio/ratarmy_bed.wav', 'wb') as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(out.tobytes())
print('wrote public/audio/ratarmy_bed.wav', out.shape[0] / SR, 's')
