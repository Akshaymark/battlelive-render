import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path';
import fs from 'fs';
fs.mkdirSync('out', {recursive: true});
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const comp = await selectComposition({serveUrl, id: 'RatThumb', chromiumOptions: {gl: 'angle'}});
await renderStill({serveUrl, composition: comp, frame: 0, output: 'out/RatArmy_Ep1_Thumbnail.jpg', imageFormat: 'jpeg', jpegQuality: 92, chromiumOptions: {gl: 'angle'}});
console.log('ok');
