import {Config} from '@remotion/cli/config';

// WebGL is required for the 3D scenes. "angle" works headless on Linux/macOS/Windows.
Config.setChromiumOpenGlRenderer('angle');
Config.setVideoImageFormat('jpeg');
Config.setJpegQuality(92);
Config.setOverwriteOutput(true);
Config.setConcurrency(2);
