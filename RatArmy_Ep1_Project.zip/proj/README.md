# CATS vs RAT — Episode 1 ("3 AM, Times Sq–42 St")

Vertical short (1080×1920, 30 fps, 55.5 s) built with **Remotion 4 + @remotion/three (react-three-fiber)**.
Stylized toy/Pixar-ish 3D made entirely from primitives (no external models). Voiceover: `public/audio/narration.wav` (word timings in `src/vo_words.json` drive the word-by-word captions). Music + SFX bed generated in Python and ducked under the voice (`npm run audio` re-reads narration.wav for the ducking envelope).

## Setup
```bash
npm install            # Remotion 4.0.290, three 0.170, r3f 8.17
pip install numpy      # only needed to regenerate the audio
npm run audio          # -> public/audio/ratarmy_bed.wav (already included)
npm run studio         # live preview
npm run thumbnail      # -> out/RatArmy_Ep1_Thumbnail.jpg  (composition "RatThumb")
npm run render         # -> out/RatArmy_Ep1.mp4             (composition "RatArmy1")
node scripts/stills.mjs 0 300 600   # preview stills -> stills/
```
WebGL runs headless via `--gl=angle` (set in remotion.config.ts). On bare Linux, Chromium may need:
`apt-get install libatk1.0-0 libatk-bridge2.0-0 libcups2 libxkbcommon0 libxcomposite1 libxdamage1 libxfixes3 libxrandr2 libgbm1 libpango-1.0-0 libcairo2 libnss3 libnspr4 libdrm2 libxshmfence1 libasound2t64`.
Software-GL rendering is slow (~30 s/frame at 0.4 scale on 2 CPU cores); on a machine with a GPU it's far faster.

## Files
- `src/story.ts` — **edit here**: handles, date label, recruit drop times/positions, counter logic (`catCount`, `ratCount`).
- `src/Shots.tsx` — the 9 shots (camera keys, scene contents, which characters get name tags).
- `src/Characters.tsx` — `Rat` (gear: crust, hard hat, helmet, MetroCard shield, pizza-box armor, bandana), `RoombaTank`, `Cat` (tabby/black/orange, boss with eyepatch+scar, roar/narrow-eye controls), instanced `CatCrowd` (~1,000 cats, eyes ignore fog so they glow in the dark), instanced `RatSwarm`.
- `src/Station.tsx` — NYC subway platform: tiles, 42 ST / TIMES SQ mosaics, yellow tactile edge strip, tracks + third rail, I-beam columns, flickering fluorescents, fence + turnstiles, pizza slices, trash, puddle, steam grate, tunnel with train headlight.
- `src/Overlays.tsx` — HUD (LIVE BATTLE · date, CAT ARMY / RAT ARMY scoreboard), Instagram-style tag pills (projected from 3D positions every frame so they stick to characters), callouts, end card.
- `src/Thumb.tsx` — thumbnail composition.
- `scripts/make_audio.py` — music/SFX bed.

## Recruit tiers (match the narration)
comment = **SOLDIER** (helmet) · tag 1 friend = **SNIPER** (tiny scoped rifle) · tag 2 friends = **ROBOT RAT** (metal suit, rides the Roomba tank) · tag 3 friends = **KING SEWER RAT** (crown + cape, grows to double size). Tier pills show under the @handle tags from 23.3 s to the end card.

## Swapping in real commenters
Recruit tags use `RECRUIT_HANDLE = '@your_handle'` in `src/story.ts`. To use real handles, replace `text: RECRUIT_HANDLE` in `recruitTags`/`upgradeTags`/`swarmTags` (src/Shots.tsx) with a lookup into an array of handles.

## Credits
Rat emoji on the end card: Twemoji (CC-BY 4.0, © Twitter/X and contributors). Fonts: Montserrat (OFL), DejaVu Sans Mono (free license).
