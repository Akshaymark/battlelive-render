import React, {useMemo} from 'react';
import * as THREE from 'three';
import {V3, rnd} from './cam';
import {useCanvasTex} from './Characters';

// World layout (meters): platform top y=0, platform edge at x=-2.6 (track on the left, x<-2.6, y=-1.3).
// Back tiled wall at x=9. Fence + turnstiles at z=-2.8. Cats live behind the fence (z<-3.3). Tunnel at far -z.
export const EDGE_X = -2.6;
export const TRACK_Y = -1.3;
export const FENCE_Z = -2.8;

const useTileTex = (rx: number, ry: number, band = true) => {
  const tex = useCanvasTex(512, 512, (g) => {
    g.fillStyle = '#8f9690';
    g.fillRect(0, 0, 512, 512);
    const tw = 64;
    const th = 32;
    for (let y = 0; y < 512; y += th) {
      for (let x = 0; x < 512; x += tw) {
        const v = 222 + Math.floor(rnd(x * 3 + y * 7) * 22);
        g.fillStyle = `rgb(${v},${v + 4},${v - 6})`;
        g.fillRect(x + 2, y + 2, tw - 4, th - 4);
        if (rnd(x + y * 13) > 0.92) {
          g.fillStyle = 'rgba(90,80,40,0.25)';
          g.fillRect(x + 2, y + 2, tw - 4, th - 4);
        }
      }
    }
    if (band) {
      // grime gradient at the bottom
      const gr = g.createLinearGradient(0, 380, 0, 512);
      gr.addColorStop(0, 'rgba(60,50,30,0)');
      gr.addColorStop(1, 'rgba(60,50,30,0.35)');
      g.fillStyle = gr;
      g.fillRect(0, 380, 512, 132);
    }
  });
  useMemo(() => {
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(rx, ry);
  }, [tex, rx, ry]);
  return tex;
};

const NameBand: React.FC<{position: V3; rotY: number; text: string; w?: number}> = ({position, rotY, text, w = 3.2}) => {
  const tex = useCanvasTex(1024, 256, (g) => {
    g.fillStyle = '#6e1f1f';
    g.fillRect(0, 0, 1024, 256);
    // mosaic border
    for (let x = 0; x < 1024; x += 32) {
      g.fillStyle = (x / 32) % 2 ? '#c9a04a' : '#2c5a3a';
      g.fillRect(x, 0, 32, 28);
      g.fillRect(x, 228, 32, 28);
    }
    g.fillStyle = '#f3ead2';
    g.fillRect(70, 52, 884, 152);
    g.fillStyle = '#1b1b1b';
    g.font = 'bold 118px Arial';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(text, 512, 132);
  }, [text]);
  return (
    <mesh position={position} rotation={[0, rotY, 0]}>
      <planeGeometry args={[w, w / 4]} />
      <meshStandardMaterial map={tex} roughness={0.6} />
    </mesh>
  );
};

const PizzaSlice: React.FC<{position: V3; rot?: number; s?: number}> = ({position, rot = 0, s = 1}) => {
  const geo = useMemo(() => {
    const sh = new THREE.Shape();
    sh.moveTo(0, 0);
    sh.lineTo(-0.13, 0.32);
    sh.quadraticCurveTo(0, 0.36, 0.13, 0.32);
    sh.lineTo(0, 0);
    return new THREE.ExtrudeGeometry(sh, {depth: 0.02, bevelEnabled: false});
  }, []);
  return (
    <group position={position} rotation={[0, rot, 0]} scale={s}>
      <mesh geometry={geo} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.005, 0]}>
        <meshStandardMaterial color="#ffc94a" roughness={0.6} />
      </mesh>
      <mesh position={[0, 0.03, -0.33]} rotation={[0, 0, Math.PI / 2]}>
        <cylinderGeometry args={[0.03, 0.03, 0.27, 10]} />
        <meshStandardMaterial color="#c98a3a" roughness={0.9} />
      </mesh>
      {[[0.02, -0.1], [-0.04, -0.2], [0.05, -0.24]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.03, z]} scale={[1, 0.3, 1]}>
          <sphereGeometry args={[0.03, 10, 6]} />
          <meshStandardMaterial color="#c2272d" roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
};

export const PizzaBox: React.FC<{position: V3; rotY?: number; lid?: number; s?: number}> = ({position, rotY = 0, lid = 0, s = 1}) => {
  const tex = useCanvasTex(256, 256, (g) => {
    g.fillStyle = '#d7b07a';
    g.fillRect(0, 0, 256, 256);
    g.fillStyle = '#d6262f';
    g.beginPath();
    g.arc(128, 128, 80, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = '#fff';
    g.font = 'bold 40px Arial';
    g.textAlign = 'center';
    g.fillText('NY PIZZA', 128, 140);
  });
  return (
    <group position={position} rotation={[0, rotY, 0]} scale={s}>
      <mesh position={[0, 0.06, 0]}>
        <boxGeometry args={[0.7, 0.12, 0.7]} />
        <meshStandardMaterial color="#cfa46c" roughness={0.9} />
      </mesh>
      <mesh position={[0, 0.121, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.62, 0.62]} />
        <meshStandardMaterial color="#3a1f12" roughness={1} />
      </mesh>
      <group position={[0, 0.12, -0.35]} rotation={[-lid * 1.9, 0, 0]}>
        <mesh position={[0, 0.005, 0.35]}>
          <boxGeometry args={[0.7, 0.01, 0.7]} />
          <meshStandardMaterial color="#cfa46c" roughness={0.9} />
        </mesh>
        <mesh position={[0, 0.011, 0.35]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[0.6, 0.6]} />
          <meshStandardMaterial map={tex} roughness={0.9} />
        </mesh>
      </group>
    </group>
  );
};

const Turnstile: React.FC<{position: V3; spin?: number}> = ({position, spin = 0}) => (
  <group position={position}>
    <mesh position={[0, 0.5, 0]}>
      <boxGeometry args={[0.32, 1.0, 0.8]} />
      <meshStandardMaterial color="#9aa1aa" metalness={0.7} roughness={0.35} />
    </mesh>
    <mesh position={[0, 1.005, 0]}>
      <boxGeometry args={[0.34, 0.02, 0.82]} />
      <meshStandardMaterial color="#202326" roughness={0.4} />
    </mesh>
    <mesh position={[0.05, 1.02, 0.2]}>
      <boxGeometry args={[0.12, 0.02, 0.18]} />
      <meshBasicMaterial color="#38ff7a" />
    </mesh>
    <group position={[0.2, 0.82, 0]} rotation={[spin, 0, 0]}>
      {[0, 1, 2].map((i) => (
        <mesh key={i} rotation={[(i * Math.PI * 2) / 3, 0, 0]} position={[0.0, 0, 0]}>
          <group rotation={[0, 0, Math.PI / 2]}>
            <mesh position={[0, -0.3, 0]}>
              <cylinderGeometry args={[0.022, 0.022, 0.6, 10]} />
              <meshStandardMaterial color="#d6dbe0" metalness={0.8} roughness={0.25} />
            </mesh>
          </group>
        </mesh>
      ))}
    </group>
  </group>
);

const Fence: React.FC<{z: number; x0: number; x1: number; gaps?: number[]}> = ({z, x0, x1, gaps = []}) => {
  const posts: number[] = [];
  for (let x = x0; x <= x1; x += 0.22) if (!gaps.some((g) => Math.abs(g - x) < 0.5)) posts.push(x);
  const steel = <meshStandardMaterial color="#7e868f" metalness={0.75} roughness={0.35} />;
  return (
    <group>
      {[0.12, 1.1].map((y) => (
        <mesh key={y} position={[(x0 + x1) / 2, y, z]} rotation={[0, 0, Math.PI / 2]}>
          <cylinderGeometry args={[0.035, 0.035, x1 - x0, 10]} />
          {steel}
        </mesh>
      ))}
      {posts.map((x) => (
        <mesh key={x} position={[x, 0.6, z]}>
          <cylinderGeometry args={[0.014, 0.014, 1.0, 6]} />
          {steel}
        </mesh>
      ))}
    </group>
  );
};

const Steam: React.FC<{t: number; position: V3}> = ({t, position}) => (
  <group position={position}>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.006, 0]}>
      <planeGeometry args={[0.7, 0.5]} />
      <meshStandardMaterial color="#222" metalness={0.6} roughness={0.5} />
    </mesh>
    {Array.from({length: 9}).map((_, i) => {
      const k = ((t * 0.35 + i / 9) % 1);
      return (
        <mesh key={i} position={[Math.sin(i * 2.1 + t) * 0.15 * k, 0.2 + k * 2.6, Math.cos(i * 1.3) * 0.1]} scale={0.25 + k * 0.8}>
          <sphereGeometry args={[0.5, 12, 10]} />
          <meshStandardMaterial color="#cfd6dd" transparent opacity={0.14 * Math.sin(k * Math.PI)} depthWrite={false} roughness={1} />
        </mesh>
      );
    })}
  </group>
);

const Tube: React.FC<{position: V3; on: number}> = ({position, on}) => (
  <group position={position}>
    <mesh>
      <boxGeometry args={[0.22, 0.06, 2.4]} />
      <meshStandardMaterial color="#5a5f63" metalness={0.5} roughness={0.5} />
    </mesh>
    <mesh position={[0, -0.04, 0]}>
      <boxGeometry args={[0.12, 0.04, 2.3]} />
      <meshBasicMaterial color={new THREE.Color('#e9fff2').multiplyScalar(0.15 + 0.85 * on)} toneMapped={false} />
    </mesh>
  </group>
);

export const flicker = (t: number, seed: number) => {
  const r = rnd(Math.floor(t * 9) + seed * 101);
  return r > 0.86 ? 0.15 : r > 0.8 ? 0.55 : 1;
};

export const Glow: React.FC<{position: V3; size: number; color: string; opacity?: number}> = ({position, size, color, opacity = 1}) => {
  const tex = useCanvasTex(128, 128, (g) => {
    const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.25, 'rgba(255,255,255,0.55)');
    gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 128, 128);
  });
  return (
    <sprite position={position} scale={[size, size, 1]}>
      <spriteMaterial map={tex} color={color} transparent opacity={opacity} depthWrite={false} blending={THREE.AdditiveBlending} fog={false} toneMapped={false} />
    </sprite>
  );
};

export type StationProps = {t: number; fog?: [string, number, number]; headlight?: number; tunnelZ?: number; noFence?: boolean; pizzaLid?: number; showBox?: boolean; bright?: number};

export const Station: React.FC<StationProps> = ({t, fog = ['#0b1014', 5, 26], headlight = 0, tunnelZ = -34, noFence, pizzaLid = 0, showBox = true, bright = 1}) => {
  const wallTex = useTileTex(24, 6);
  const farTex = useTileTex(24, 6);
  const floorTex = useCanvasTex(512, 512, (g) => {
    g.fillStyle = '#5d5c58';
    g.fillRect(0, 0, 512, 512);
    for (let i = 0; i < 900; i++) {
      const v = 70 + rnd(i) * 40;
      g.fillStyle = `rgba(${v},${v},${v - 5},0.35)`;
      g.fillRect(rnd(i * 3) * 512, rnd(i * 7) * 512, 3 + rnd(i * 9) * 6, 3 + rnd(i * 11) * 6);
    }
    // gum spots
    for (let i = 0; i < 40; i++) {
      g.fillStyle = 'rgba(30,30,30,0.5)';
      g.beginPath();
      g.arc(rnd(i * 13) * 512, rnd(i * 17) * 512, 4 + rnd(i) * 5, 0, 6.3);
      g.fill();
    }
    g.strokeStyle = 'rgba(0,0,0,0.35)';
    g.lineWidth = 3;
    for (let x = 0; x <= 512; x += 128) {
      g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 512); g.stroke();
      g.beginPath(); g.moveTo(0, x); g.lineTo(512, x); g.stroke();
    }
  });
  useMemo(() => {
    floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
    floorTex.repeat.set(6, 34);
  }, [floorTex]);
  const stripTex = useCanvasTex(64, 64, (g) => {
    g.fillStyle = '#f2c400';
    g.fillRect(0, 0, 64, 64);
    g.fillStyle = '#d4a900';
    for (let y = 8; y < 64; y += 16) for (let x = 8; x < 64; x += 16) { g.beginPath(); g.arc(x, y, 4.5, 0, 6.3); g.fill(); }
  });
  useMemo(() => {
    stripTex.wrapS = stripTex.wrapT = THREE.RepeatWrapping;
    stripTex.repeat.set(2, 140);
  }, [stripTex]);
  const ties = useMemo(() => Array.from({length: 70}, (_, i) => 6 - i * 0.65), []);
  const tubes = useMemo(() => Array.from({length: 9}, (_, i) => 4 - i * 4.2), []);
  const cols = useMemo(() => Array.from({length: 8}, (_, i) => 3.5 - i * 5.5), []);
  const f = flicker(t, 3);
  return (
    <>
      <color attach="background" args={[fog[0]]} />
      <fog attach="fog" args={fog} />
      <hemisphereLight args={['#9fb8c8', '#2a2620', 0.55 * bright]} />
      <ambientLight intensity={0.18 * bright} color="#b0c4d0" />
      <pointLight position={[0.5, 3.6, 1.5]} intensity={9 * f * bright} distance={10} decay={1.6} color="#e9fff2" />
      <pointLight position={[2.5, 3.6, -4]} intensity={7 * bright} distance={10} decay={1.6} color="#e9fff2" />
      <pointLight position={[2.5, 3.6, -11]} intensity={6 * flicker(t, 7) * bright} distance={10} decay={1.6} color="#d8ffe8" />
      {/* platform */}
      <mesh position={[(EDGE_X + 9) / 2, -0.2, -28]}>
        <boxGeometry args={[9 - EDGE_X, 0.4, 72]} />
        <meshStandardMaterial map={floorTex} roughness={0.85} />
      </mesh>
      <mesh position={[EDGE_X + 0.3, 0.004, -28]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.6, 72]} />
        <meshStandardMaterial map={stripTex} roughness={0.6} />
      </mesh>
      <mesh position={[EDGE_X - 0.01, -0.75, -28]}>
        <boxGeometry args={[0.04, 1.1, 72]} />
        <meshStandardMaterial color="#2c2a27" roughness={0.9} />
      </mesh>
      {/* track bed */}
      <mesh position={[-6, TRACK_Y, -28]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[7, 72]} />
        <meshStandardMaterial color="#2a2621" roughness={1} />
      </mesh>
      {ties.map((z) => (
        <mesh key={z} position={[-5.1, TRACK_Y + 0.05, z]}>
          <boxGeometry args={[2.6, 0.1, 0.22]} />
          <meshStandardMaterial color="#3b2e24" roughness={1} />
        </mesh>
      ))}
      {[-5.85, -4.35].map((x) => (
        <mesh key={x} position={[x, TRACK_Y + 0.17, -28]}>
          <boxGeometry args={[0.08, 0.14, 72]} />
          <meshStandardMaterial color="#a8a39c" metalness={0.85} roughness={0.3} />
        </mesh>
      ))}
      <mesh position={[-3.3, TRACK_Y + 0.25, -28]}>
        <boxGeometry args={[0.3, 0.08, 72]} />
        <meshStandardMaterial color="#d8c27a" roughness={0.7} />
      </mesh>
      {/* far wall across the track */}
      <mesh position={[-8.5, 1.4, -28]} rotation={[0, Math.PI / 2, 0]}>
        <planeGeometry args={[72, 6]} />
        <meshStandardMaterial map={farTex} roughness={0.5} />
      </mesh>
      {/* back wall */}
      <mesh position={[9, 2.3, -28]} rotation={[0, -Math.PI / 2, 0]}>
        <planeGeometry args={[72, 4.6]} />
        <meshStandardMaterial map={wallTex} roughness={0.45} />
      </mesh>
      <NameBand position={[-8.45, 2.2, -4]} rotY={Math.PI / 2} text="42 ST" />
      <NameBand position={[-8.45, 2.2, -16]} rotY={Math.PI / 2} text="TIMES SQ" />
      <NameBand position={[8.95, 2.6, -2]} rotY={-Math.PI / 2} text="TIMES SQ" />
      {/* ceiling */}
      <mesh position={[0, 4.6, -28]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[20, 72]} />
        <meshStandardMaterial color="#1c1f22" roughness={1} />
      </mesh>
      {tubes.map((z, i) => (
        <React.Fragment key={z}>
          <Tube position={[0.6, 4.5, z]} on={i === 0 ? f : i === 3 ? flicker(t, 7) : 1} />
          <Tube position={[5, 4.5, z]} on={1} />
        </React.Fragment>
      ))}
      {/* columns */}
      {cols.map((z) => (
        <React.Fragment key={z}>
          {[-1.9, 4.5].map((x) => (
            <group key={x} position={[x, 2.3, z]}>
              <mesh>
                <boxGeometry args={[0.32, 4.6, 0.08]} />
                <meshStandardMaterial color="#2f4f46" roughness={0.6} metalness={0.3} />
              </mesh>
              <mesh>
                <boxGeometry args={[0.08, 4.6, 0.3]} />
                <meshStandardMaterial color="#2f4f46" roughness={0.6} metalness={0.3} />
              </mesh>
            </group>
          ))}
        </React.Fragment>
      ))}
      {/* fence + turnstiles */}
      {noFence ? null : (
        <>
          <Fence z={FENCE_Z} x0={-2.4} x1={8.8} gaps={[1.6, 3.2]} />
          <Turnstile position={[1.2, 0, FENCE_Z]} spin={t * 0.4} />
          <Turnstile position={[2.0, 0, FENCE_Z]} />
          <Turnstile position={[2.8, 0, FENCE_Z]} />
          <Turnstile position={[3.6, 0, FENCE_Z]} />
        </>
      )}
      {/* trash */}
      <PizzaSlice position={[1.2, 0, 1.0]} rot={0.7} />
      <PizzaSlice position={[-1.5, 0, -1.5]} rot={-2.2} s={0.9} />
      <PizzaSlice position={[3.2, 0, 0.3]} rot={2.5} />
      {[[0.9, -1.2], [-1.2, 1.6], [2.5, -1.7], [4.2, 1.4]].map(([x, z], i) => (
        <mesh key={i} position={[x, 0.06, z]} rotation={[rnd(i) * 3, rnd(i + 2) * 3, 0]}>
          <icosahedronGeometry args={[0.07, 0]} />
          <meshStandardMaterial color="#e8e4da" roughness={1} flatShading />
        </mesh>
      ))}
      <group position={[-0.9, 0, -2.0]} rotation={[0, 0, Math.PI / 2]}>
        <mesh position={[0.07, 0, 0]}>
          <cylinderGeometry args={[0.07, 0.055, 0.2, 14]} />
          <meshStandardMaterial color="#d22d2d" roughness={0.5} />
        </mesh>
      </group>
      <mesh position={[2.2, 0.003, 1.9]} rotation={[-Math.PI / 2, 0, 0]} scale={[1.6, 1, 1]}>
        <circleGeometry args={[0.4, 24]} />
        <meshStandardMaterial color="#141618" metalness={0.6} roughness={0.08} />
      </mesh>
      {showBox ? <PizzaBox position={[-1.15, 0, 0.6]} rotY={0.5} lid={pizzaLid} /> : null}
      <Steam t={t} position={[4.0, 0, 2.0]} />
      {/* tunnel mouth */}
      <group position={[-5.1, TRACK_Y, tunnelZ]}>
        <mesh position={[0, 2.2, 0.01]}>
          <planeGeometry args={[7, 6]} />
          <meshStandardMaterial color="#1a1a1a" roughness={1} />
        </mesh>
        <mesh position={[0, 1.4, 0.02]}>
          <planeGeometry args={[3.4, 2.8]} />
          <meshBasicMaterial color="#020203" />
        </mesh>
        <mesh position={[0, 2.8, 0.02]}>
          <circleGeometry args={[1.7, 32, 0, Math.PI]} />
          <meshBasicMaterial color="#020203" />
        </mesh>
        {headlight > 0 ? (
          <>
            <Glow position={[-0.7, 1.2, 0.3]} size={2.6 * headlight} color="#fff6d0" />
            <Glow position={[0.7, 1.2, 0.3]} size={2.6 * headlight} color="#fff6d0" />
            <Glow position={[0, 1.4, 0.2]} size={9 * headlight} color="#ffe9a8" opacity={0.6} />
            <pointLight position={[0, 1.5, 3]} intensity={30 * headlight} distance={30} decay={1.2} color="#fff0c8" />
          </>
        ) : null}
      </group>
    </>
  );
};
