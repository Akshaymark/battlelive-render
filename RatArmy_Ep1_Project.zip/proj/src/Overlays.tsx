import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';
import {clamp, project} from './cam';
import {Shot, TagSpec} from './Shots';
import {DATE_LABEL, catCount, ratBumpAge, ratCount} from './story';
import VO from './vo_words.json';

export const F = 'Montserrat, sans-serif';
export const MONO = '"RatMono", "DejaVu Sans Mono", monospace';
export const stroke = (w = 4, c = '#000') => ({WebkitTextStroke: `${w}px ${c}`, paintOrder: 'stroke fill' as const});
const pop = (t: number, at: number, dur = 0.25) => {
  const x = clamp((t - at) / dur);
  return x <= 0 ? 0 : 1 + Math.sin(x * Math.PI) * 0.22 * (1 - x);
};
const fmt = (n: number) => n.toLocaleString('en-US');

// ---------------------------------------------------------------- Instagram glyph
export const IgGlyph: React.FC<{size: number}> = ({size}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{flexShrink: 0}}>
    <defs>
      <radialGradient id="igg" cx="30%" cy="107%" r="150%">
        <stop offset="0%" stopColor="#fdf497" />
        <stop offset="5%" stopColor="#fdf497" />
        <stop offset="45%" stopColor="#fd5949" />
        <stop offset="60%" stopColor="#d6249f" />
        <stop offset="90%" stopColor="#285AEB" />
      </radialGradient>
    </defs>
    <rect x="1" y="1" width="22" height="22" rx="6.5" fill="url(#igg)" />
    <rect x="5.2" y="5.2" width="13.6" height="13.6" rx="4.2" fill="none" stroke="#fff" strokeWidth="2" />
    <circle cx="12" cy="12" r="3.3" fill="none" stroke="#fff" strokeWidth="2" />
    <circle cx="16.4" cy="7.6" r="1.1" fill="#fff" />
  </svg>
);

export const TIER_COLORS: Record<string, string> = {SOLDIER: '#5f8f3a', SNIPER: '#2f6fe0', 'ROBOT RAT': '#20a8c8', 'KING SEWER RAT': '#e0a400'};
export const TagPill: React.FC<{text: string; hero?: boolean; scale?: number; tier?: string}> = ({text, hero, scale = 1, tier}) => {
  const fs = (hero ? 34 : 27) * scale;
  return (
    <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: fs * 0.3, background: '#fff', borderRadius: 999, padding: `${fs * 0.22}px ${fs * 0.55}px ${fs * 0.22}px ${fs * 0.28}px`, boxShadow: '0 4px 14px rgba(0,0,0,0.55)', whiteSpace: 'nowrap'}}>
        <IgGlyph size={fs * 1.15} />
        <span style={{fontFamily: F, fontWeight: 800, fontSize: fs, color: '#111', letterSpacing: -0.3}}>{text}</span>
      </div>
      {tier ? (
        <div style={{marginTop: fs * 0.18, background: TIER_COLORS[tier] ?? '#333', color: '#fff', fontFamily: F, fontWeight: 900, fontSize: fs * (tier.startsWith('KING') ? 0.85 : 0.68), letterSpacing: 1, padding: `${fs * 0.08}px ${fs * 0.45}px`, borderRadius: 999, border: '2px solid #fff', whiteSpace: 'nowrap', boxShadow: '0 3px 8px rgba(0,0,0,0.5)'}}>{tier}</div>
      ) : null}
      <div style={{width: 0, height: 0, borderLeft: `${fs * 0.32}px solid transparent`, borderRight: `${fs * 0.32}px solid transparent`, borderTop: `${fs * 0.36}px solid #fff`, marginTop: -1}} />
    </div>
  );
};

export const Tags: React.FC<{t: number; shot: Shot; W: number; H: number}> = ({t, shot, W, H}) => {
  if (!shot.tags) return null;
  const cs = shot.cam(t);
  const list: TagSpec[] = shot.tags(t);
  // draw far ones first
  const placed = list
    .map((tg) => ({tg, s: project(cs, tg.p, W, H)}))
    .filter((o) => !o.s.behind && o.s.y > 360 && o.s.y < H - 40 && (o.tg.hero ? o.s.x > 0 && o.s.x < W : o.s.x > 130 && o.s.x < W - 130))
    .sort((a, b) => a.s.dist - b.s.dist);
  // swarm tags ('s*') are dropped when they would overlap a tag already placed (nearest first)
  const boxes: {x: number; y: number; w: number; h: number}[] = [];
  const kept = placed.filter(({tg, s}) => {
    const sc = tg.hero ? 1.25 : 1;
    const b = {x: s.x, y: s.y, w: 250 * sc, h: (tg.tier ? 95 : 65) * sc};
    const hit = boxes.some((o) => Math.abs(o.x - b.x) < (o.w + b.w) / 2 && Math.abs(o.y - b.y) < (o.h + b.h) / 2);
    if (hit && tg.key.startsWith('s')) return false;
    boxes.push(b);
    return true;
  });
  kept.reverse();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {kept.map(({tg, s}) => {
        const sc = tg.hero ? 1 : clamp(3.6 / s.dist, 0.88, 1.05);
        const k = pop(t, tg.at, 0.28);
        return (
          <div key={tg.key} style={{position: 'absolute', left: s.x, top: s.y, transform: `translate(-50%, -100%) scale(${k})`, transformOrigin: '50% 100%'}}>
            <TagPill text={tg.text} hero={tg.hero} scale={tg.tier?.startsWith('KING') ? 1.25 : sc} tier={tg.tier} />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- HUD
export const HUD: React.FC<{t: number}> = ({t}) => {
  const rc = ratCount(t);
  const age = ratBumpAge(t);
  const rBump = age < 0.3 ? 1 + 0.28 * Math.sin((age / 0.3) * Math.PI) : 1;
  const cBump = t % 1 < 0.15 && t > 0.5 ? 1 + 0.06 * Math.sin(((t % 1) / 0.15) * Math.PI) : 1;
  const blink = Math.floor(t * 1.6) % 2 === 0;
  const diff = age < 0.6 ? rc - ratCount(t - age - 0.01) : 0;
  return (
    <>
      <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 440, background: 'linear-gradient(180deg, rgba(0,0,0,0.78) 0%, rgba(0,0,0,0.45) 60%, rgba(0,0,0,0) 100%)'}} />
      <div style={{position: 'absolute', top: 92, left: 0, right: 0, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 16}}>
        <div style={{width: 24, height: 24, borderRadius: 12, background: '#ff2a3a', opacity: blink ? 1 : 0.35, boxShadow: '0 0 16px #ff2a3a'}} />
        <div style={{fontFamily: F, fontWeight: 900, fontSize: 40, color: '#fff', letterSpacing: 2, ...stroke(3)}}>LIVE BATTLE · {DATE_LABEL}</div>
      </div>
      <div style={{position: 'absolute', top: 170, left: 40, right: 40, display: 'flex'}}>
        <div style={{flex: 1, textAlign: 'center'}}>
          <div style={{fontFamily: F, fontWeight: 900, fontSize: 44, color: '#ff3b47', letterSpacing: 3, ...stroke(3)}}>CAT ARMY</div>
          <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 96, color: '#fff', lineHeight: 1.05, transform: `scale(${cBump})`, ...stroke(4)}}>{fmt(catCount(t))}</div>
        </div>
        <div style={{width: 4, background: 'rgba(255,255,255,0.35)', margin: '10px 0', borderRadius: 2}} />
        <div style={{flex: 1, textAlign: 'center', position: 'relative'}}>
          <div style={{fontFamily: F, fontWeight: 900, fontSize: 44, color: '#ffd21f', letterSpacing: 3, ...stroke(3)}}>RAT ARMY</div>
          <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 96, color: '#fff', lineHeight: 1.05, transform: `scale(${rBump})`, ...stroke(4)}}>{fmt(rc)}</div>
          {diff > 0 ? (
            <div style={{position: 'absolute', right: 30, top: 70 - age * 90, opacity: 1 - age / 0.6, fontFamily: F, fontWeight: 900, fontSize: 48, color: '#7dff6a', ...stroke(4)}}>+{diff}</div>
          ) : null}
        </div>
      </div>
    </>
  );
};

// ---------------------------------------------------------------- callouts
const Callout: React.FC<{t: number; at: number; until: number; x: number; y: number; text: string; color?: string; size?: number; rot?: number}> = ({t, at, until, x, y, text, color = '#ffd21f', size = 52, rot = -4}) => {
  if (t < at || t >= until) return null;
  const k = pop(t, at, 0.22);
  return (
    <div style={{position: 'absolute', left: x, top: y, transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${k})`, background: color, border: '6px solid #000', borderRadius: 18, padding: '6px 26px', fontFamily: F, fontWeight: 900, fontSize: size, color: '#000', whiteSpace: 'nowrap', boxShadow: '0 8px 0 rgba(0,0,0,0.5)'}}>{text}</div>
  );
};

export const Callouts: React.FC<{t: number}> = ({t}) => {
  const roar = t >= 9.55 && t < 11.6;
  const shake = roar ? Math.sin(t * 70) * 10 : 0;
  return (
    <>
      {roar ? (
        <div style={{position: 'absolute', left: 540 + shake, top: 1660, transform: `translate(-50%,-50%) rotate(-6deg) scale(${pop(t, 9.55, 0.2)})`, fontFamily: F, fontWeight: 900, fontSize: 124, color: '#ff3b47', whiteSpace: 'nowrap', ...stroke(12)}}>MRRROOWW!</div>
      ) : null}
      <Callout t={t} at={23.3} until={25.6} x={540} y={1730} text="COMMENT = SOLDIER" size={50} rot={-3} color="#9be36b" />
      <Callout t={t} at={25.9} until={28.3} x={540} y={1730} text="TAG 1 FRIEND = SNIPER" size={46} rot={-4} color="#7fb0ff" />
      <Callout t={t} at={28.5} until={31.6} x={540} y={1730} text="TAG 2 FRIENDS = ROBOT" size={46} rot={4} color="#7fe8ff" />
      <Callout t={t} at={32.0} until={37.2} x={540} y={1730} text="TAG 3 = KING SEWER RAT" size={46} rot={-3} />
      <Callout t={t} at={36.0} until={37.2} x={830} y={1590} text="x2 SIZE" size={60} rot={8} color="#ff3b47" />
      <Callout t={t} at={46.6} until={50.3} x={540} y={1730} text="THE TUNNEL RATS ARE HERE" size={46} color="#7dff6a" rot={-3} />
    </>
  );
};

// ---------------------------------------------------------------- word-by-word captions (from the voiceover word timings)
type W = {w: string; s: number; e: number};
const WORDS: W[] = (() => {
  const raw = VO as W[];
  const out: W[] = [];
  for (const w of raw) {
    if (w.w.startsWith(',') && out.length) {
      const last = out[out.length - 1];
      out[out.length - 1] = {w: last.w + w.w, s: last.s, e: w.e};
    } else out.push({...w});
  }
  return out;
})();
const PHRASES: W[][] = (() => {
  const ph: W[][] = [];
  let cur: W[] = [];
  WORDS.forEach((w, i) => {
    const prev = WORDS[i - 1];
    const gap = prev ? w.s - prev.e : 0;
    if (cur.length && (gap > 0.3 || cur.length >= 4 || (/[.,?!]$/.test(prev.w) && cur.length >= 2))) {
      ph.push(cur);
      cur = [];
    }
    cur.push(w);
  });
  if (cur.length) ph.push(cur);
  return ph;
})();
const norm = (w: string) => w.toLowerCase().replace(/[^a-z0-9']/g, '');
const ACC: Record<string, string> = {
  '100000': '#ff3b47', cats: '#ff3b47', rat: '#ffd21f', soldier: '#9be36b', sniper: '#7fb0ff', robot: '#7fe8ff', king: '#ffd21f',
  sewer: '#ffd21f', double: '#ff3b47', size: '#ff3b47', attack: '#ff3b47', dangerous: '#ff3b47', comment: '#7dff6a', username: '#7dff6a',
  live: '#ff3b47', battle: '#ffd21f', follow: '#ffd21f', army: '#ffd21f', friend: '#7fb0ff', friends: '#7fb0ff', hungry: '#ff3b47',
};
export const Captions: React.FC<{t: number}> = ({t}) => {
  const idx = PHRASES.findIndex((p, i) => {
    const nx = PHRASES[i + 1];
    const end = nx ? Math.min(nx[0].s, p[p.length - 1].e + 0.5) : p[p.length - 1].e + 0.3;
    return t >= p[0].s - 0.05 && t < end;
  });
  if (idx < 0 || t >= 53.6) return null;
  const p = PHRASES[idx];
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: 1270, display: 'flex', justifyContent: 'center', flexWrap: 'wrap', gap: '0 30px', padding: '0 50px'}}>
      {p.map((w, i) => {
        if (t < w.s - 0.02) return null;
        const c = ACC[norm(w.w)] ?? '#ffffff';
        const sc = pop(t, w.s - 0.02, 0.16);
        return (
          <span key={i} style={{fontFamily: F, fontWeight: 900, fontSize: 88, color: c, transform: `scale(${sc})`, display: 'inline-block', lineHeight: 1.1, ...stroke(12), textShadow: '0 8px 0 rgba(0,0,0,0.6)'}}>
            {w.w.replace(/[,.]$/, '').toUpperCase()}
          </span>
        );
      })}
    </div>
  );
};

// ---------------------------------------------------------------- end card
export const EndCard: React.FC<{t: number}> = ({t}) => {
  const a = clamp((t - 53.6) / 0.25);
  const blink = Math.floor(t * 1.6) % 2 === 0;
  return (
    <AbsoluteFill style={{background: '#000', opacity: a, alignItems: 'center', justifyContent: 'center', flexDirection: 'column'}}>
      <div style={{transform: `scale(${pop(t, 53.65, 0.35)})`, textAlign: 'center'}}>
        <div style={{fontFamily: F, fontWeight: 900, fontSize: 132, lineHeight: 1.0, color: '#fff'}}>FOLLOW</div>
        <div style={{fontFamily: F, fontWeight: 900, fontSize: 104, lineHeight: 1.05, color: '#fff'}}>FOR THE</div>
        <div style={{fontFamily: F, fontWeight: 900, fontSize: 150, lineHeight: 1.0, color: '#ffd21f'}}>BATTLE</div>
      </div>
      <div style={{marginTop: 70, opacity: clamp((t - 54.0) / 0.3), display: 'flex', alignItems: 'center', gap: 18, fontFamily: F, fontWeight: 800, fontSize: 46, color: '#fff'}}>
        COMMENT TO JOIN THE <span style={{color: '#ffd21f'}}>RAT ARMY</span>
        <Img src={staticFile('img/rat.svg')} style={{width: 64, height: 64}} />
      </div>
      <div style={{marginTop: 60, opacity: clamp((t - 54.3) / 0.3), display: 'flex', alignItems: 'center', gap: 14, fontFamily: F, fontWeight: 800, fontSize: 34, color: '#bbb', letterSpacing: 2}}>
        <div style={{width: 20, height: 20, borderRadius: 10, background: '#ff2a3a', opacity: blink ? 1 : 0.4}} />
        LIVE · {DATE_LABEL}
      </div>
    </AbsoluteFill>
  );
};
