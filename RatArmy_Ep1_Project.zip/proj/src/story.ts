import {V3, clamp, ease, rnd} from './cam';
import {TRACK_Y} from './Station';

export const FPS = 30;
export const DURATION = 55.5; // seconds (VO ends 53.6, end card to 55.5)
export const HERO_HANDLE = '@wtf_happens_next';
export const RECRUIT_HANDLE = '@your_handle';
export const DATE_LABEL = "NEW YEAR'S EVE 2026";

// ---------------------------------------------------------------- recruits (12-20s)
export type Recruit = {drop: number; x: number; z: number; from: 'box' | 'sky'; tagLift?: number; move?: [number, number]; gear?: {hardhat?: boolean; shield?: boolean; helmet?: boolean; bandana?: string; sniper?: boolean}; fur?: string};
export const BOX_POS: V3 = [0.05, 0, -1.45];
export const RECRUITS: Recruit[] = [
  {drop: 17.2, x: -0.52, z: 0.7, from: 'sky', gear: {helmet: true}, move: [-0.86, 0.15]},
  {drop: 20.9, x: 0.52, z: 0.7, from: 'box', fur: '#7d7f8b', gear: {helmet: true}, move: [0.86, 0.15]},
  {drop: 23.3, x: -0.68, z: -0.4, from: 'sky', gear: {helmet: true}},
  {drop: 23.7, x: 0.68, z: -0.4, from: 'box', fur: '#9a9aa6', gear: {helmet: true}, tagLift: 0.16},
  {drop: 24.1, x: -0.25, z: -0.5, from: 'sky', gear: {helmet: true}, tagLift: 0.12},
  {drop: 24.5, x: 0.25, z: -0.5, from: 'box', fur: '#84868f', gear: {helmet: true}, tagLift: 0.3},
  {drop: 24.9, x: 0.0, z: -1.05, from: 'sky', gear: {helmet: true}, tagLift: 0.65},
];
export const MOVE_AT = 25.7; // front-row soldiers step aside for sniper/robot
export const LAND = 0.42; // seconds from drop start to landing

/** recruit i world position + squash at time t (null = not yet spawned) */
export const recruitAt = (r: Recruit, t: number): {p: V3; squash: number; scale: number} | null => {
  if (t < r.drop) return null;
  const k = clamp((t - r.drop) / LAND);
  const land = t - r.drop - LAND;
  const squash = land > 0 && land < 0.25 ? Math.sin((land / 0.25) * Math.PI) * 0.6 : 0;
  if (r.from === 'sky') {
    const y = 2.6 * (1 - k * k);
    if (r.move && t > MOVE_AT) {
      const m = ease(clamp((t - MOVE_AT) / 0.6));
      return {p: [r.x + (r.move[0] - r.x) * m, Math.abs(Math.sin(m * Math.PI * 3)) * 0.05, r.z + (r.move[1] - r.z) * m], squash: 0, scale: 1};
    }
    return {p: [r.x, y, r.z], squash, scale: 1};
  }
  if (r.move && t > MOVE_AT) {
    const m = ease(clamp((t - MOVE_AT) / 0.6));
    return {p: [r.x + (r.move[0] - r.x) * m, Math.abs(Math.sin(m * Math.PI * 3)) * 0.05, r.z + (r.move[1] - r.z) * m], squash: 0, scale: 1};
  }
  // arc out of the pizza box
  const x = BOX_POS[0] + (r.x - BOX_POS[0]) * k;
  const z = BOX_POS[2] + (r.z - BOX_POS[2]) * k;
  const y = 0.15 + Math.sin(k * Math.PI) * 0.9 - 0.15 * k;
  return {p: [x, y, z], squash, scale: 0.6 + 0.4 * ease(k * 2)};
};

// ---------------------------------------------------------------- upgrades (20-26s)
// tiers: comment = SOLDIER, tag 1 friend = SNIPER, tag 2 = ROBOT (rides the Roomba tank), tag 3 = KING SEWER RAT
// all times are aligned to the voiceover (public/audio/narration.wav, words in src/vo_words.json)
export const ARMOR_IN = 25.8; // SNIPER walks in (left)  "You tagged a friend"
export const TANK_IN = 28.4; // ROBOT rat on the Roomba tank (right)  "tagged two friends"
export const JUMP1 = 26.4; // -> 23
export const JUMP2 = 29.3; // -> 41
export const KING_DROP = 33.8; // "the king sewer rat"
export const KING_LAND = 34.3; // -> 56
export const KING_GROW = 36.0; // "Double size."
export const TIER_FROM = 23.3; // tier pills under tags ("you're a soldier") ...
export const TIER_TO = 53.6; // ... until the end card
export const tankPos = (t: number): V3 => {
  const k = ease(clamp((t - TANK_IN) / 1.2));
  return [2.3 - 1.9 * k, 0, 1.95];
};
export const armorPos = (t: number): V3 => {
  const k = ease(clamp((t - ARMOR_IN) / 1.0));
  return [-2.3 + 1.92 * k, 0, 1.95];
};
// extra recruits that make up the jumps (positions behind the squad)
export const EXTRAS: {x: number; z: number; at: number; fur: string}[] = (() => {
  const out: {x: number; z: number; at: number; fur: string}[] = [];
  const pts: [number, number][] = [];
  for (let row = 0; row < 4; row++) for (let c = 0; c < 9; c++) pts.push([-1.7 + c * 0.42 + (row % 2) * 0.21, -1.35 - row * 0.38]);
  // 15 more come in at JUMP1 (8 + tank rider = 9, +14 = 23), 18 more at JUMP2 (+armor = 24... ) -> 41
  pts.slice(0, 33).forEach(([x, z], i) => {
    out.push({x: x + (rnd(i) - 0.5) * 0.1, z: z + (rnd(i + 9) - 0.5) * 0.1, at: (i < 14 ? JUMP1 : JUMP2) + (i % 14) * 0.035, fur: ['#8e909c', '#7d7f8b', '#9a9aa6', '#84868f'][i % 4]});
  });
  return out;
})();

// ---------------------------------------------------------------- swarm (26-32s)
export const SWARM_FROM = 46.2;
export const SWARM_N = 260;
export const swarmRat = (j: number, t: number) => {
  const spawn = SWARM_FROM + 0.2 + j * 0.016;
  const near = rnd(j * 3 + 1) < 0.7;
  const target = near ? -0.6 - rnd(j * 5 + 4) * 8 : -8.6 - rnd(j * 3 + 1) * 14;
  const x = -6.5 + rnd(j * 7 + 2) * 3.6;
  if (t < spawn) return {p: [x, -50, -40] as V3, ry: 0, live: false};
  const z = Math.min(target, -30 + (t - spawn) * 13);
  return {p: [x, TRACK_Y + 0.12, z] as V3, ry: (rnd(j) - 0.5) * 0.4, live: true};
};

// ---------------------------------------------------------------- counters
export const catCount = (t: number) => 100000 + Math.floor(t);
export const ratCount = (t: number) => {
  let n = 1;
  for (const r of RECRUITS) if (t >= r.drop + LAND) n++;
  if (t >= JUMP1) n = 23;
  if (t >= JUMP2) n = 41;
  if (t >= KING_LAND) n = 56;
  if (t >= 46.6) n = Math.max(56, Math.min(99, 56 + Math.floor(((t - 46.6) / 3.0) * 43)));
  return n;
};
/** time of the last counter change before t (for bump animation) */
export const ratBumpAge = (t: number) => {
  const dt = 1 / FPS;
  const now = ratCount(t);
  for (let a = 0; a < 0.5; a += dt) if (ratCount(t - a) !== now) return a;
  return 9;
};
