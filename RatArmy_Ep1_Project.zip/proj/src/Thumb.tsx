import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {ThumbScene, THUMB_KEYS} from './Shots';
import {useFonts} from './Video';
import {F, MONO, TagPill, stroke} from './Overlays';
import {camState, project} from './cam';
import {DATE_LABEL, HERO_HANDLE} from './story';

export const RatThumb: React.FC = () => {
  useFonts();
  const {width, height} = useVideoConfig();
  const tag = project(camState(THUMB_KEYS, 0), [0, 0.9, 0.2], width, height);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <ThreeCanvas width={width} height={height} gl={{preserveDrawingBuffer: true, antialias: true}}>
        <ThumbScene />
      </ThreeCanvas>
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.2) 32%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.85) 100%)'}} />
      <div style={{position: 'absolute', top: 90, left: 0, right: 0, textAlign: 'center'}}>
        <div style={{display: 'inline-flex', alignItems: 'center', gap: 14, background: '#ff2a3a', borderRadius: 14, padding: '6px 26px', fontFamily: F, fontWeight: 900, fontSize: 40, color: '#fff'}}>
          <div style={{width: 18, height: 18, borderRadius: 9, background: '#fff'}} /> LIVE BATTLE · {DATE_LABEL}
        </div>
        <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 150, lineHeight: 1.0, color: '#ff3b47', marginTop: 34, ...stroke(12)}}>100,000</div>
        <div style={{fontFamily: F, fontWeight: 900, fontSize: 120, lineHeight: 0.95, color: '#fff', ...stroke(12)}}>CATS</div>
        <div style={{fontFamily: F, fontWeight: 900, fontSize: 76, lineHeight: 1.1, color: '#fff', ...stroke(9)}}>vs</div>
        <div style={{fontFamily: F, fontWeight: 900, fontSize: 132, lineHeight: 0.95, color: '#ffd21f', ...stroke(12)}}>1 RAT</div>
      </div>
      <div style={{position: 'absolute', left: tag.x, top: tag.y, transform: 'translate(-50%,-100%)'}}>
        <TagPill text={HERO_HANDLE} hero scale={1.2} />
      </div>
      <div style={{position: 'absolute', bottom: 90, left: 0, right: 0, textAlign: 'center', fontFamily: F, fontWeight: 900, fontSize: 54, color: '#fff', ...stroke(8)}}>
        COMMENT TO <span style={{color: '#ffd21f'}}>JOIN HIS ARMY</span>
      </div>
    </AbsoluteFill>
  );
};
