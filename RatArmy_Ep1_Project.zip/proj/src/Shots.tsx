import React, {useLayoutEffect, useMemo} from 'react';
import * as THREE from 'three';
import {useThree} from '@react-three/fiber';
import {CamKey, CamState, V3, applyCam, camState, clamp, punchAt, ramp, rnd} from './cam';
import {Cat, CatCrowd, Rat, RatSwarm, RoombaTank, makeCatCrowd, SwarmRat} from './Characters';
import {Station, PizzaBox, TRACK_Y} from './Station';
import {KING_GROW, MOVE_AT, KING_DROP, KING_LAND, TIER_FROM, TIER_TO, ARMOR_IN, BOX_POS, SWARM_FROM, EXTRAS, HERO_HANDLE, RECRUITS, RECRUIT_HANDLE, SWARM_N, TANK_IN, armorPos, recruitAt, swarmRat, tankPos} from './story';

export type TagSpec = {p: V3; text: string; hero?: boolean; at: number; key: string; tier?: string};
export type Shot = {id: string; from: number; to: number; cam: (t: number) => CamState; Comp: React.FC<{t: number}>; tags?: (t: number) => TagSpec[]; end?: boolean};

export const CamRig: React.FC<{s: CamState}> = ({s}) => {
  const {camera, size} = useThree();
  useLayoutEffect(() => {
    applyCam(camera as THREE.PerspectiveCamera, s, size.width / size.height);
  }, [camera, s, size.width, size.height]);
  return null;
};

// shared crowds (built once)
const PLATFORM_CATS = makeCatCrowd({x0: -2.3, x1: 8.6, z0: -3.45, z1: -40, seed: 1});
const TRACK_CATS = makeCatCrowd({x0: -7.8, x1: -2.9, z0: -3.6, z1: -40, seed: 2}).map((c) => ({...c, p: [c.p[0], TRACK_Y, c.p[2]] as V3}));
const ALL_CATS = [...PLATFORM_CATS, ...TRACK_CATS];
// remove the cats that would clip the boss
const CATS_NO_BOSS = ALL_CATS.filter((c) => !(Math.abs(c.p[0] - 1.6) < 1.0 && c.p[2] > -5.2));

export const BOSS_POS: V3 = [1.6, 0, -3.75];
const HERO: V3 = [0, 0, 0.2];
const tagAbove = (p: V3, h = 0.66, s = 1): V3 => [p[0], p[1] + h * s, p[2]];
const tierAt = (t: number, tier: string) => (t >= TIER_FROM && t < TIER_TO ? tier : undefined);

// ================================================================ 0-3 wide crowd
const WIDE_KEYS: CamKey[] = [
  {t: 0, pos: [-1.5, 3.9, 7.0], at: [2.0, -0.4, -9], fov: 52},
  {t: 4, pos: [-1.0, 3.0, 4.8], at: [1.8, -0.2, -9], fov: 50},
];
const Wide: React.FC<{t: number}> = ({t}) => (
  <>
    <Station t={t} fog={['#0a0e12', 6, 30]} />
    <CatCrowd t={t} cats={ALL_CATS} />
    <Cat t={t} boss position={BOSS_POS} scale={1.7} fat={1.25} />
    <Rat t={t} position={HERO} rotY={Math.PI - 0.3} gear={{crust: true}} nervous={1} />
  </>
);

// ================================================================ 3-6 hero close-up
const HERO_KEYS: CamKey[] = [
  {t: 4, pos: [0.25, 0.45, 1.75], at: [0, 0.38, 0.2], fov: 40},
  {t: 6.3, pos: [0.12, 0.42, 1.45], at: [0, 0.4, 0.2], fov: 38},
];
// 14.5-16.5 'But you can change this' push-in
const PUSH_KEYS: CamKey[] = [
  {t: 14.5, pos: [-0.25, 0.5, 2.4], at: [0, 0.36, 0.2], fov: 42},
  {t: 16.5, pos: [-0.05, 0.42, 1.3], at: [0, 0.4, 0.2], fov: 38},
];
const HeroClose: React.FC<{t: number}> = ({t}) => (
  <>
    <Station t={t} fog={['#0a0e12', 3, 16]} />
    <CatCrowd t={t} cats={ALL_CATS} />
    <Rat t={t} position={HERO} gear={{crust: true}} nervous={t < 15.4 ? 1 : 0} sweat={t < 15.4} determined={t >= 15.4} />
  </>
);

// ================================================================ 6-9 boss roar
const ROAR_AT = 9.5; // "They're hungry"
const ROAR_END = 11.5;
const roarAmt = (t: number) => (t < ROAR_AT ? 0 : t < ROAR_AT + 0.25 ? (t - ROAR_AT) / 0.25 : t < ROAR_END ? 1 : Math.max(0, 1 - (t - ROAR_END) / 0.4));
const BOSS_KEYS: CamKey[] = [
  {t: 6.3, pos: [2.6, 1.6, 1.4], at: [1.6, 1.2, -3.75], fov: 42},
  {t: 9.4, pos: [2.0, 1.75, 0.9], at: [1.6, 1.2, -3.75], fov: 40},
];
const ROAR_KEYS: CamKey[] = [
  {t: 9.4, pos: [1.6, 1.8, 0.5], at: [1.6, 1.2, -3.75], fov: 40},
  {t: 12.3, pos: [1.6, 1.7, -0.2], at: [1.6, 1.25, -3.75], fov: 40},
];
const BossLights: React.FC<{red: number}> = ({red}) => (
  <>
    <pointLight position={[1.6, 2.2, -2.0]} intensity={5} distance={6} decay={1.5} color="#ffe2c0" />
    <pointLight position={[0.2, 1.0, -3.0]} intensity={6 * red} distance={5} decay={1.5} color="#ff2a3a" />
    <pointLight position={[3.0, 1.0, -3.0]} intensity={6 * red} distance={5} decay={1.5} color="#ff2a3a" />
  </>
);
const BossRoar: React.FC<{t: number}> = ({t}) => (
  <>
    <Station t={t} fog={['#0a0e12', 2, 14]} />
    <BossLights red={roarAmt(t)} />
    <CatCrowd t={t} cats={CATS_NO_BOSS} bounce={1 + roarAmt(t) * 2} />
    <Cat t={t} boss position={BOSS_POS} scale={1.7} fat={1.25} roar={roarAmt(t)} />
  </>
);

// ================================================================ 9-12 rat alone vs wall
const ALONE_KEYS: CamKey[] = [
  {t: 12.3, pos: [-0.3, 0.95, 2.9], at: [0.75, 0.7, -4], fov: 50},
  {t: 14.5, pos: [-0.2, 0.85, 2.4], at: [0.7, 0.7, -4], fov: 48},
];
const Alone: React.FC<{t: number}> = ({t}) => (
  <>
    <Station t={t} fog={['#0a0e12', 5, 24]} />
    <CatCrowd t={t} cats={ALL_CATS} />
    <Cat t={t} boss position={BOSS_POS} scale={1.7} fat={1.25} />
    <Rat t={t} position={HERO} rotY={-1.2} gear={{crust: true}} nervous={0.5} sweat />
  </>
);

// ================================================================ 12-20 recruits
const squadCam = (t: number): CamKey[] => [
  {t: 16.5, pos: [0, 1.1, 3.8], at: [0, 0.32, -0.1], fov: 45},
  {t: 22.5, pos: [0, 1.2, 4.0], at: [0, 0.33, -0.1], fov: 45},
  {t: 25.6, pos: [0.05, 1.3, 4.5], at: [0, 0.35, -0.1], fov: 45},
];
const RECRUIT_KEYS = squadCam(0);
const Squad: React.FC<{t: number; showRecruits?: boolean}> = ({t}) => (
  <>
    {RECRUITS.map((r, i) => {
      const st = recruitAt(r, t);
      if (!st) return null;
      return <Rat key={i} t={t + i} position={st.p} scale={st.scale} squash={st.squash} fur={r.fur} gear={r.gear} determined={t > r.drop + 0.8} look={-r.x * 0.5} />;
    })}
    <Rat t={t} position={HERO} gear={{crust: true}} nervous={t < 18 ? 0.6 : 0} determined={t > 19.5} />
  </>
);
const Recruits: React.FC<{t: number}> = ({t}) => {
  const lidOpen = RECRUITS.some((r) => r.from === 'box' && t > r.drop - 0.15 && t < r.drop + 0.35) ? 1 : 0.25;
  return (
    <>
      <Station t={t} fog={['#0a0e12', 5, 22]} showBox={false} />
      <PizzaBox position={BOX_POS} lid={lidOpen} s={1.1} />
      <CatCrowd t={t} cats={ALL_CATS} />
      <Squad t={t} />
    </>
  );
};
const recruitTags = (t: number): TagSpec[] => {
  const out: TagSpec[] = [{p: tagAbove(HERO, 0.7), text: HERO_HANDLE, hero: true, at: 0, key: 'hero'}];
  RECRUITS.forEach((r, i) => {
    const st = recruitAt(r, t);
    if (st && t > r.drop + 0.2) out.push({p: tagAbove(st.p, (r.gear?.hardhat || r.gear?.helmet ? 0.74 : 0.66) + (r.tagLift ?? 0)), text: RECRUIT_HANDLE, at: r.drop + 0.2, key: `r${i}`, tier: tierAt(t, 'SOLDIER')});
  });
  return out;
};

// ================================================================ 20-26 upgrades
const UPG_KEYS: CamKey[] = [
  {t: 25.6, pos: [0.05, 1.3, 4.5], at: [0, 0.35, -0.1], fov: 46},
  {t: 31.6, pos: [0.1, 1.75, 5.6], at: [0, 0.3, -0.3], fov: 46},
];
const extrasSwarm = (t: number): SwarmRat[] =>
  EXTRAS.map((e, i) => {
    const k = clamp((t - e.at) / 0.35);
    const y = t < e.at ? -50 : 1.6 * (1 - k * k);
    return {p: [e.x, y, e.z], ry: (rnd(i) - 0.5) * 0.5, s: 0.95, ph: i};
  });
const Upgrades: React.FC<{t: number}> = ({t}) => {
  const tp = tankPos(t);
  const ap = armorPos(t);
  return (
    <>
      <Station t={t} fog={['#0a0e12', 6, 24]} showBox={false} />
      <PizzaBox position={BOX_POS} lid={0.25} s={1.1} />
      <CatCrowd t={t} cats={ALL_CATS} />
      <Squad t={t} />
      <RatSwarm t={t} rats={extrasSwarm(t)} />
      {t >= TANK_IN ? (
        <>
          <RoombaTank t={t} position={tp} rotY={-0.25} scale={1.05} />
          <Rat t={t} position={[tp[0] - 0.05, 0.12, tp[2] - 0.05]} rotY={-0.25} gear={{robot: true}} fur="#aeb6c2" determined />
        </>
      ) : null}
      {t >= ARMOR_IN ? <Rat t={t} position={ap} rotY={0.3} gear={{sniper: true, helmet: true}} fur="#7d7f8b" determined hop={Math.abs(Math.sin(t * 9)) * 0.04 * (t < ARMOR_IN + 1 ? 1 : 0)} /> : null}
    </>
  );
};
const upgradeTags = (t: number): TagSpec[] => {
  const out = recruitTags(t);
  if (t >= TANK_IN) out.push({p: tagAbove(tankPos(t), 0.95), text: RECRUIT_HANDLE, at: TANK_IN, key: 'tank', tier: 'ROBOT RAT'});
  if (t >= ARMOR_IN) out.push({p: tagAbove(armorPos(t), 0.74), text: RECRUIT_HANDLE, at: ARMOR_IN, key: 'armor', tier: 'SNIPER'});
  return out;
};

// ================================================================ 26-30 KING SEWER RAT (tagged 3 friends) drops in at double size
const KING_POS: V3 = [0, 0, 2.3];
const KING_KEYS: CamKey[] = [
  {t: 31.6, pos: [0, 1.1, 6.2], at: [0, 0.6, 1.2], fov: 48},
  {t: 34.3, pos: [0, 0.7, 5.6], at: [0, 0.8, 1.4], fov: 48},
  {t: 37.2, pos: [0, 0.6, 5.3], at: [0, 0.95, 1.6], fov: 48},
];
const kingY = (t: number) => {
  const k = clamp((t - KING_DROP) / (KING_LAND - KING_DROP));
  return 3.2 * (1 - k * k);
};
const kingScale = (t: number) => {
  const g = clamp((t - KING_GROW) / 0.35);
  return 1 + g + Math.sin(g * Math.PI) * 0.25;
};
const KingShot: React.FC<{t: number}> = ({t}) => {
  const land = t - KING_LAND;
  const squash = land > 0 && land < 0.35 ? Math.sin((land / 0.35) * Math.PI) * 0.5 : 0;
  return (
    <>
      <Upgrades t={t} />
      <pointLight position={[0, 2.2, 3.6]} intensity={8} distance={6} decay={1.5} color="#ffe2a0" />
      {t >= KING_DROP ? <Rat t={t} position={[KING_POS[0], kingY(t), KING_POS[2]]} scale={kingScale(t)} squash={squash} fur="#6f6a74" gear={{king: true}} determined /> : null}
    </>
  );
};
const kingTags = (t: number): TagSpec[] =>
  t >= KING_LAND ? [{p: [KING_POS[0], 0.72 * kingScale(t), KING_POS[2]], text: RECRUIT_HANDLE, at: KING_LAND, key: 'king', tier: 'KING SEWER RAT'}] : [];

// ================================================================ 37.2-42.2 lineup: Soldier / Sniper / Robot / King (cut on each word)
const SOLDIER_P: V3 = [-0.86, 0, 0.15];
const LINE_SOLDIER: CamKey[] = [{t: 37.2, pos: [-0.95, 0.62, 1.55], at: [-0.86, 0.42, 0.15], fov: 48}, {t: 38.5, pos: [-0.95, 0.6, 1.45], at: [-0.86, 0.42, 0.15], fov: 46}];
const LINE_SNIPER: CamKey[] = [{t: 38.5, pos: [-0.95, 0.58, 3.8], at: [-0.38, 0.45, 1.95], fov: 42}, {t: 39.6, pos: [-0.92, 0.56, 3.65], at: [-0.38, 0.45, 1.95], fov: 40}];
const LINE_ROBOT: CamKey[] = [{t: 39.6, pos: [1.3, 0.75, 3.75], at: [0.38, 0.5, 1.95], fov: 42}, {t: 40.8, pos: [1.25, 0.72, 3.6], at: [0.38, 0.5, 1.95], fov: 40}];
const LINE_KING: CamKey[] = [{t: 40.8, pos: [0, 0.8, 5.4], at: [0, 1.0, 2.3], fov: 44}, {t: 42.2, pos: [0, 0.85, 4.9], at: [0, 1.05, 2.3], fov: 42}];
const lineTag = (key: string, p: V3, tier: string, at: number) => (): TagSpec[] => [{p, text: RECRUIT_HANDLE, at, key, tier}];


// ================================================================ 30-36 swarm from the tunnel
const SWARM_KEYS: CamKey[] = [
  {t: 46.2, pos: [-4.45, -0.35, 4.2], at: [-5.0, -0.75, -30], fov: 48},
  {t: 50.3, pos: [-4.5, -0.45, 3.5], at: [-5.0, -0.8, -30], fov: 46},
];
const OUTRO_KEYS: CamKey[] = [
  {t: 50.3, pos: [-4.55, -0.5, 3.0], at: [-4.75, -0.85, 1.0], fov: 46},
  {t: 53.6, pos: [-4.7, -0.62, 2.35], at: [-4.75, -0.82, 1.0], fov: 42},
];
const SWARM_HERO: V3 = [-4.75, TRACK_Y + 0.12, 1.0];
const headlightAmt = (t: number) => clamp((t - 46.4) / 1.2) * (0.85 + Math.sin(t * 3) * 0.05);
const Swarm: React.FC<{t: number}> = ({t}) => {
  const rats = useMemo(() => Array.from({length: SWARM_N}, (_, j) => j), []);
  const sw: SwarmRat[] = rats.map((j) => {
    const r = swarmRat(j, t);
    return {p: r.p, ry: r.ry, s: 1.0, ph: j};
  });
  return (
    <>
      <Station t={t} fog={['#0a0e12', 9, 46]} headlight={headlightAmt(t)} tunnelZ={-34} />
      <pointLight position={[-4.5, 0.6, 3.2]} intensity={7} distance={14} decay={1.4} color="#cfe6ff" />
      <pointLight position={[-4.8, 0.8, -4]} intensity={9} distance={12} decay={1.4} color="#ffe7b8" />
      <pointLight position={[-4.8, 0.8, -12]} intensity={9} distance={12} decay={1.4} color="#ffe7b8" />
      <RatSwarm t={t} rats={sw} />
      <Rat t={t} position={SWARM_HERO} rotY={0.15} gear={{crust: true}} determined />
    </>
  );
};
const swarmTags = (t: number): TagSpec[] => {
  const out: TagSpec[] = [{p: tagAbove(SWARM_HERO, 0.66), text: HERO_HANDLE, hero: true, at: 0, key: 'hero'}];
  for (let j = 0; j < SWARM_N; j++) {
    const r = swarmRat(j, t);
    if (!r.live) continue;
    if (r.p[2] < -6 || j % 3) continue;
    out.push({p: tagAbove(r.p, 0.66), text: RECRUIT_HANDLE, at: SWARM_FROM + 1, key: `s${j}`, tier: tierAt(t, 'SOLDIER')});
  }
  return out.slice(0, 9);
};


// ================================================================ 32-35 boss cliffhanger
const STARE_KEYS: CamKey[] = [
  {t: 42.2, pos: [1.6, 1.7, 2.6], at: [1.6, 1.3, -3.75], fov: 40},
  {t: 44.0, pos: [1.6, 1.55, 1.1], at: [1.6, 1.45, -3.75], fov: 30},
  {t: 46.2, pos: [1.6, 1.55, 0.9], at: [1.68, 1.5, -3.75], fov: 24},
];
const Stare: React.FC<{t: number}> = ({t}) => (
  <>
    <Station t={t} fog={['#07090c', 3, 10]} bright={0.6} noFence />
    <BossLights red={0.6 + 0.4 * ramp(t, 43.9, 45.0)} />
    <CatCrowd t={t} cats={CATS_NO_BOSS} />
    <Cat t={t} boss position={BOSS_POS} scale={1.7} fat={1.25} narrow={ramp(t, 44.2, 45.1)} />
  </>
);

const EndCard: React.FC<{t: number}> = () => null;

export const SHOTS: Shot[] = [
  {id: 'wide', from: 0, to: 4.0, cam: (t) => camState(WIDE_KEYS, t, 0, punchAt(t, [0.05])), Comp: Wide},
  {id: 'hero', from: 4.0, to: 6.3, cam: (t) => camState(HERO_KEYS, t, 0, punchAt(t, [4.0])), Comp: HeroClose, tags: () => [{p: tagAbove(HERO, 0.6), text: HERO_HANDLE, hero: true, at: 4.2, key: 'hero'}]},
  {id: 'boss', from: 6.3, to: 9.4, cam: (t) => camState(BOSS_KEYS, t, 0, punchAt(t, [6.3, 8.36])), Comp: BossRoar},
  {id: 'roar', from: 9.4, to: 12.3, cam: (t) => camState(ROAR_KEYS, t, roarAmt(t) * (t < ROAR_END ? 1 : 0.4), punchAt(t, [ROAR_AT, 11.16])), Comp: BossRoar},
  {id: 'alone', from: 12.3, to: 14.5, cam: (t) => camState(ALONE_KEYS, t, 0, punchAt(t, [12.3])), Comp: Alone, tags: () => [{p: tagAbove(HERO, 0.7), text: HERO_HANDLE, hero: true, at: 12.3, key: 'hero'}]},
  {id: 'pushin', from: 14.5, to: 16.5, cam: (t) => camState(PUSH_KEYS, t, 0, punchAt(t, [15.48])), Comp: HeroClose, tags: () => [{p: tagAbove(HERO, 0.6), text: HERO_HANDLE, hero: true, at: 14.5, key: 'hero'}]},
  {id: 'recruits', from: 16.5, to: 25.6, cam: (t) => camState(RECRUIT_KEYS, t, 0, punchAt(t, RECRUITS.map((r) => r.drop + 0.42), 0.2) * 0.5), Comp: Recruits, tags: recruitTags},
  {id: 'upgrades', from: 25.6, to: 31.6, cam: (t) => camState(UPG_KEYS, t, 0, punchAt(t, [26.4, 29.3])), Comp: Upgrades, tags: upgradeTags},
  {id: 'king', from: 31.6, to: 37.2, cam: (t) => camState(KING_KEYS, t, (t > KING_LAND && t < KING_LAND + 0.5) || (t > KING_GROW && t < KING_GROW + 0.45) ? 0.5 : 0, punchAt(t, [KING_LAND, KING_GROW], 0.5)), Comp: KingShot, tags: kingTags},
  {id: 'l-soldier', from: 37.2, to: 38.5, cam: (t) => camState(LINE_SOLDIER, t, 0, punchAt(t, [37.36])), Comp: KingShot, tags: lineTag('ls', tagAbove(SOLDIER_P, 0.74), 'SOLDIER', 37.25)},
  {id: 'l-sniper', from: 38.5, to: 39.6, cam: (t) => camState(LINE_SNIPER, t, 0, punchAt(t, [38.56])), Comp: KingShot, tags: lineTag('lsn', [-0.38, 0.74, 1.95], 'SNIPER', 38.55)},
  {id: 'l-robot', from: 39.6, to: 40.8, cam: (t) => camState(LINE_ROBOT, t, 0, punchAt(t, [39.62])), Comp: KingShot, tags: lineTag('lr', [0.4, 0.84, 1.95], 'ROBOT RAT', 39.65)},
  {id: 'l-king', from: 40.8, to: 42.2, cam: (t) => camState(LINE_KING, t, t > 41.2 && t < 41.6 ? 0.4 : 0, punchAt(t, [41.2])), Comp: KingShot, tags: lineTag('lk', [0, 1.44, 2.3], 'KING SEWER RAT', 40.85)},
  {id: 'stare', from: 42.2, to: 46.2, cam: (t) => camState(STARE_KEYS, t, 0, punchAt(t, [44.5])), Comp: Stare},
  {id: 'swarm', from: 46.2, to: 50.3, cam: (t) => camState(SWARM_KEYS, t, t > 47.2 ? 0.12 : 0, punchAt(t, [47.2, 48.94])), Comp: Swarm, tags: swarmTags},
  {id: 'outro', from: 50.3, to: 53.6, cam: (t) => camState(OUTRO_KEYS, t, 0, punchAt(t, [51.92])), Comp: Swarm, tags: swarmTags},
  {id: 'end', from: 53.6, to: 55.51, cam: (t) => camState(STARE_KEYS, t), Comp: EndCard, end: true},
];


// ================================================================ thumbnail scene
export const THUMB_KEYS: CamKey[] = [{t: 0, pos: [-0.55, 0.72, 2.7], at: [0.75, 0.95, -4], fov: 50}];
export const ThumbScene: React.FC = () => {
  const t = 10;
  return (
    <>
      <Station t={1.2} fog={['#0a0e12', 5, 24]} />
      <CatCrowd t={t} cats={ALL_CATS} />
      <Cat t={t} boss position={BOSS_POS} scale={1.7} fat={1.25} roar={0.7} />
      <Rat t={t} position={[0, 0, 0.2]} rotY={0.85} scale={1.3} gear={{crust: true}} determined />
      <pointLight position={[-0.6, 1.2, 1.6]} intensity={5} distance={4} decay={1.5} color="#dfeaff" />
      <CamRig s={camState(THUMB_KEYS, 0)} />
    </>
  );
};
