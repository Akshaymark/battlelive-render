import React from 'react';
import {Composition} from 'remotion';
import {RatArmy1} from './Video';
import {RatThumb} from './Thumb';
import {DURATION, FPS} from './story';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition id="RatArmy1" component={RatArmy1} durationInFrames={DURATION * FPS} fps={FPS} width={1080} height={1920} />
    <Composition id="RatThumb" component={RatThumb} durationInFrames={1} fps={FPS} width={1080} height={1920} />
  </>
);
