import React, {useEffect, useState} from 'react';
import {AbsoluteFill, Audio, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {CamRig, SHOTS} from './Shots';
import {Callouts, Captions, EndCard, HUD, Tags} from './Overlays';

export const useFonts = () => {
  const [h] = useState(() => delayRender('fonts'));
  useEffect(() => {
    const fonts = [
      new FontFace('Montserrat', `url(${staticFile('fonts/Montserrat.ttf')})`, {weight: '100 900'}),
      new FontFace('RatMono', `url(${staticFile('fonts/DejaVuSansMono-Bold.ttf')})`, {weight: '700'}),
    ];
    Promise.all(fonts.map((f) => f.load()))
      .then((ls) => {
        ls.forEach((l) => (document.fonts as any).add(l));
        continueRender(h);
      })
      .catch(() => continueRender(h));
  }, [h]);
};

export const RatArmy1: React.FC = () => {
  useFonts();
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = frame / fps;
  const shot = SHOTS.find((s) => t >= s.from && t < s.to) ?? SHOTS[SHOTS.length - 1];
  const flash = SHOTS.reduce((m, s) => (s.from > 0 && !s.end && t >= s.from && t < s.from + 0.1 ? Math.max(m, 1 - (t - s.from) / 0.1) : m), 0);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {shot.end ? (
        <EndCard t={t} />
      ) : (
        <>
          <ThreeCanvas key={shot.id} width={width} height={height} gl={{antialias: true, preserveDrawingBuffer: true}}>
            <shot.Comp t={t} />
            <CamRig s={shot.cam(t)} />
          </ThreeCanvas>
          <AbsoluteFill style={{pointerEvents: 'none', background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.5) 100%)'}} />
          <Tags t={t} shot={shot} W={width} H={height} />
          <Callouts t={t} />
          <Captions t={t} />
          <HUD t={t} />
          {flash > 0 ? <AbsoluteFill style={{background: '#fff', opacity: flash * 0.5}} /> : null}
        </>
      )}
      <Audio src={staticFile('audio/ratarmy_bed.wav')} volume={0.5} />
      <Audio src={staticFile('audio/narration.wav')} />
    </AbsoluteFill>
  );
};
