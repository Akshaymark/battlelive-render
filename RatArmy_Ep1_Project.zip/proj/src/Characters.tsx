import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {V3, rnd} from './cam';

const M: React.FC<{c: string; r?: number; e?: string; ei?: number; m?: number}> = ({c, r = 0.55, e, ei = 0, m = 0}) => (
  <meshStandardMaterial color={c} roughness={r} metalness={m} emissive={e ?? '#000000'} emissiveIntensity={ei} />
);

const tubeGeo = (pts: V3[], r: number) => new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map((p) => new THREE.Vector3(...p))), 24, r, 8, false);

// ---------------------------------------------------------------- canvas textures
export const useCanvasTex = (w: number, h: number, draw: (g: CanvasRenderingContext2D) => void, deps: unknown[] = []) =>
  useMemo(() => {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    draw(c.getContext('2d')!);
    const tx = new THREE.CanvasTexture(c);
    tx.colorSpace = THREE.SRGBColorSpace;
    tx.anisotropy = 4;
    return tx;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

// ================================================================ RAT
export type RatGear = {crust?: boolean; hardhat?: boolean; shield?: boolean; pizzaArmor?: boolean; helmet?: boolean; bandana?: string; sniper?: boolean; robot?: boolean; king?: boolean};
export type RatProps = {
  t: number;
  position?: V3;
  rotY?: number;
  scale?: number;
  fur?: string;
  gear?: RatGear;
  nervous?: number; // 0..1 shiver + darting eyes
  hop?: number; // vertical offset
  look?: number; // eye look x -1..1
  sweat?: boolean;
  squash?: number;
  determined?: boolean;
};

const MetroCard: React.FC = () => {
  const tex = useCanvasTex(256, 160, (g) => {
    g.fillStyle = '#ffcf1a';
    g.fillRect(0, 0, 256, 160);
    g.fillStyle = '#1a3f9e';
    g.font = 'bold italic 46px Arial';
    g.fillText('Metro', 18, 62);
    g.fillStyle = '#1a3f9e';
    g.fillText('Card', 140, 62);
    g.fillStyle = '#111';
    g.fillRect(0, 100, 256, 26);
    g.fillStyle = '#1a3f9e';
    g.font = 'bold 20px Arial';
    g.fillText('NYC TRANSIT', 20, 150);
  });
  return (
    <mesh>
      <boxGeometry args={[0.26, 0.17, 0.012]} />
      <meshStandardMaterial attach="material-0" color="#ffcf1a" />
      <meshStandardMaterial attach="material-1" color="#ffcf1a" />
      <meshStandardMaterial attach="material-2" color="#ffcf1a" />
      <meshStandardMaterial attach="material-3" color="#ffcf1a" />
      <meshStandardMaterial attach="material-4" map={tex} roughness={0.35} />
      <meshStandardMaterial attach="material-5" color="#ffcf1a" />
    </mesh>
  );
};

const PizzaBoxArmor: React.FC = () => {
  const tex = useCanvasTex(256, 256, (g) => {
    g.fillStyle = '#d7b07a';
    g.fillRect(0, 0, 256, 256);
    g.strokeStyle = '#b8894f';
    g.lineWidth = 6;
    g.strokeRect(8, 8, 240, 240);
    g.fillStyle = '#d6262f';
    g.beginPath();
    g.arc(128, 110, 70, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = '#fff';
    g.font = 'bold 44px Arial';
    g.textAlign = 'center';
    g.fillText('PIZZA', 128, 125);
    g.fillStyle = '#d6262f';
    g.font = 'bold 30px Arial';
    g.fillText('HOT!', 128, 225);
  });
  return (
    <group position={[0, 0.17, 0.01]}>
      <mesh>
        <boxGeometry args={[0.38, 0.27, 0.36]} />
        <meshStandardMaterial color="#d7b07a" roughness={0.9} />
      </mesh>
      <mesh position={[0, 0, 0.181]}>
        <planeGeometry args={[0.36, 0.26]} />
        <meshStandardMaterial map={tex} roughness={0.9} />
      </mesh>
      {/* shoulder flaps */}
      <mesh position={[0.2, 0.12, 0]} rotation={[0, 0, -0.5]}>
        <boxGeometry args={[0.12, 0.012, 0.3]} />
        <meshStandardMaterial color="#c9a06a" roughness={0.9} />
      </mesh>
      <mesh position={[-0.2, 0.12, 0]} rotation={[0, 0, 0.5]}>
        <boxGeometry args={[0.12, 0.012, 0.3]} />
        <meshStandardMaterial color="#c9a06a" roughness={0.9} />
      </mesh>
    </group>
  );
};

export const Crust: React.FC<{position?: V3; rot?: V3; s?: number}> = ({position = [0, 0, 0], rot = [0, 0, 0], s = 1}) => (
  <group position={position} rotation={rot} scale={s}>
    <mesh rotation={[0, 0, 0.2]}>
      <torusGeometry args={[0.075, 0.032, 10, 16, Math.PI * 1.1]} />
      <M c="#d9a04f" r={0.8} />
    </mesh>
    {/* bitten cheese bit */}
    <mesh position={[0.02, 0.05, 0.01]} rotation={[0, 0, -0.3]} scale={[1, 0.35, 0.6]}>
      <sphereGeometry args={[0.05, 10, 8]} />
      <M c="#ffd35c" r={0.5} />
    </mesh>
  </group>
);

const Rifle: React.FC = () => (
  <group position={[0.03, 0.2, 0.22]} rotation={[0.25, 0, 0.95]} scale={1.35}>
    <mesh position={[0, -0.07, 0]}>
      <boxGeometry args={[0.05, 0.12, 0.035]} />
      <M c="#6b4426" r={0.7} />
    </mesh>
    <mesh position={[0, 0.06, 0]}>
      <boxGeometry args={[0.04, 0.14, 0.04]} />
      <M c="#2d3128" r={0.5} m={0.4} />
    </mesh>
    <mesh position={[0, 0.22, 0]}>
      <cylinderGeometry args={[0.009, 0.009, 0.22, 8]} />
      <M c="#1d1f22" r={0.3} m={0.7} />
    </mesh>
    {/* scope */}
    <mesh position={[0, 0.07, 0.035]}>
      <cylinderGeometry args={[0.016, 0.016, 0.11, 12]} />
      <M c="#111" r={0.3} m={0.6} />
    </mesh>
    <mesh position={[0, 0.128, 0.035]}>
      <cylinderGeometry args={[0.014, 0.014, 0.004, 12]} />
      <meshBasicMaterial color="#7fd8ff" />
    </mesh>
  </group>
);

const RobotSuit: React.FC<{t: number}> = ({t}) => (
  <>
    <mesh position={[0, 0.17, 0.02]} scale={[1, 0.95, 1.12]}>
      <sphereGeometry args={[0.158, 24, 18]} />
      <M c="#c9d1dc" r={0.35} m={0.3} />
    </mesh>
    <mesh position={[0, 0.17, 0.165]}>
      <boxGeometry args={[0.16, 0.12, 0.03]} />
      <M c="#6d7888" r={0.35} m={0.3} />
    </mesh>
    <mesh position={[0, 0.17, 0.182]}>
      <circleGeometry args={[0.03, 16]} />
      <meshBasicMaterial color={Math.sin(t * 6) > 0 ? '#40e0ff' : '#1a7a90'} toneMapped={false} />
    </mesh>
    {[-1, 1].map((s) => (
      <mesh key={s} position={[s * 0.15, 0.24, 0.02]}>
        <sphereGeometry args={[0.05, 14, 10]} />
        <M c="#a3adbb" r={0.35} m={0.3} />
      </mesh>
    ))}
  </>
);

const RobotHelm: React.FC = () => (
  <>
    <mesh position={[0, 0.03, 0.155]}>
      <boxGeometry args={[0.2, 0.05, 0.03]} />
      <meshBasicMaterial color="#40e0ff" toneMapped={false} />
    </mesh>
    <mesh position={[0, 0.2, 0]}>
      <cylinderGeometry args={[0.006, 0.006, 0.12, 6]} />
      <M c="#8c96a5" m={0.8} r={0.3} />
    </mesh>
    <mesh position={[0, 0.27, 0]}>
      <sphereGeometry args={[0.022, 10, 8]} />
      <meshBasicMaterial color="#ff3040" toneMapped={false} />
    </mesh>
  </>
);

const Crown: React.FC = () => (
  <group position={[0, 0.15, 0]} rotation={[-0.1, 0, 0.08]}>
    <mesh>
      <cylinderGeometry args={[0.11, 0.1, 0.07, 20, 1, true]} />
      <meshStandardMaterial color="#ffc93a" metalness={0.9} roughness={0.25} side={THREE.DoubleSide} />
    </mesh>
    {Array.from({length: 6}).map((_, i) => {
      const a = (i / 6) * Math.PI * 2;
      return (
        <mesh key={i} position={[Math.sin(a) * 0.105, 0.06, Math.cos(a) * 0.105]}>
          <coneGeometry args={[0.025, 0.06, 6]} />
          <meshStandardMaterial color="#ffc93a" metalness={0.9} roughness={0.25} />
        </mesh>
      );
    })}
    {[0, 1, 2].map((i) => (
      <mesh key={i} position={[Math.sin((i - 1) * 0.6) * 0.106, 0, Math.cos((i - 1) * 0.6) * 0.106]}>
        <sphereGeometry args={[0.014, 8, 6]} />
        <meshStandardMaterial color={i === 1 ? '#e0203a' : '#2a7de0'} roughness={0.2} />
      </mesh>
    ))}
  </group>
);

const Cape: React.FC = () => (
  <mesh position={[0, 0.2, -0.04]} rotation={[0.12, 0, 0]}>
    <cylinderGeometry args={[0.13, 0.2, 0.3, 20, 1, true, Math.PI * 0.6, Math.PI * 0.8]} />
    <meshStandardMaterial color="#b0122a" roughness={0.6} side={THREE.DoubleSide} />
  </mesh>
);

export const Rat: React.FC<RatProps> = ({t, position = [0, 0, 0], rotY = 0, scale = 1, fur = '#8e909c', gear = {}, nervous = 0, hop = 0, look = 0, sweat, squash = 0, determined}) => {
  const shiver = nervous * Math.sin(t * 47) * 0.008;
  const dart = look + nervous * (Math.sin(t * 3.1) > 0.3 ? 0.6 : Math.sin(t * 3.1) < -0.3 ? -0.6 : 0);
  const breathe = 1 + Math.sin(t * (nervous ? 14 : 4)) * 0.025;
  const earTw = nervous * Math.sin(t * 9) * 0.15;
  const tail = useMemo(() => tubeGeo([[0, 0.07, -0.13], [0.06, 0.03, -0.3], [0.2, 0.04, -0.4], [0.3, 0.13, -0.38], [0.32, 0.22, -0.3]], 0.016), []);
  const belly = '#d4d0d8';
  const pink = '#f29aa7';
  const sq = 1 - squash * 0.25;
  return (
    <group position={[position[0] + shiver, position[1] + hop, position[2]]} rotation={[0, rotY, 0]} scale={[scale * (1 + squash * 0.15), scale * sq, scale * (1 + squash * 0.15)]}>
      {/* blob shadow */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.003 - hop / scale, 0]}>
        <circleGeometry args={[0.2, 24]} />
        <meshBasicMaterial color="#000" transparent opacity={0.35 / (1 + hop * 3)} depthWrite={false} />
      </mesh>
      {/* body */}
      <mesh position={[0, 0.16, 0]} scale={[1, 0.95 * breathe, 1.1]}>
        <sphereGeometry args={[0.15, 24, 18]} />
        <M c={fur} r={0.8} />
      </mesh>
      <mesh position={[0, 0.145, 0.085]} scale={[0.8, 0.88, 0.62]}>
        <sphereGeometry args={[0.13, 24, 18]} />
        <M c={belly} r={0.85} />
      </mesh>
      {/* feet */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.08, 0.02, 0.1]} scale={[1, 0.5, 1.5]}>
          <sphereGeometry args={[0.04, 12, 10]} />
          <M c={pink} />
        </mesh>
      ))}
      {/* tail */}
      <mesh geometry={tail} rotation={[0, Math.sin(t * 2.4) * 0.2, 0]}>
        <M c={pink} r={0.6} />
      </mesh>
      {/* head */}
      <group position={[0, 0.37, 0.05]} rotation={[0, dart * 0.15, 0]}>
        <mesh scale={[1.05, 0.95, 1]}>
          <sphereGeometry args={[0.165, 28, 22]} />
          <M c={fur} r={0.8} />
        </mesh>
        {/* snout */}
        <mesh position={[0, -0.04, 0.13]} scale={[0.95, 0.8, 1.15]}>
          <sphereGeometry args={[0.085, 20, 16]} />
          <M c="#b8b6c2" r={0.8} />
        </mesh>
        <mesh position={[0, -0.025, 0.232]}>
          <sphereGeometry args={[0.032, 16, 12]} />
          <M c="#ff7f9a" r={0.3} />
        </mesh>
        {/* buck teeth */}
        <mesh position={[0, -0.1, 0.19]}>
          <boxGeometry args={[0.04, 0.035, 0.012]} />
          <M c="#fffbea" r={0.3} />
        </mesh>
        {/* whiskers */}
        {[-1, 1].map((s) =>
          [0.02, -0.02].map((dy, j) => (
            <mesh key={`${s}${j}`} position={[s * 0.13, -0.03 + dy, 0.18]} rotation={[0, 0, Math.PI / 2 + s * (dy * 6)]}>
              <cylinderGeometry args={[0.0025, 0.0025, 0.14, 4]} />
              <M c="#2b2b33" />
            </mesh>
          )),
        )}
        {/* eyes */}
        {[-1, 1].map((s) => (
          <group key={s} position={[s * 0.068, 0.035, 0.138]}>
            <mesh scale={[1, determined ? 0.75 : 1.08, 0.8]}>
              <sphereGeometry args={[0.045, 18, 14]} />
              <meshStandardMaterial color="#111118" roughness={0.15} />
            </mesh>
            <mesh position={[0.012 + dart * 0.01, 0.018, 0.032]}>
              <sphereGeometry args={[0.014, 10, 8]} />
              <meshBasicMaterial color="#ffffff" />
            </mesh>
            <mesh position={[-0.01 + dart * 0.01, -0.012, 0.036]}>
              <sphereGeometry args={[0.006, 8, 6]} />
              <meshBasicMaterial color="#ffffff" />
            </mesh>
            {determined ? (
              <mesh position={[-s * 0.005, 0.052, 0.02]} rotation={[0, 0, s * 0.45]}>
                <boxGeometry args={[0.07, 0.016, 0.02]} />
                <M c="#2a2a30" />
              </mesh>
            ) : null}
          </group>
        ))}
        {/* blush */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.11, -0.04, 0.115]} scale={[1, 0.6, 0.3]}>
            <sphereGeometry args={[0.03, 10, 8]} />
            <meshBasicMaterial color="#ff9fb0" transparent opacity={0.8} />
          </mesh>
        ))}
        {/* ears: big round */}
        {[-1, 1].map((s) => (
          <group key={s} position={[s * 0.13, 0.13, -0.02]} rotation={[0.15, s * -0.25, s * (-0.45 - earTw)]}>
            <mesh rotation={[Math.PI / 2, 0, 0]}>
              <cylinderGeometry args={[0.105, 0.105, 0.022, 24]} />
              <M c={fur} r={0.8} />
            </mesh>
            <mesh rotation={[Math.PI / 2, 0, 0]} position={[0, 0, 0.012]}>
              <cylinderGeometry args={[0.075, 0.075, 0.006, 24]} />
              <M c={pink} r={0.6} />
            </mesh>
          </group>
        ))}
        {gear.hardhat ? (
          <group position={[0, 0.1, 0]} rotation={[-0.12, 0, 0.08]}>
            <mesh>
              <sphereGeometry args={[0.15, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <M c="#ffc21a" r={0.35} />
            </mesh>
            <mesh position={[0, 0.005, 0.03]}>
              <cylinderGeometry args={[0.2, 0.2, 0.018, 28]} />
              <M c="#ffc21a" r={0.35} />
            </mesh>
            <mesh position={[0, 0.06, 0]}>
              <boxGeometry args={[0.03, 0.1, 0.27]} />
              <M c="#f2b000" r={0.35} />
            </mesh>
          </group>
        ) : null}
        {gear.robot ? <RobotHelm /> : null}
        {gear.king ? <Crown /> : null}
        {gear.helmet ? (
          <group position={[0, 0.09, 0]} rotation={[-0.15, 0, 0]}>
            <mesh>
              <sphereGeometry args={[0.165, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
              <M c="#56703c" r={0.6} />
            </mesh>
            <mesh position={[0, 0, 0]}>
              <cylinderGeometry args={[0.18, 0.18, 0.02, 24]} />
              <M c="#4a6234" r={0.6} />
            </mesh>
          </group>
        ) : null}
        {gear.bandana ? (
          <mesh position={[0, 0.1, 0]} rotation={[0.2, 0, 0]}>
            <torusGeometry args={[0.15, 0.022, 8, 24]} />
            <M c={gear.bandana} />
          </mesh>
        ) : null}
        {sweat ? (
          <mesh position={[0.15, 0.06 - ((t * 0.3) % 0.1), 0.11]} scale={[0.8, 1.2, 0.8]}>
            <sphereGeometry args={[0.018, 10, 8]} />
            <meshStandardMaterial color="#8fd8ff" roughness={0.1} transparent opacity={0.9} />
          </mesh>
        ) : null}
      </group>
      {/* arms */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.1, 0.17, 0.15]} rotation={[0.9, 0, s * 0.4]} scale={[1, 1.4, 1]}>
          <sphereGeometry args={[0.035, 12, 10]} />
          <M c={fur} r={0.8} />
        </mesh>
      ))}
      {gear.crust ? <Crust position={[0.02, 0.15, 0.2]} rot={[0.5, 0, 0.5]} s={0.9} /> : null}
      {gear.shield ? (
        <group position={[-0.13, 0.2, 0.17]} rotation={[0, 0.35, 0.12]}>
          <MetroCard />
        </group>
      ) : null}
      {gear.pizzaArmor ? <PizzaBoxArmor /> : null}
      {gear.sniper ? <Rifle /> : null}
      {gear.robot ? <RobotSuit t={t} /> : null}
      {gear.king ? <Cape /> : null}
    </group>
  );
};

// ================================================================ ROOMBA TANK
export const RoombaTank: React.FC<{t: number; position?: V3; rotY?: number; scale?: number}> = ({t, position = [0, 0, 0], rotY = 0, scale = 1}) => (
  <group position={position} rotation={[0, rotY, 0]} scale={scale}>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.003, 0]}>
      <circleGeometry args={[0.4, 28]} />
      <meshBasicMaterial color="#000" transparent opacity={0.4} depthWrite={false} />
    </mesh>
    <mesh position={[0, 0.06, 0]}>
      <cylinderGeometry args={[0.36, 0.37, 0.1, 40]} />
      <M c="#2b2d33" r={0.3} m={0.2} />
    </mesh>
    <mesh position={[0, 0.112, 0]}>
      <cylinderGeometry args={[0.3, 0.3, 0.01, 40]} />
      <M c="#4a4e58" r={0.25} m={0.4} />
    </mesh>
    <mesh position={[0, 0.06, 0]}>
      <torusGeometry args={[0.365, 0.02, 8, 40, Math.PI]} />
      <M c="#9aa0aa" r={0.4} />
    </mesh>
    {/* LED */}
    <mesh position={[0.18, 0.12, 0.18]}>
      <sphereGeometry args={[0.02, 8, 6]} />
      <meshBasicMaterial color={Math.sin(t * 8) > 0 ? '#3dff6a' : '#0a5a1a'} />
    </mesh>
    {/* cannon */}
    <group position={[0.17, 0.2, 0.05]} rotation={[Math.PI / 2 - 0.15, 0, 0]}>
      <mesh>
        <cylinderGeometry args={[0.03, 0.035, 0.4, 14]} />
        <M c="#5d6650" r={0.5} m={0.3} />
      </mesh>
      <mesh position={[0, 0.2, 0]}>
        <cylinderGeometry args={[0.045, 0.045, 0.05, 14]} />
        <M c="#3d4434" />
      </mesh>
    </group>
    <mesh position={[0.17, 0.17, -0.05]}>
      <boxGeometry args={[0.12, 0.1, 0.14]} />
      <M c="#5d6650" />
    </mesh>
    {/* little flag */}
    <mesh position={[-0.25, 0.32, -0.15]}>
      <cylinderGeometry args={[0.006, 0.006, 0.4, 6]} />
      <M c="#ddd" />
    </mesh>
    <mesh position={[-0.19, 0.46, -0.15]} rotation={[0, Math.sin(t * 6) * 0.3, 0]}>
      <boxGeometry args={[0.12, 0.08, 0.005]} />
      <M c="#ffcc00" />
    </mesh>
  </group>
);

// ================================================================ CAT
export type CatKind = 'tabby' | 'black' | 'orange';
export const CAT_COLORS: Record<CatKind, {fur: string; stripe: string; muzzle: string}> = {
  tabby: {fur: '#9b9ca6', stripe: '#5d5e6a', muzzle: '#e8e6ee'},
  black: {fur: '#2a2a33', stripe: '#1b1b22', muzzle: '#3c3c47'},
  orange: {fur: '#f08a2c', stripe: '#c35a14', muzzle: '#fff1e0'},
};
export const EYE = '#d8ff3a';

export type CatProps = {t: number; kind?: CatKind; position?: V3; rotY?: number; scale?: number; boss?: boolean; roar?: number; narrow?: number; fat?: number};

export const Cat: React.FC<CatProps> = ({t, kind = 'tabby', position = [0, 0, 0], rotY = 0, scale = 1, boss, roar = 0, narrow = 0, fat = 1}) => {
  const C = CAT_COLORS[boss ? 'orange' : kind];
  const breathe = 1 + Math.sin(t * 3 + position[0]) * 0.02;
  const tail = useMemo(() => tubeGeo([[0, 0.2, -0.3], [0.25, 0.25, -0.5], [0.42, 0.6, -0.45], [0.38, 0.95, -0.35]], 0.06), []);
  const eyeH = (1 - 0.78 * narrow) * (1 - 0.15 * roar);
  const headTilt = -roar * 0.18;
  return (
    <group position={position} rotation={[0, rotY, 0]} scale={scale}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.004, 0]}>
        <circleGeometry args={[0.45 * fat, 28]} />
        <meshBasicMaterial color="#000" transparent opacity={0.4} depthWrite={false} />
      </mesh>
      {/* body */}
      <mesh position={[0, 0.32, 0]} scale={[1.1 * fat, 0.92 * breathe, 1.0 * fat]}>
        <sphereGeometry args={[0.34, 28, 22]} />
        <M c={C.fur} r={0.85} />
      </mesh>
      <mesh position={[0, 0.3, 0.17 * fat]} scale={[0.75 * fat, 0.8, 0.55]}>
        <sphereGeometry args={[0.3, 22, 18]} />
        <M c={C.muzzle} r={0.9} />
      </mesh>
      {/* paws */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.16 * fat, 0.06, 0.24 * fat]} scale={[1, 0.7, 1.2]}>
          <sphereGeometry args={[0.09, 14, 12]} />
          <M c={C.muzzle} r={0.9} />
        </mesh>
      ))}
      <mesh geometry={tail} rotation={[0, Math.sin(t * 2 + position[2]) * 0.25, 0]}>
        <M c={C.fur} r={0.85} />
      </mesh>
      {/* head */}
      <group position={[0, 0.84, 0.02]} rotation={[headTilt, 0, 0]}>
        <mesh scale={[1.12, 0.95, 1]}>
          <sphereGeometry args={[0.37, 32, 24]} />
          <M c={C.fur} r={0.85} />
        </mesh>
        {/* tabby stripes on forehead */}
        {[-0.08, 0, 0.08].map((x, i) => (
          <mesh key={i} position={[x, 0.24 - Math.abs(x) * 0.4, 0.27]} rotation={[-0.75, 0, -x * 2]}>
            <boxGeometry args={[0.035, 0.13, 0.03]} />
            <M c={C.stripe} r={0.9} />
          </mesh>
        ))}
        {/* cheek fluff */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.33, -0.12, 0.08]} rotation={[0, 0, s * 0.6]} scale={[0.6, 1, 0.7]}>
            <coneGeometry args={[0.1, 0.2, 10]} />
            <M c={C.fur} r={0.85} />
          </mesh>
        ))}
        {/* ears */}
        {[-1, 1].map((s) => (
          <group key={s} position={[s * 0.22, 0.27, 0]} rotation={[0, 0, s * -0.38]}>
            <mesh>
              <coneGeometry args={[0.13, 0.27, 16]} />
              <M c={C.fur} r={0.85} />
            </mesh>
            <mesh position={[0, -0.02, 0.06]} scale={[0.6, 0.75, 0.4]}>
              <coneGeometry args={[0.13, 0.27, 12]} />
              <M c="#f29aa7" />
            </mesh>
          </group>
        ))}
        {/* eyes */}
        {[-1, 1].map((s) => {
          const patched = boss && s === -1;
          return (
            <group key={s} position={[s * 0.15, 0.03, 0.3]}>
              {patched ? null : (
                <>
                  <mesh scale={[1, 0.85 * eyeH, 0.45]} rotation={[0, 0, s * 0.18]}>
                    <sphereGeometry args={[0.095, 20, 16]} />
                    <meshStandardMaterial color={EYE} emissive={EYE} emissiveIntensity={1.4} roughness={0.2} />
                  </mesh>
                  <mesh position={[0, 0, 0.04]} scale={[1, eyeH, 1]}>
                    <boxGeometry args={[0.025, 0.12, 0.01]} />
                    <meshBasicMaterial color="#0b0b0b" />
                  </mesh>
                  <mesh position={[0.03, 0.03 * eyeH, 0.045]}>
                    <sphereGeometry args={[0.014, 8, 6]} />
                    <meshBasicMaterial color="#ffffff" />
                  </mesh>
                </>
              )}
              {/* angry brow */}
              <mesh position={[-s * 0.005, 0.09 - narrow * 0.04, 0.03]} rotation={[0, 0, s * (0.5 + narrow * 0.2)]}>
                <boxGeometry args={[0.17, 0.04, 0.04]} />
                <meshStandardMaterial color={kind === 'black' && !boss ? '#0c0c10' : '#3a2a20'} />
              </mesh>
            </group>
          );
        })}
        {boss ? (
          <>
            {/* eye patch */}
            <mesh position={[-0.15, 0.04, 0.3]} rotation={[Math.PI / 2, 0, 0]} scale={[1, 1, 1.1]}>
              <cylinderGeometry args={[0.1, 0.1, 0.03, 20]} />
              <M c="#111" r={0.4} />
            </mesh>
            <mesh position={[0, 0.06, 0]} rotation={[0.1, 0, 0.35]} scale={[1.12, 1, 1.02]}>
              <torusGeometry args={[0.366, 0.012, 6, 40]} />
              <M c="#111" />
            </mesh>
            {/* scar across right eye */}
            <mesh position={[0.17, 0.05, 0.335]} rotation={[0, 0, -0.35]}>
              <boxGeometry args={[0.02, 0.28, 0.02]} />
              <M c="#c64b5e" r={0.5} />
            </mesh>
            {[-0.06, 0, 0.06].map((y, i) => (
              <mesh key={i} position={[0.17 - y * 0.35, 0.05 + y, 0.338]} rotation={[0, 0, 1.2]}>
                <boxGeometry args={[0.012, 0.05, 0.015]} />
                <M c="#c64b5e" />
              </mesh>
            ))}
          </>
        ) : null}
        {/* muzzle */}
        {[-1, 1].map((s) => (
          <mesh key={s} position={[s * 0.06, -0.12, 0.31]} scale={[1, 0.8, 0.6]}>
            <sphereGeometry args={[0.075, 14, 12]} />
            <M c={C.muzzle} r={0.9} />
          </mesh>
        ))}
        <mesh position={[0, -0.075, 0.36]} scale={[1.3, 0.8, 0.8]}>
          <sphereGeometry args={[0.025, 10, 8]} />
          <M c="#e86a84" r={0.4} />
        </mesh>
        {/* mouth: roar */}
        {roar > 0.05 ? (
          <group position={[0, -0.2, 0.3]}>
            <mesh scale={[1.2, 0.3 + roar * 1.1, 0.5]}>
              <sphereGeometry args={[0.08, 18, 14]} />
              <meshStandardMaterial color="#5a0f1c" roughness={0.6} />
            </mesh>
            <mesh position={[0, -0.03 - roar * 0.04, 0.03]} scale={[1, 0.4, 0.5]}>
              <sphereGeometry args={[0.05, 12, 10]} />
              <M c="#e45a72" />
            </mesh>
            {[-1, 1].map((s) => (
              <mesh key={s} position={[s * 0.05, 0.02 + roar * 0.04, 0.035]} rotation={[Math.PI, 0, 0]}>
                <coneGeometry args={[0.018, 0.06, 8]} />
                <M c="#fffbea" r={0.3} />
              </mesh>
            ))}
          </group>
        ) : (
          <mesh position={[0, -0.18, 0.33]} rotation={[0, 0, Math.PI]}>
            <torusGeometry args={[0.035, 0.008, 6, 12, Math.PI]} />
            <M c="#3a2a20" />
          </mesh>
        )}
        {/* whiskers */}
        {[-1, 1].map((s) =>
          [0.02, -0.03].map((dy, j) => (
            <mesh key={`${s}${j}`} position={[s * 0.2, -0.12 + dy, 0.3]} rotation={[0, 0, Math.PI / 2 - s * dy * 5]}>
              <cylinderGeometry args={[0.004, 0.004, 0.22, 4]} />
              <meshBasicMaterial color="#f4f4f4" />
            </mesh>
          )),
        )}
      </group>
    </group>
  );
};

// ================================================================ CAT CROWD (instanced)
type Part = {geo: THREE.BufferGeometry; local: THREE.Matrix4; color: 'fur' | 'muzzle' | 'pink' | 'eye' | 'dark' | 'helmet'};
const mk = (pos: V3, scl: V3 = [1, 1, 1], rot: V3 = [0, 0, 0]) =>
  new THREE.Matrix4().compose(new THREE.Vector3(...pos), new THREE.Quaternion().setFromEuler(new THREE.Euler(...rot)), new THREE.Vector3(...scl));

export type CrowdCat = {p: V3; s: number; kind: CatKind; ry: number; ph: number};

export const makeCatCrowd = (opts: {x0: number; x1: number; z0: number; z1: number; spacing?: number; seed?: number; jitter?: number}) => {
  const {x0, x1, z0, z1, spacing = 0.78, seed = 1, jitter = 0.25} = opts;
  const out: CrowdCat[] = [];
  let i = 0;
  for (let z = z0; z > z1; z -= spacing * 0.9) {
    for (let x = x0; x < x1; x += spacing) {
      i++;
      const r = rnd(i * 7 + seed);
      const kind: CatKind = r < 0.4 ? 'tabby' : r < 0.72 ? 'black' : 'orange';
      out.push({
        p: [x + (rnd(i * 3 + seed) - 0.5) * jitter + ((Math.round(z * 10) % 2) * spacing) / 2, 0, z + (rnd(i * 5 + seed) - 0.5) * jitter],
        s: 0.85 + rnd(i * 11 + seed) * 0.35,
        kind,
        ry: (rnd(i * 13 + seed) - 0.5) * 0.5,
        ph: rnd(i * 17 + seed) * 6.28,
      });
    }
  }
  return out;
};

export const CatCrowd: React.FC<{t: number; cats: CrowdCat[]; eyeFog?: boolean; bounce?: number}> = ({t, cats, eyeFog = false, bounce = 1}) => {
  const parts = useMemo<Part[]>(() => {
    const sph = new THREE.SphereGeometry(1, 16, 12);
    const cone = new THREE.ConeGeometry(1, 1, 10);
    const box = new THREE.BoxGeometry(1, 1, 1);
    return [
      {geo: sph, local: mk([0, 0.32, 0], [0.37, 0.31, 0.34]), color: 'fur'},
      {geo: sph, local: mk([0, 0.84, 0.02], [0.41, 0.35, 0.37]), color: 'fur'},
      {geo: sph, local: mk([0, 0.3, 0.17], [0.22, 0.24, 0.16]), color: 'muzzle'},
      {geo: cone, local: mk([-0.22, 1.11, 0.02], [0.13, 0.27, 0.13], [0, 0, 0.38]), color: 'fur'},
      {geo: cone, local: mk([0.22, 1.11, 0.02], [0.13, 0.27, 0.13], [0, 0, -0.38]), color: 'fur'},
      {geo: sph, local: mk([-0.06, 0.72, 0.33], [0.075, 0.06, 0.045]), color: 'muzzle'},
      {geo: sph, local: mk([0.06, 0.72, 0.33], [0.075, 0.06, 0.045]), color: 'muzzle'},
      {geo: sph, local: mk([-0.15, 0.87, 0.32], [0.095, 0.075, 0.045], [0, 0, -0.18]), color: 'eye'},
      {geo: sph, local: mk([0.15, 0.87, 0.32], [0.095, 0.075, 0.045], [0, 0, 0.18]), color: 'eye'},
      {geo: box, local: mk([-0.15, 0.87, 0.36], [0.022, 0.1, 0.01]), color: 'dark'},
      {geo: box, local: mk([0.15, 0.87, 0.36], [0.022, 0.1, 0.01]), color: 'dark'},
      {geo: box, local: mk([-0.155, 0.96, 0.34], [0.17, 0.04, 0.04], [0, 0, -0.5]), color: 'dark'},
      {geo: box, local: mk([0.155, 0.96, 0.34], [0.17, 0.04, 0.04], [0, 0, 0.5]), color: 'dark'},
    ];
  }, []);
  const refs = useRef<(THREE.InstancedMesh | null)[]>([]);
  useLayoutEffect(() => {
    const base = new THREE.Matrix4();
    const m = new THREE.Matrix4();
    const col = new THREE.Color();
    parts.forEach((pt, pi) => {
      const im = refs.current[pi];
      if (!im) return;
      cats.forEach((c, i) => {
        const b = Math.max(0, Math.sin(t * 7 + c.ph)) * 0.06 * bounce;
        base.compose(new THREE.Vector3(c.p[0], c.p[1] + b, c.p[2]), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, c.ry, Math.sin(t * 2 + c.ph) * 0.05)), new THREE.Vector3(c.s, c.s, c.s));
        m.multiplyMatrices(base, pt.local);
        im.setMatrixAt(i, m);
        const C = CAT_COLORS[c.kind];
        if (pt.color === 'fur') im.setColorAt(i, col.set(C.fur));
        if (pt.color === 'muzzle') im.setColorAt(i, col.set(C.muzzle));
      });
      im.instanceMatrix.needsUpdate = true;
      if (im.instanceColor) im.instanceColor.needsUpdate = true;
    });
  }, [t, cats, parts, bounce]);
  return (
    <>
      {parts.map((pt, pi) => (
        <instancedMesh key={pi} ref={(r) => { refs.current[pi] = r; }} args={[pt.geo, undefined, cats.length]} frustumCulled={false}>
          {pt.color === 'eye' ? (
            <meshBasicMaterial color={EYE} fog={eyeFog} toneMapped={false} />
          ) : pt.color === 'dark' ? (
            <meshBasicMaterial color="#0a0a0a" />
          ) : (
            <meshStandardMaterial roughness={0.85} />
          )}
        </instancedMesh>
      ))}
    </>
  );
};

// ================================================================ RAT SWARM (instanced)
export type SwarmRat = {p: V3; ry: number; s: number; ph: number};
export const RatSwarm: React.FC<{t: number; rats: SwarmRat[]}> = ({t, rats}) => {
  const parts = useMemo<Part[]>(() => {
    const sph = new THREE.SphereGeometry(1, 14, 10);
    const cyl = new THREE.CylinderGeometry(1, 1, 1, 14);
    return [
      {geo: sph, local: mk([0, 0.16, 0], [0.15, 0.143, 0.165]), color: 'fur'},
      {geo: sph, local: mk([0, 0.37, 0.05], [0.173, 0.157, 0.165]), color: 'fur'},
      {geo: sph, local: mk([0, 0.33, 0.18], [0.08, 0.068, 0.098]), color: 'muzzle'},
      {geo: sph, local: mk([0, 0.345, 0.282], [0.032, 0.032, 0.032]), color: 'pink'},
      {geo: cyl, local: mk([-0.13, 0.5, 0.03], [0.105, 0.022, 0.105], [Math.PI / 2, 0, 0.45]), color: 'fur'},
      {geo: cyl, local: mk([0.13, 0.5, 0.03], [0.105, 0.022, 0.105], [Math.PI / 2, 0, -0.45]), color: 'fur'},
      {geo: cyl, local: mk([-0.13, 0.5, 0.045], [0.075, 0.006, 0.075], [Math.PI / 2, 0, 0.45]), color: 'pink'},
      {geo: cyl, local: mk([0.13, 0.5, 0.045], [0.075, 0.006, 0.075], [Math.PI / 2, 0, -0.45]), color: 'pink'},
      {geo: sph, local: mk([-0.068, 0.405, 0.188], [0.045, 0.048, 0.036]), color: 'dark'},
      {geo: sph, local: mk([0.068, 0.405, 0.188], [0.045, 0.048, 0.036]), color: 'dark'},
      {geo: sph, local: mk([-0.056, 0.42, 0.22], [0.013, 0.013, 0.013]), color: 'eye'},
      {geo: sph, local: mk([0.08, 0.42, 0.22], [0.013, 0.013, 0.013]), color: 'eye'},
      {geo: new THREE.SphereGeometry(1, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), local: mk([0, 0.45, 0.04], [0.168, 0.15, 0.168], [-0.15, 0, 0]), color: 'helmet'},
    ];
  }, []);
  const refs = useRef<(THREE.InstancedMesh | null)[]>([]);
  useLayoutEffect(() => {
    const base = new THREE.Matrix4();
    const m = new THREE.Matrix4();
    parts.forEach((pt, pi) => {
      const im = refs.current[pi];
      if (!im) return;
      rats.forEach((r, i) => {
        const hop = Math.abs(Math.sin(t * 12 + r.ph)) * 0.06;
        base.compose(new THREE.Vector3(r.p[0], r.p[1] + hop, r.p[2]), new THREE.Quaternion().setFromEuler(new THREE.Euler(0, r.ry, 0)), new THREE.Vector3(r.s, r.s, r.s));
        m.multiplyMatrices(base, pt.local);
        im.setMatrixAt(i, m);
      });
      im.instanceMatrix.needsUpdate = true;
    });
  }, [t, rats, parts]);
  return (
    <>
      {parts.map((pt, pi) => (
        <instancedMesh key={pi} ref={(r) => { refs.current[pi] = r; }} args={[pt.geo, undefined, Math.max(1, rats.length)]} count={rats.length} frustumCulled={false}>
          {pt.color === 'eye' ? (
            <meshBasicMaterial color="#ffffff" />
          ) : pt.color === 'dark' ? (
            <meshStandardMaterial color="#111118" roughness={0.15} />
          ) : (
            <meshStandardMaterial color={pt.color === 'fur' ? '#8e909c' : pt.color === 'pink' ? '#ff7f9a' : pt.color === 'helmet' ? '#56703c' : '#b8b6c2'} roughness={0.8} />
          )}
        </instancedMesh>
      ))}
    </>
  );
};
