import * as THREE from 'three';

export type V3 = [number, number, number];
export type CamKey = {t: number; pos: V3; at: V3; fov?: number};

export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
export const ease = (x: number) => {
  const k = clamp(x);
  return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
};
export const ramp = (t: number, a: number, b: number) => ease((t - a) / (b - a));
export const lin = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
export const punchAt = (t: number, beats: number[], len = 0.35) =>
  beats.reduce((m, b) => Math.max(m, t >= b && t < b + len ? 1 - (t - b) / len : 0), 0);

// deterministic pseudo random
export const rnd = (i: number) => {
  const x = Math.sin(i * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

export type CamState = {pos: V3; at: V3; fov: number};

/** Shared camera evaluation: used by the 3D CamRig AND by the HTML tag projector so tags stay glued to characters. */
export const camState = (keys: CamKey[], t: number, shake = 0, punch = 0): CamState => {
  let a = keys[0];
  let b = keys[keys.length - 1];
  for (let i = 0; i < keys.length - 1; i++) if (t >= keys[i].t && t <= keys[i + 1].t) { a = keys[i]; b = keys[i + 1]; break; }
  if (t < keys[0].t) b = a;
  if (t > keys[keys.length - 1].t) a = b;
  const k = a === b ? 0 : ease((t - a.t) / (b.t - a.t));
  const p = a.pos.map((v, i) => lerp(v, b.pos[i], k)) as V3;
  const at = a.at.map((v, i) => lerp(v, b.at[i], k)) as V3;
  const sh = 0.006 + 0.06 * shake;
  const fr = shake > 0 ? 38 : 1.3;
  p[0] += Math.sin(t * fr) * sh;
  p[1] += Math.sin(t * fr * 1.3 + 1) * sh;
  p[2] += Math.sin(t * fr * 0.7 + 2) * sh * 0.5;
  const fov = lerp(a.fov ?? 40, b.fov ?? 40, k) * (1 - 0.08 * punch);
  return {pos: p, at, fov};
};

export const applyCam = (cam: THREE.PerspectiveCamera, s: CamState, aspect: number) => {
  cam.position.set(...s.pos);
  cam.lookAt(...s.at);
  cam.fov = s.fov;
  cam.aspect = aspect;
  cam.near = 0.05;
  cam.far = 200;
  cam.updateProjectionMatrix();
  cam.updateMatrixWorld();
};

const tmpCam = new THREE.PerspectiveCamera();
/** project a world point to pixel coords for a W x H frame */
export const project = (s: CamState, p: V3, W: number, H: number) => {
  applyCam(tmpCam, s, W / H);
  const v = new THREE.Vector3(...p).project(tmpCam);
  return {x: (v.x * 0.5 + 0.5) * W, y: (-v.y * 0.5 + 0.5) * H, behind: v.z > 1, dist: tmpCam.position.distanceTo(new THREE.Vector3(...p))};
};
